<template>
    <div>
      <HzHeader></HzHeader>
      <div data-v-18c070a6="" class="personal-main-container lay-box clearfix">
        <div data-v-18c070a6="" class="personal-container">
            <LeftDash></LeftDash>
            <div data-v-18c070a6="" class="personal-main-box">
                <div data-v-18c070a6="" class="personal-main-content">
                    <div data-v-8d17c708="" data-v-18c070a6="" class="dashboard-page flex box-border">
                        <div data-v-8d17c708="" class="flex flex-col flex-auto">
                            <div data-v-0c8c315d="" data-v-8d17c708=""
                                class="sep-dashboard-welcome dashboard-welcome mb-24px">
                                <div data-v-0c8c315d=""
                                    class="welcome-text text-24px text-v3PrimaryText font-700 leading-34px"><span
                                        data-v-0c8c315d="">Welcome back, </span><span data-v-0c8c315d="">BGUSER-M3C8Z5R6
                                        <img data-v-0c8c315d="" width="26"
                                            src="/baseasset/img/dashboardNew/welcome-img.svg"
                                            class="ml-6px relative top-4px "></span></div>
                                <div data-v-0c8c315d="" class="text-16px text-v3TertiaryText leading-22px mt-4px">
                                    Bitcoin will do to banks what email did to the postal industry. — Rick Falkvinge
                                </div>
                            </div>
                            <div data-v-55078d1f="" data-v-8d17c708="" class="dashboard-userInfo relative">
                                <div data-v-55078d1f=""
                                    class="userInfo-top-content p-24px bg-v3levelsurface1 rounded-16px">
                                    <div data-v-55078d1f="" class="userInfo-wrapper flex items-center <md:items-start">
                                        <div data-v-247453ba="" data-v-55078d1f=""
                                            class="sep-bit-avatar relative cursor-pointer"
                                            style="width: 72px; height: 72px;"><span data-v-247453ba=""
                                                class="bit-avatar bit-avatar--circle"
                                                style="height: 72px; width: 72px; line-height: 72px;"><img
                                                    data-v-247453ba="" width="72" height="72"
                                                    src="../assets/img/avatar-default.svg"
                                                    class="default-img"></span> <!----></div>
                                        <div data-v-55078d1f=""
                                            class="avatar-tags-wrapper ml-16px flex flex-col justify-between md:h-auto">
                                            <div data-v-55078d1f=""
                                                class="userInfo-displayname text-v3PrimaryText text-24px font-700 leading-34px cursor-pointer">
                                                BGUSER-M3C8Z5R6
                                            </div>
                                            <div data-v-55078d1f="" class="tags-wrapper flex items-center flex-wrap">
                                                <div data-v-55078d1f=""
                                                    class="tag-item mr-8px px-12px py-4px h-17px leading-17px flex items-center bg-v3levelsurface0 rounded-16px text-12px text-v3SecondaryText cursor-pointer">
                                                    UID:&nbsp;
                                                    <span data-v-55078d1f="" class="cursor-text">9088351813</span> <svg
                                                        data-v-55078d1f="" xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"
                                                        class="iconfont w-12px h-12px ml-4px mt-2px">
                                                        <path
                                                            d="M20.25 3h-12a.75.75 0 00-.75.75V7.5H3.75a.75.75 0 00-.75.75v12a.75.75 0 00.75.75h12a.75.75 0 00.75-.75V16.5h3.75a.75.75 0 00.75-.75v-12a.75.75 0 00-.75-.75zM15 19.5H4.5V9H15v10.5zm4.5-4.5h-3V8.25a.75.75 0 00-.75-.75H9v-3h10.5V15z">
                                                        </path>
                                                    </svg>
                                                </div> <!---->
                                                <div data-v-4eaa59c6="" data-v-55078d1f=""
                                                    class="bit-tooltip sep-verified-label relative flex items-center cursor-pointer mr-8px tag-item"
                                                    aria-describedby="bit-tooltip-5424" tabindex="0"><span
                                                        data-v-4eaa59c6="" class="absolute flex items-center"><img
                                                            data-v-4eaa59c6=""
                                                            src="/baseasset/img/dashboardNew/icon-unverified-light.svg"></span>
                                                    <div data-v-4eaa59c6=""
                                                        class="text-12px font-700 leading-18px h-18px ml-12px pl-12px pr-6px rounded-2px text-unverified">
                                                        Unverified
                                                    </div>
                                                </div> <!---->
                                                <div data-v-3ac78c20="" data-v-55078d1f="" class="flex tag-item"><!---->
                                                    <!----> <!---->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div data-v-55078d1f="" class="profile-btn-375"><button data-v-55078d1f=""
                                            type="button"
                                            class="bit-button w-full ml-12px bit-button--main bit-button--large is-round"><!----><!----><!----><span>
                                                My profile
                                            </span><!----></button></div>
                                </div>
                                <div data-v-55078d1f="" class="absolute top-24px right-24px"><button data-v-55078d1f=""
                                        type="button" class="bit-button mr-12px bit-button--default is-circle"><!----><i
                                            class="bit-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                fill="currentColor" aria-hidden="true">
                                                <path
                                                    d="M23.185 11.696c-.032-.074-.827-1.835-2.592-3.6C18.241 5.742 15.27 4.5 12 4.5c-3.27 0-6.24 1.243-8.593 3.595C1.642 9.861.844 11.625.815 11.696a.75.75 0 000 .61c.032.074.827 1.834 2.592 3.6C5.759 18.256 8.73 19.5 12 19.5c3.27 0 6.24-1.243 8.593-3.594 1.765-1.766 2.56-3.526 2.592-3.6a.75.75 0 000-.61zM12 18c-2.886 0-5.407-1.05-7.493-3.117A12.511 12.511 0 012.344 12a12.499 12.499 0 012.163-2.883C6.593 7.05 9.114 6 12 6s5.407 1.05 7.493 3.117A12.507 12.507 0 0121.661 12c-.676 1.262-3.62 6-9.661 6zm0-10.5a4.5 4.5 0 100 9 4.5 4.5 0 000-9zm0 7.5a3 3 0 110-5.999A3 3 0 0112 15z">
                                                </path>
                                            </svg></i><!----><!----><!----></button> <!----> <button data-v-55078d1f=""
                                        type="button"
                                        class="bit-button profile-btn ml-12px bit-button--main is-round"><!----><!----><!----><span>
                                            My profile
                                        </span><!----></button></div>
                            </div>
                            <div
                                class="dashboard-cards-wrapper flex justify-between minpc:flex-col pad:flex-col phone:flex-col">
                                <div data-v-8d17c708=""
                                    class="dashboard-card-left flex flex-col flex-auto mr-32px minpc:mr-0 pad:mr-0 phone:mr-0">
                                    <div data-v-8d17c708=""
                                        class="card-items-wrapper flex items-center justify-between">
                                        <div data-v-6d6097fe="" data-v-8d17c708=""
                                            class="sep-dashboard-security box-border max-h-172px h-172px p-24px box-border border-1 rounded-16px border-v3StrengthBorder0 card-item">
                                            <div data-v-6d6097fe="" class="flex items-center justify-between">
                                                <div data-v-6d6097fe=""
                                                    class="text-20px font-700 leading-28px text-v3PrimaryText">
                                                    Security
                                                </div>
                                                <div data-v-6d6097fe=""
                                                    class="security-tag flex items-center h-36px pl-12px pr-16px rounded-full security-low">
                                                    <span data-v-6d6097fe="" class="security-svg mt-5px"><svg
                                                            data-v-6d6097fe="" width="20" height="20"
                                                            viewBox="0 0 20 20" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <g data-v-6d6097fe="" id="i-protect">
                                                                <path data-v-6d6097fe="" id="Vector"
                                                                    d="M3.18164 4.41509L10.0031 2.42432L16.818 4.41509V8.49769C16.818 12.7888 14.0719 16.5983 10.0008 17.9548C5.92865 16.5984 3.18164 12.788 3.18164 8.49579V4.41509Z"
                                                                    stroke="currentColor" stroke-width="1.6"
                                                                    stroke-linejoin="round"></path>
                                                                <path data-v-6d6097fe="" id="Vector_2"
                                                                    d="M6.59082 9.62123L9.24234 12.2727L13.7878 7.72729"
                                                                    stroke="currentColor" stroke-width="1.6"
                                                                    stroke-linecap="round" stroke-linejoin="round">
                                                                </path>
                                                            </g>
                                                        </svg></span> <span data-v-6d6097fe=""
                                                        class="ml-6px font-700 leading-20px text-v3PrimaryText">
                                                        Low
                                                    </span>
                                                </div>
                                            </div>
                                            <div data-v-6d6097fe=""
                                                class="sep-dashboard-animate-button main-content mt-8px box-border px-16px py-16px h-80px max-h-80px rounded-8px cursor-pointer">
                                                <div data-v-6d6097fe=""
                                                    class="font-500 text-12px leading-17px text-v3TertiaryText">
                                                    Verification
                                                </div>
                                                <div data-v-6d6097fe=""
                                                    class="mt-8px flex items-center justify-between leading-20px text-v3PrimaryText">
                                                    Passkey
                                                    <span data-v-6d6097fe=""
                                                        class="sep-dashboard-btn-icon-right flex"><svg
                                                            data-v-6d6097fe="" xmlns="http://www.w3.org/2000/svg"
                                                            viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"
                                                            class="icon-font w-16px h-16px rtl-rotate">
                                                            <path
                                                                d="M20.78 12.53l-6.75 6.75a.75.75 0 01-1.06-1.06l5.47-5.47H3.75a.75.75 0 110-1.5h14.69l-5.47-5.47a.75.75 0 111.06-1.06l6.75 6.75a.747.747 0 010 1.06z">
                                                            </path>
                                                        </svg></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div data-v-5d4dfe3b="" data-v-8d17c708=""
                                            class="sep-dashboard-kyc box-border max-h-172px h-172px p-24px box-border border-1 rounded-16px border-v3StrengthBorder0 card-item">
                                            <div data-v-5d4dfe3b="" class="flex items-center justify-between flex-wrap">
                                                <div data-v-5d4dfe3b=""
                                                    class="kyc-title text-20px font-700 leading-28px text-v3PrimaryText truncate">
                                                    Identity verification
                                                </div>
                                                <div data-v-5d4dfe3b=""
                                                    class="kyc-tag flex items-center gap-8px h-36px pl-12px pr-16px rounded-full kyc-unverified">
                                                    <img data-v-5d4dfe3b="" width="20" height="20"
                                                        src="/baseasset/img/dashboardNew/icon-unverified-light.svg">
                                                    <span data-v-5d4dfe3b=""
                                                        class="kyc-tagtext font-700 leading-20px text-v3PrimaryText pad:max-w-20px pad:truncate">
                                                        Unverified
                                                    </span>
                                                </div>
                                            </div>
                                            <div data-v-5d4dfe3b=""
                                                class="sep-dashboard-animate-button main-content mt-8px box-border flex justify-between px-16px py-16px h-80px max-h-80px rounded-8px cursor-pointer">
                                                <div data-v-5d4dfe3b=""
                                                    class="line-clamp-2 h-[42px] leading-20px text-v3PrimaryText">
                                                    Complete identity verification to unlock all features.
                                                </div>
                                                <div data-v-5d4dfe3b=""
                                                    class="sep-dashboard-btn-icon-right mt-8px self-end font-600 leading-20px text-v3PrimaryText">
                                                    <svg data-v-5d4dfe3b="" xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"
                                                        class="icon-font w-16px h-16px rtl-rotate">
                                                        <path
                                                            d="M20.78 12.53l-6.75 6.75a.75.75 0 01-1.06-1.06l5.47-5.47H3.75a.75.75 0 110-1.5h14.69l-5.47-5.47a.75.75 0 111.06-1.06l6.75 6.75a.747.747 0 010 1.06z">
                                                        </path>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div data-v-8d17c708="" class="card-items-wrapper flex">
                                        <div data-v-45e2eb2e="" data-v-8d17c708=""
                                            class="sep-dashboard-assets box-border min-h-295px p-24px box-border border-1 rounded-16px border-v3StrengthBorder0 cursor-pointer card-item"
                                            openeye="true">
                                            <div data-v-45e2eb2e="" class="flex items-center justify-between">
                                                <div data-v-45e2eb2e=""
                                                    class="text-20px font-700 leading-28px text-v3PrimaryText">
                                                    Assets
                                                </div>
                                                <div data-v-45e2eb2e="" class="<md:hidden"><button data-v-45e2eb2e=""
                                                        type="button"
                                                        class="bit-button bit-button--main is-round"><!----><!----><!----><span>
                                                            Deposit
                                                        </span><!----></button> <!----> <button data-v-45e2eb2e=""
                                                        type="button"
                                                        class="bit-button bit-button--default is-round"><!----><!----><!----><span>
                                                            Withdrawal
                                                        </span><!----></button> <button data-v-45e2eb2e="" type="button"
                                                        class="bit-button bit-button--default is-round"><!----><!----><!----><span>
                                                            Transfer
                                                        </span><!----></button></div>
                                            </div>
                                            <div data-v-45e2eb2e="" class="min-h-192px clear-both flex flex-col">
                                                <div
                                                    class="w-full my-40px box-border float-left pr-40px air:my-32px air:w-full air:pr-0 air:float-none pad:my-32px pad:w-full pad:pr-0 pad:float-none phone:my-20px phone:w-full phone:pr-0 phone:float-none">
                                                    <div class="flex flex-col">
                                                        <p class="flex align-center mb-8px select-none"><span
                                                                class="bit-tooltip text-v3TertiaryText inline-block text-16px leading-20px align-text-top border-0 border-b-1px border-dashed border-b-v3StrengthBorder1 hover:cursor-pointer"
                                                                aria-describedby="bit-tooltip-8724" tabindex="0">
                                                                Assets
                                                            </span> <i
                                                                class="iconfont cursor-pointer ml-5px text-v3DisabledText !text-fs-18px icon-Hide"></i>
                                                        </p>
                                                        <h1
                                                            class="flex items-center flex-wrap text-v3PrimaryText text-40px font-700 pro:leading-52px air:leading-52px pad:leading-52px phone:text-24px phone:leading-34px">
                                                            <div dir="ltr"
                                                                class="inline-block pro:h-52px air:h-52px pad:h-52px phone:h-34px overflow-hidden">
                                                                <ul class="flex">
                                                                    <li class="flex"><span
                                                                            class="flex flex-col transform transition-transform duration-900 ease-in-out"
                                                                            style="transform: translateY(0%);"><i
                                                                                class="not-italic">
                                                                                0
                                                                            </i><i class="not-italic">
                                                                                1
                                                                            </i><i class="not-italic">
                                                                                2
                                                                            </i><i class="not-italic">
                                                                                3
                                                                            </i><i class="not-italic">
                                                                                4
                                                                            </i><i class="not-italic">
                                                                                5
                                                                            </i><i class="not-italic">
                                                                                6
                                                                            </i><i class="not-italic">
                                                                                7
                                                                            </i><i class="not-italic">
                                                                                8
                                                                            </i><i class="not-italic">
                                                                                9
                                                                            </i></span></li>
                                                                    <li class="flex"><span>.</span></li>
                                                                    <li class="flex"><span
                                                                            class="flex flex-col transform transition-transform duration-900 ease-in-out"
                                                                            style="transform: translateY(0%);"><i
                                                                                class="not-italic">
                                                                                0
                                                                            </i><i class="not-italic">
                                                                                1
                                                                            </i><i class="not-italic">
                                                                                2
                                                                            </i><i class="not-italic">
                                                                                3
                                                                            </i><i class="not-italic">
                                                                                4
                                                                            </i><i class="not-italic">
                                                                                5
                                                                            </i><i class="not-italic">
                                                                                6
                                                                            </i><i class="not-italic">
                                                                                7
                                                                            </i><i class="not-italic">
                                                                                8
                                                                            </i><i class="not-italic">
                                                                                9
                                                                            </i></span></li>
                                                                    <li class="flex"><span
                                                                            class="flex flex-col transform transition-transform duration-900 ease-in-out"
                                                                            style="transform: translateY(0%);"><i
                                                                                class="not-italic">
                                                                                0
                                                                            </i><i class="not-italic">
                                                                                1
                                                                            </i><i class="not-italic">
                                                                                2
                                                                            </i><i class="not-italic">
                                                                                3
                                                                            </i><i class="not-italic">
                                                                                4
                                                                            </i><i class="not-italic">
                                                                                5
                                                                            </i><i class="not-italic">
                                                                                6
                                                                            </i><i class="not-italic">
                                                                                7
                                                                            </i><i class="not-italic">
                                                                                8
                                                                            </i><i class="not-italic">
                                                                                9
                                                                            </i></span></li>
                                                                </ul>
                                                            </div>
                                                            <div
                                                                class="ml-6px !text-40px align-bottom !phone:text-24px phone:align-middle bit-dropdown">
                                                                <span
                                                                    class="text-v3PrimaryText text-40px font-700 cursor-pointer flex items-center phone:text-24px bit-dropdown-selfdefine"
                                                                    aria-haspopup="list"
                                                                    aria-controls="dropdown-menu-2154" role="button"
                                                                    tabindex="0">
                                                                    BTC
                                                                    <svg xmlns="http://www.w3.org/2000/svg"
                                                                        viewBox="0 0 24 24" fill="currentColor"
                                                                        aria-hidden="true"
                                                                        class="w-6 h-6 !text-v3DisabledText ml-1">
                                                                        <path
                                                                            d="M20.03 9.53l-7.5 7.5a.75.75 0 01-1.06 0l-7.5-7.5a.75.75 0 011.06-1.06L12 15.44l6.97-6.97a.75.75 0 011.06 1.06z">
                                                                        </path>
                                                                    </svg></span>
                                                                <ul class="bit-dropdown-menu bit-popper bit-dropdown-menu--medium"
                                                                    id="dropdown-menu-2154" style="display: none;">
                                                                    <li tabindex="-1" class="bit-dropdown-menu__item">
                                                                        <!---->
                                                                        <div class="flex items-center gap-8px"><span>
                                                                                BTC
                                                                            </span></div>
                                                                    </li>
                                                                    <li tabindex="-1" class="bit-dropdown-menu__item">
                                                                        <!---->
                                                                        <div class="flex items-center gap-8px"><span>
                                                                                USDT
                                                                            </span></div>
                                                                    </li>
                                                                    <li tabindex="-1" class="bit-dropdown-menu__item">
                                                                        <!---->
                                                                        <div class="flex items-center gap-8px"><span>
                                                                                USD
                                                                            </span></div>
                                                                    </li>
                                                                    <li tabindex="-1" class="bit-dropdown-menu__item">
                                                                        <!---->
                                                                        <div class="flex items-center gap-8px"><span>
                                                                                More
                                                                            </span></div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </h1>
                                                        <div>
                                                            <p
                                                                class="text-v3PrimaryText opacity-60 text-16px mt-8px mb-10px phone:text-14px">
                                                                <span class="flex">
                                                                    ≈ 0.00 USD
                                                                </span>
                                                            </p> <!---->
                                                        </div>
                                                    </div>
                                                </div>
                                                <div
                                                    class="flex items-center flex-wrap hidden mt-24px !pro:hidden phone:mt-32px">
                                                    <button type="button"
                                                        class="bit-button !mb-12px bit-button--main bit-button--medium is-round"><!----><!----><!----><span>
                                                            Deposit
                                                        </span><!----></button> <!----> <button type="button"
                                                        class="bit-button !mb-12px bit-button--default bit-button--medium is-round"><!----><!----><!----><span>
                                                            Withdrawal
                                                        </span><!----></button> <!----> <button type="button"
                                                        class="bit-button !mb-12px !ml-8px bit-button--default bit-button--medium is-round"><!----><!----><!----><span>
                                                            Transfer
                                                        </span><!----></button>
                                                </div>
                                                <div
                                                    class="w-full float-right air:mt-20px air:w-full air:float-none pad:mt-20px pad:w-full pad:float-none phone:mt-8px phone:mb-20px phone:w-full phone:float-none">
                                                    <div class="text-right">
                                                        <div role="radiogroup" class="bit-radio-group is-round"><label
                                                                role="radio" aria-checked="true" tabindex="0"
                                                                class="bit-radio-button bit-radio-button--mini is-active"><input
                                                                    type="radio" tabindex="-1" autocomplete="off"
                                                                    class="bit-radio-button__orig-radio" value="1"><span
                                                                    class="bit-radio-button__inner bit-radio-button__roundinner">
                                                                    1D
                                                                    <!----></span></label> <label role="radio"
                                                                tabindex="-1"
                                                                class="bit-radio-button bit-radio-button--mini"><input
                                                                    type="radio" tabindex="-1" autocomplete="off"
                                                                    class="bit-radio-button__orig-radio" value="7"><span
                                                                    class="bit-radio-button__inner bit-radio-button__roundinner">
                                                                    1W
                                                                    <!----></span></label> <label role="radio"
                                                                tabindex="-1"
                                                                class="bit-radio-button bit-radio-button--mini"><input
                                                                    type="radio" tabindex="-1" autocomplete="off"
                                                                    class="bit-radio-button__orig-radio"
                                                                    value="30"><span
                                                                    class="bit-radio-button__inner bit-radio-button__roundinner">
                                                                    1M
                                                                    <!----></span></label> <label role="radio"
                                                                tabindex="-1"
                                                                class="bit-radio-button bit-radio-button--mini"><input
                                                                    type="radio" tabindex="-1" autocomplete="off"
                                                                    class="bit-radio-button__orig-radio"
                                                                    value="90"><span
                                                                    class="bit-radio-button__inner bit-radio-button__roundinner">
                                                                    3M
                                                                    <!----></span></label> <label role="radio"
                                                                tabindex="-1"
                                                                class="bit-radio-button bit-radio-button--mini"><input
                                                                    type="radio" tabindex="-1" autocomplete="off"
                                                                    class="bit-radio-button__orig-radio"
                                                                    value="180"><span
                                                                    class="bit-radio-button__inner bit-radio-button__roundinner">
                                                                    6M
                                                                    <!----></span></label></div>
                                                    </div>
                                                    <div data-v-f73601bc="" class="chart-container w-full h-154px"
                                                        _echarts_instance_="ec_1727248415162"
                                                        style="user-select: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); position: relative;">
                                                        <div
                                                            style="position: relative; width: 928px; height: 154px; padding: 0px; margin: 0px; border-width: 0px; cursor: default;">
                                                            <canvas data-zr-dom-id="zr_0" width="928" height="154"
                                                                style="position: absolute; left: 0px; top: 0px; width: 928px; height: 154px; user-select: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); padding: 0px; margin: 0px; border-width: 0px;"></canvas>
                                                        </div>
                                                        <!-- <div class=""
                                                            style="position: absolute; display: block; border-style: solid; white-space: nowrap; z-index: 9999999; box-shadow: rgba(0, 0, 0, 0.2) 1px 2px 10px; background-color: rgb(249, 251, 251); border-width: 1px; border-radius: 4px; color: rgb(65, 71, 71); font: 14px / 21px &quot;Microsoft YaHei&quot;; padding: 10px; top: 0px; left: 0px; transform: translate3d(789px, 80px, 0px); border-color: rgb(239, 241, 241); pointer-events: none; visibility: hidden; opacity: 0;">
                                                            09-24 20:00<br> 0.00 USD</div> -->
                                                    </div>
                                                </div>
                                            </div>
                                            <div data-v-45e2eb2e="" class="btns-375"><button data-v-45e2eb2e=""
                                                    type="button"
                                                    class="bit-button bit-button--main is-round"><!----><!----><!----><span>
                                                        Deposit
                                                    </span><!----></button> <!----> <button data-v-45e2eb2e=""
                                                    type="button"
                                                    class="bit-button bit-button--default is-round"><!----><!----><!----><span>
                                                        Withdrawal
                                                    </span><!----></button> <button data-v-45e2eb2e="" type="button"
                                                    class="bit-button bit-button--default is-round"><!----><!----><!----><span>
                                                        Transfer
                                                    </span><!----></button></div>
                                        </div>
                                    </div>
                                    <div data-v-8d17c708=""
                                        class="card-items-wrapper flex items-center justify-between">
                                        <div data-v-86dcdea4="" data-v-8d17c708=""
                                            class="sep-dashboard-coupons box-border max-h-360px h-360px p-24px box-border border-1 rounded-16px bg-v3levelsurface0 border-v3StrengthBorder0 card-item">
                                            <div data-v-86dcdea4=""
                                                class="text-20px font-700 leading-28px text-v3PrimaryText">
                                                Coupons
                                            </div>
                                            <div data-v-86dcdea4="" class="relative mt-8px mb-24px pt-30px pb-16px">
                                                <div data-v-86dcdea4=""
                                                    class="absolute top-0 left-0 w-full gap-8px box-border flex items-center justify-between px-8px py-4px rounded-4px bg-v3ContentLinkTransparency text-v3LinkDefaultText text-12px leading-12px cursor-pointer">
                                                    <div data-v-86dcdea4="" class="flex flex-wrap">
                                                        Complete tasks and get up to 30U in rewards!
                                                    </div> <i data-v-86dcdea4="" class="bit-icon rtl-rotate"
                                                        style="font-size: 16px;"><svg data-v-86dcdea4=""
                                                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                            fill="currentColor" aria-hidden="true">
                                                            <path
                                                                d="M17.03 12.53l-7.5 7.5a.75.75 0 11-1.06-1.06L15.44 12 8.47 5.03a.75.75 0 111.06-1.06l7.5 7.5a.75.75 0 010 1.06z">
                                                            </path>
                                                        </svg></i>
                                                </div>
                                                <div data-v-86dcdea4="">
                                                    <div data-v-86dcdea4=""
                                                        class="text-48px leading-58px font-700 text-v3PrimaryText">2
                                                    </div>
                                                    <div data-v-86dcdea4=""
                                                        class="mt-4px leading-20px text-v3SecondaryText">
                                                        Pending tasks
                                                    </div>
                                                </div>
                                            </div> <!----> <!---->
                                            <div data-v-86dcdea4="" class="h-60px leading-20px"></div>
                                            <div data-v-86dcdea4="" class="mt-18px"><button data-v-86dcdea4=""
                                                    type="button"
                                                    class="bit-button w-full mt-24px bit-button--default bit-button--medium is-round"><!----><!----><!----><span>
                                                        More
                                                    </span><!----></button></div>
                                        </div>
                                        <div data-v-5a3d3ec8="" data-v-8d17c708=""
                                            class="sep-dashboard-spent flex flex-col justify-between box-border max-h-360px h-360px p-24px box-border border-1 rounded-16px bg-v3levelsurface0 border-v3StrengthBorder0 card-item">
                                            <div data-v-5a3d3ec8=""
                                                class="text-20px font-700 leading-28px text-v3PrimaryText">
                                                Fees
                                            </div>
                                            <div data-v-5a3d3ec8=""
                                                class="sep-dashboard-spent-vip my-16px box-border max-h-196px px-16px py-16px rounded-8px cursor-pointer">
                                                <div data-v-5a3d3ec8="" class="flex items-center justify-between">
                                                    <div data-v-5a3d3ec8="" class="flex items-center relative"><!---->
                                                        <img data-v-5a3d3ec8="" width="20"
                                                            src="../assets/img/icon-viplevel-0.svg"> <span
                                                            data-v-5a3d3ec8=""
                                                            class="ml-8px text-16px font-700 leading-22px text-v3PrimaryText">
                                                            VIP 0
                                                        </span>
                                                    </div> <svg data-v-5a3d3ec8="" xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"
                                                        class="text-v3TertiaryText iconfont w-16px h-16px rtl-rotate">
                                                        <path
                                                            d="M17.03 12.53l-7.5 7.5a.75.75 0 11-1.06-1.06L15.44 12 8.47 5.03a.75.75 0 111.06-1.06l7.5 7.5a.75.75 0 010 1.06z">
                                                        </path>
                                                    </svg>
                                                </div>
                                                <div data-v-5a3d3ec8=""
                                                    class="vip0-content mt-10px leading-20px text-v3TertiaryText h-120px max-h-120px">
                                                    Join Bitget's VIP Program to receive exclusive perks. As a VIP on
                                                    Bitget, make trades with some of the lowest crypto trading fees on
                                                    the market and keep more of your profits.
                                                </div>
                                            </div>
                                            <div data-v-5a3d3ec8=""
                                                class="sep-dashboard-spent-vip px-16px py-16px rounded-8px flex items-center justify-between">
                                                <div data-v-5a3d3ec8=""
                                                    class="text-v3PrimaryText flex items-center flex-wrap"><span
                                                        data-v-5a3d3ec8="" class="bgb-fees-tips">Use BGB to offset
                                                        fees</span> <span data-v-5a3d3ec8=""
                                                        class="sep-dashboard-spent-bgb-tag text-v3PrimaryText"><span
                                                            data-v-5a3d3ec8="" dir="ltr" class=""><!---->-20%
                                                        </span></span></div>
                                                <div data-v-5a3d3ec8="" role="switch" class="bit-switch"><input
                                                        type="checkbox" name="" true-value="true"
                                                        class="bit-switch__input"><!----><span class="bit-switch__core"
                                                        style="width: 36px;"></span><!----></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div data-v-8d17c708=""
                                        class="card-items-wrapper flex items-center justify-between">
                                        <div data-v-48123b79="" data-v-8d17c708=""
                                            class="sep-dashboard-api box-border max-h-360px h-360px p-24px box-border border-1 rounded-16px bg-v3levelsurface0 border-v3StrengthBorder0 card-item">
                                            <div data-v-48123b79=""
                                                class="text-20px font-700 leading-28px text-v3PrimaryText">API keys
                                            </div>
                                            <div data-v-48123b79="" class="my-24px py-16px">
                                                <div data-v-48123b79=""
                                                    class="text-48px leading-58px font-700 text-v3PrimaryText">0</div>
                                                <div data-v-48123b79=""
                                                    class="mt-4px leading-20px text-v3SecondaryText">Keys</div>
                                            </div>
                                            <div data-v-48123b79="" class="h-60px text-v3TertiaryText leading-20px">
                                                Bitget provides you with a powerful API that can be used to query the
                                                market. Learn more by reading the <a
                                                    href="https://bitgetlimited.github.io/apidoc/en/mix/#welcome"
                                                    class="text-primary" target="_blank">API documentation</a>.
                                            </div>
                                            <div data-v-48123b79="" class="mt-18px"><button data-v-48123b79=""
                                                    type="button"
                                                    class="bit-button w-full bit-button--default bit-button--medium is-round"><!----><!----><!----><span>API
                                                        management</span><!----></button></div>
                                        </div>
                                        <div data-v-5ff42e9c="" data-v-8d17c708=""
                                            class="sep-dashboard-account box-border max-h-360px h-360px p-24px box-border border-1 rounded-16px bg-v3levelsurface0 border-v3StrengthBorder0 card-item">
                                            <div data-v-5ff42e9c=""
                                                class="text-20px font-700 leading-28px text-v3PrimaryText">Accounts
                                            </div>
                                            <div data-v-5ff42e9c="" class="mt-20px mb-24px py-16px">
                                                <div data-v-5ff42e9c=""
                                                    class="text-48px leading-58px font-700 text-v3PrimaryText">1</div>
                                                <div data-v-5ff42e9c="" class="leading-20px text-v3SecondaryText">
                                                    Accounts</div>
                                            </div>
                                            <div data-v-5ff42e9c="" class="my-24px h-62px flex items-center gap-24px">
                                                <div data-v-5ff42e9c="" class="sep-dashboard-account-sub-item">
                                                    <div data-v-5ff42e9c=""
                                                        class="text-32px leading-38px text-v3PrimaryText">1</div>
                                                    <div data-v-5ff42e9c=""
                                                        class="max-w-148px leading-20px text-v3TertiaryText truncate">
                                                        Main account</div>
                                                </div>
                                                <div data-v-5ff42e9c="">
                                                    <div data-v-5ff42e9c=""
                                                        class="text-32px leading-38px text-v3PrimaryText">0</div>
                                                    <div data-v-5ff42e9c=""
                                                        class="max-w-148px leading-20px text-v3TertiaryText truncate">
                                                        Sub-accounts</div>
                                                </div>
                                            </div> <button data-v-5ff42e9c="" type="button"
                                                class="bit-button w-full bit-button--default bit-button--medium is-round"><!----><!----><!----><span>Create</span><!----></button>
                                        </div>
                                    </div>
                                </div>
                                <div data-v-8d17c708="" class="dashboard-card-right mt-40px">
                                    <div data-v-8d17c708=""
                                        class="text-20px font-600 leading-28px text-v3PrimaryText mb-16px">
                                        Recommended for you
                                    </div>
                                    <div data-v-8d17c708=""
                                        class="right-banners minpc:grid minpc:grid-cols-[1fr,1fr] minpc:gap-16px pad:grid pad:grid-cols-[1fr,1fr] pad:gap-16px">
                                        <div data-v-8d17c708=""
                                            class="sep-dashboard-rewards box-border p-24px rounded-16px bg-v3SurfaceLightPurple cursor-pointer banner-items">
                                            <div class="flex justify-between">
                                                <div
                                                    class="sep-dashboard-rewards-title px-16px py-8px leading-20px rounded-full font-700">
                                                    Rewards Center</div> <!---->
                                            </div>
                                            <div class="mt-16px text-v3SecondaryText text-16px leading-22px">
                                                Limited-time: Earn more points and swap them for USDT!
                                            </div>
                                            <div class="mt-16px py-16px">
                                                <div class="flex gap-8px">
                                                    <div
                                                        class="p-10px text-v3InverseText text-24px font-700 bg-v3PrimaryText rounded-8px flex">
                                                        <span>05</span><span>D</span>
                                                    </div>
                                                    <div
                                                        class="p-10px text-v3InverseText text-24px font-700 bg-v3PrimaryText rounded-8px flex">
                                                        <span>00</span><span>H</span>
                                                    </div>
                                                    <div
                                                        class="p-10px text-v3InverseText text-24px font-700 bg-v3PrimaryText rounded-8px flex">
                                                        <span>08</span><span>M</span>
                                                    </div>
                                                </div>
                                                <div class="text-v3SecondaryText mt-8px leading-20px">Complete new user
                                                    tasks to get 1700 points.</div>
                                            </div>
                                            <div class="mt-16px sep-dashboard-animate-button"><button type="button"
                                                    class="bit-button w-full flex items-center justify-content bit-button--main bit-button--medium is-round"><!----><!----><!----><span><span
                                                            class="flex justify-center items-center"><span
                                                                class="inline-block max-w-200px truncate">Limited-time
                                                                perks!</span> <span
                                                                class="sep-dashboard-btn-icon-right flex"><svg
                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                    viewBox="0 0 24 24" fill="currentColor"
                                                                    aria-hidden="true"
                                                                    class="ml-8px icon-font w-16px h-16px rtl-rotate">
                                                                    <path
                                                                        d="M20.78 12.53l-6.75 6.75a.75.75 0 01-1.06-1.06l5.47-5.47H3.75a.75.75 0 110-1.5h14.69l-5.47-5.47a.75.75 0 111.06-1.06l6.75 6.75a.747.747 0 010 1.06z">
                                                                    </path>
                                                                </svg></span></span></span><!----></button></div>
                                        </div>
                                        <div data-v-175771fe="" data-v-8d17c708=""
                                            class="mt-16px banner-items minpc:mt-0 pad:mt-0">
                                            <div data-v-4f0fa8a2="" data-v-175771fe=""
                                                class="sep-dashboard-referrals box-border p-24px rounded-16px h-full cursor-pointer">
                                                <div data-v-4f0fa8a2="" class="flex justify-between">
                                                    <div data-v-4f0fa8a2=""
                                                        class="referrals-title px-16px py-8px leading-20px rounded-full font-700">
                                                        Referral
                                                    </div>
                                                </div>
                                                <div data-v-4f0fa8a2=""
                                                    class="mt-16px text-v3SecondaryText text-16px leading-22px">
                                                    Become a Premier Inviter and enjoy a 25% rebate
                                                </div>
                                                <div data-v-4f0fa8a2=""
                                                    class="mt-16px flex justify-between items-center minpc:h-100px pad:h-100px">
                                                    <div data-v-4f0fa8a2="">
                                                        <div data-v-4f0fa8a2=""
                                                            class="text-32px font-700 leading-38px text-v3PrimaryText">
                                                            M3C8Z5R6
                                                        </div>
                                                        <div data-v-4f0fa8a2=""
                                                            class="leading-20px text-v3SecondaryText">
                                                            Your referral code
                                                        </div>
                                                    </div> <svg data-v-4f0fa8a2="" xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"
                                                        class="iconfont w-20px h-20px text-v3PrimaryText">
                                                        <path
                                                            d="M20.25 3h-12a.75.75 0 00-.75.75V7.5H3.75a.75.75 0 00-.75.75v12a.75.75 0 00.75.75h12a.75.75 0 00.75-.75V16.5h3.75a.75.75 0 00.75-.75v-12a.75.75 0 00-.75-.75zM15 19.5H4.5V9H15v10.5zm4.5-4.5h-3V8.25a.75.75 0 00-.75-.75H9v-3h10.5V15z">
                                                        </path>
                                                    </svg>
                                                </div> <!---->
                                            </div>
                                        </div>
                                        <div data-v-7b66f01c="" data-v-8d17c708=""
                                            class="sep-dashboard-webwallet relative h-320px p-24px rounded-16px box-border cursor-pointer mt-16px banner-items minpc:mt-0 pad:mt-0">
                                            <div data-v-7b66f01c="" class="flex justify-between">
                                                <div data-v-7b66f01c=""
                                                    class="webwallet-title px-16px py-8px leading-20px rounded-full font-700 truncate">
                                                    Web3</div>
                                            </div>
                                            <div data-v-7b66f01c="" class="flex flex-col mt-16px">
                                                <div data-v-7b66f01c=""
                                                    class="text-24px leading-34px font-700 text-v3PrimaryText truncate">
                                                    Bitget Wallet</div>
                                                <div data-v-7b66f01c=""
                                                    class="mt-8px text-v3SecondaryText leading-20px">The gateway to
                                                    multi-chain ecosystems for global crypto users</div>
                                            </div>
                                            <div data-v-7b66f01c="" class="webwallet-download white">Download</div> <img
                                                data-v-7b66f01c="" width="120" height="94"
                                                src="../assets/img/webwallet-img.svg"
                                                class="webwallet-img">
                                        </div>
                                        <div data-v-7200b6e6="" data-v-8d17c708=""
                                            class="mt-16px banner-items minpc:mt-0 pad:mt-0" style="min-height: 0px;">
                                            <div data-v-7200b6e6=""
                                                class="sep-dashboard-trader-pro bg-v3BgInversePrimary relative h-320px p-24px rounded-16px box-border cursor-pointer white">
                                                <div data-v-7200b6e6=""
                                                    class="trader-pro-title text-24px leading-30px font-700 text-v3ContentAlwaysWhite">
                                                    Bitget <span>TraderPro</span> Program</div>
                                                <div data-v-7200b6e6=""
                                                    class="trader-pro-desc mt-8px leading-19px h-38px text-14px text-v3TertiaryText">
                                                    Get a <span>10,000 USDT</span> trading fund and double profit
                                                    sharing now!</div>
                                                <div data-v-7200b6e6="" class="mt-16px"><button data-v-7200b6e6=""
                                                        type="button" class="bit-button bit-button--main is-round"
                                                        style="color: rgb(31, 31, 31); background-color: rgb(0, 240, 255); border-color: rgb(0, 240, 255);"><!----><!----><!----><span>
                                                            Details
                                                        </span><!----></button></div> <img data-v-7200b6e6="" alt=""
                                                    loading="lazy" width="205" height="164"
                                                    src="../assets/img/trader-pro-img.svg"
                                                    class="absolute bottom-0 right-0">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
      <HzFooter></HzFooter>
</div>
</template>

<script>

import LeftDash  from "@/components/LeftDash.vue"; // 引入头部组件

export default {
    components: {
        LeftDash, // 注册头部组件
    },
};
</script>
<style></style>