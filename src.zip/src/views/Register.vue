<template>
  <div>
    <HzHeader></HzHeader>
    <div class="register-reg-wrap asia" data-v-40cac73a data-v-201148b6>
      <div class="register-reg-box" data-v-40cac73a>
        <div class="register-reg-content-left" data-v-40cac73a>
          <div data-v-40cac73a>
            <div data-v-0e6a890e data-v-40cac73a class="reg-box-default-banner">
              <div data-v-0e6a890e class="reg-box-default-banner__title">
                Get together, trade together
              </div>
              <p data-v-0e6a890e class="reg-box-default-banner__tips">Sign up and trade with the Pros!
              </p>
              <div data-v-0e6a890e class="reg-box-default-banner-img reg-box-default-banner__img"
                   style="background-image: url(../assets/img/big-banner-zh-CN.png);"></div>
            </div>
          </div>
          <div data-v-49ec4adf data-v-40cac73a class="join-telegram">
            <div data-v-49ec4adf class="join-telegram-logo-wrap"><img data-v-49ec4adf
                                                                      src="/baseasset/img/login/tg-black.svg" alt="icon"
                                                                      class="w-20px h-20px mr-2px inline-block" style="display: none;">
              <img
                  data-v-49ec4adf
                  src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAAiCAYAAADCp/A1AAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAJrSURBVHgBzVjRdeIwEFz7UkBogOfrIKkgpIJwFcRUcFwFcBWQVHB3HdDBuYP4M38RVGAagMyQNVEcA7YkTOY9xbKftBrPascKkXwhJEkyWK/XN1EUpbxFK9D/HcmZAWKXuKSbzeYO10HNkOJCzgRV7Q7kUtxeHhrbKUlbNbQBUtlkWjdKtlGtBuZkJB1V+wTMWwUnCXJXqtpY2qtWhzwYSaYUxCY+qu2BH0mmFKr9BKkxyLVRLZc3lZMGY4tYHEDV+v3+HxB7AcGpNE8rzfnXYrG4xtys4Zx2SvqkFOMzXEYGQJyJVvoxFBh+3II8UrpbiJ82LPag8e4RZ9pwLrfFfjMvybFKsYhrleaY+4PqacxJC4Jb+6klqcbLt019qhTzH+M4njJdLgQVH5UMaCEG80cojsyK7ULwnSQCJAgwQxuKJ6rqEXCBmRq7Cwz/XCDAf2nmVweD1ajHPT3Ts6FbUGO2SsYI8k88QPUQ4xoBM7EI8uV9CIqmmogRfIpg3xGUZI00B9W7XS6XYzu9un2e0L0SDyD2ouxvC0ctItVFhkjTEINupH4b0PcecX2wyVkEQ2wfYqfkwTJmxcubIqVPGrR5lZyEJyjqr3P2D35xdJ9l0gB0CAlEsFy+7AQ5U6mKLxIQcIodN6dTUAfI7ZsgJFl4PERIINiVTQRTUq3sVtrZ2D6EV7IEC41E1XN9cDqSBFMPg+cJaiTuqhr75qQ/s7Dq8WHgNrhvM8+ubOKk1e2oal590IkFgevfpnu1WtlEZz7ZQtWs+qBzMz+iqkGbVx9+kzOgAFar1bzX6zG12wMM/+WlyniJ5+r4V0RheWtrTJC+AAAAAElFTkSuQmCC"
                  alt="icon" class="w-20px h-20px mr-2px inline-block" style="display: none;"> <img
                  data-v-49ec4adf
                  src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAAiCAYAAADCp/A1AAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAJrSURBVHgBzVjRdeIwEFz7UkBogOfrIKkgpIJwFcRUcFwFcBWQVHB3HdDBuYP4M38RVGAagMyQNVEcA7YkTOY9xbKftBrPascKkXwhJEkyWK/XN1EUpbxFK9D/HcmZAWKXuKSbzeYO10HNkOJCzgRV7Q7kUtxeHhrbKUlbNbQBUtlkWjdKtlGtBuZkJB1V+wTMWwUnCXJXqtpY2qtWhzwYSaYUxCY+qu2BH0mmFKr9BKkxyLVRLZc3lZMGY4tYHEDV+v3+HxB7AcGpNE8rzfnXYrG4xtys4Zx2SvqkFOMzXEYGQJyJVvoxFBh+3II8UrpbiJ82LPag8e4RZ9pwLrfFfjMvybFKsYhrleaY+4PqacxJC4Jb+6klqcbLt019qhTzH+M4njJdLgQVH5UMaCEG80cojsyK7ULwnSQCJAgwQxuKJ6rqEXCBmRq7Cwz/XCDAf2nmVweD1ajHPT3Ts6FbUGO2SsYI8k88QPUQ4xoBM7EI8uV9CIqmmogRfIpg3xGUZI00B9W7XS6XYzu9un2e0L0SDyD2ouxvC0ctItVFhkjTEINupH4b0PcecX2wyVkEQ2wfYqfkwTJmxcubIqVPGrR5lZyEJyjqr3P2D35xdJ9l0gB0CAlEsFy+7AQ5U6mKLxIQcIodN6dTUAfI7ZsgJFl4PERIINiVTQRTUq3sVtrZ2D6EV7IEC41E1XN9cDqSBFMPg+cJaiTuqhr75qQ/s7Dq8WHgNrhvM8+ubOKk1e2oal590IkFgevfpnu1WtlEZz7ZQtWs+qBzMz+iqkGbVx9+kzOgAFar1bzX6zG12wMM/+WlyniJ5+r4V0RheWtrTJC+AAAAAElFTkSuQmCC"
                  alt="icon" class="w-20px h-20px mr-2px inline-block"></div>
            <div data-v-49ec4adf class="join-telegram-title">
              <p data-v-49ec4adf><a data-v-49ec4adf href="https://t.me/bitgetEN"
                                    class="font-500 mr-2px">
                Join Bitget Telegram now
              </a>
                <svg data-v-49ec4adf width="12" height="12" viewBox="0 0 12 12" fill="none"
                     xmlns="http://www.w3.org/2000/svg" class="rtl-rotate">
                  <g data-v-49ec4adf clip-path="url(#clip0_2633_63743)">
                    <path data-v-49ec4adf
                          d="M9.27411 5.41857L4.60836 0.627571L3.80211 1.41207L8.22186 5.95707C8.23322 5.9687 8.23958 5.98431 8.23958 6.00057C8.23958 6.01683 8.23322 6.03244 8.22186 6.04407L3.80211 10.5891L4.60836 11.3721L9.27336 6.58107C9.63261 6.22032 9.64836 5.79357 9.27411 5.41857Z"
                          fill="#1F1F1F"></path>
                  </g>
                  <defs data-v-49ec4adf>
                    <clipPath data-v-49ec4adf id="clip0_2633_63743">
                      <rect data-v-49ec4adf width="12" height="12" fill="white"
                            transform="translate(12 12) rotate(-180)"></rect>
                    </clipPath>
                  </defs>
                </svg>
                <svg data-v-49ec4adf width="12" height="12" viewBox="0 0 12 12" fill="none"
                     xmlns="http://www.w3.org/2000/svg" class="rtl-rotate" style="display: none;">
                  <g data-v-49ec4adf clip-path="url(#clip0_2633_63743)">
                    <path data-v-49ec4adf
                          d="M9.27411 5.41857L4.60836 0.627571L3.80211 1.41207L8.22186 5.95707C8.23322 5.9687 8.23958 5.98431 8.23958 6.00057C8.23958 6.01683 8.23322 6.03244 8.22186 6.04407L3.80211 10.5891L4.60836 11.3721L9.27336 6.58107C9.63261 6.22032 9.64836 5.79357 9.27411 5.41857Z"
                          fill="#fff"></path>
                  </g>
                  <defs data-v-49ec4adf>
                    <clipPath data-v-49ec4adf id="clip0_2633_63743">
                      <rect data-v-49ec4adf width="12" height="12" fill="white"
                            transform="translate(12 12) rotate(-180)"></rect>
                    </clipPath>
                  </defs>
                </svg>
              </p>
              <span data-v-49ec4adf class="text-share white">
                                Get help, share ideas, and receive firsthand Bitget news.
                            </span>
            </div>
          </div>
        </div>
        <div class="reg-content" data-v-40cac73a>
          <div class="reg-step-two-box" data-v-40cac73a>
            <div class="register-step reg-step-two show" data-v-22c2eca8 data-v-40cac73a>
              <h1 class="register-step-title" data-v-22c2eca8>
                Welcome to Bitget
              </h1>
              <div class="reg-form-box" data-v-22c2eca8>
                <div data-v-8ef6bb76 data-v-22c2eca8>
                  <div class="register-fir" data-v-8ef6bb76>
                    <div mobile email ismobile="true" data-v-08335308 data-v-8ef6bb76>
                      <div class="register-fir" data-v-08335308>
                        <div class="reg-form-group" data-v-08335308>
                          <label class="flex" data-v-08335308>
                                                  <span data-testid="RegisterEmailTabSelectButton"
                                                        data-v-08335308 class="label-switch">Email</span>
                            <span data-testid="RegisterMobileTabSelectButton"
                                  data-v-08335308>
                                                            Mobile
                                                        </span></label>
                        </div>
                        <div class="reg-form-group mb24" data-v-08335308>
                          <div class="reg-form-input" style="display:none;" data-v-08335308>
                            <label data-v-08335308>Mobile</label>
                            <div dir="ltr" class="reg-form-input-pos" data-v-08335308>
                                                            <span id="areaNumber"
                                                                  data-testid="RegisterAccountPhoneAreaSelect"
                                                                  class="area-list-area notranslate" data-v-08335308>
                                                                +852
                                                            </span> <i class="iconfont icon-next2"
                                                                       data-v-08335308></i>
                              <div class="area-list-split" data-v-08335308></div>
                            </div>
                            <div data-v-5a8f8d8d data-v-08335308
                                 class="register-step-area-list !pc:top-80px !atIpad:top-80px bit-theme-light-vue2 area-phone-box"
                                 style="top: 86px; display: none;">
                              <div data-v-5a8f8d8d
                                   class="ps-container area-phone-content ps ps--theme_default"
                                   data-ps-id="cc0fec4d-d348-7fab-349e-a7e24cdf115d"
                                   style="max-height: 280px;">
                                <div data-v-5a8f8d8d class="select-search-main">
                                  <div data-v-425c5e14 data-v-5a8f8d8d value
                                       class="select-search-wrap">
                                    <div data-v-425c5e14
                                         class="select-search-box"><span
                                        data-v-425c5e14
                                        class="select-search-prefix"><i
                                        data-v-425c5e14
                                        class="iconfont icon-sousuo rtl-rotate"></i></span>
                                      <input data-v-425c5e14 type="text"
                                             autocomplete="off" name="dnSearchStr"
                                             style="display: none; width: 0px; height: 0px;">
                                      <input data-v-425c5e14 autocomplete="off"
                                             type="text" name="dnSearchStr"
                                             placeholder="Search"
                                             class="select-search-input"></div>
                                  </div>
                                  <span data-v-5a8f8d8d class="close"><i
                                      data-v-5a8f8d8d
                                      class="iconfont icon-guanbi1"></i></span>
                                </div>
                                <ul data-v-5a8f8d8d>
                                  <li data-v-5a8f8d8d class="active"><span
                                      data-v-5a8f8d8d
                                      class="area-country">HongKong</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">852</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">China Mainland</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">86</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Albania</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">355</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Algeria</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">213</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Andorra</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">376</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Angola</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">244</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Antigua and
                                                                            Barbuda</span> <span data-v-5a8f8d8d
                                                                                                 class="area-num notranslate">1268</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Argentina</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">54</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Armenia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">374</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Australia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">61</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Austria</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">43</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Azerbaijan</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">994</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Commonwealth of the
                                                                            Bahamas</span> <span data-v-5a8f8d8d
                                                                                                 class="area-num notranslate">1242</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Bahrain</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">973</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Bangladesh</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">880</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Barbados</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">1246</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Belarus</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">375</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Belgium</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">32</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Belize</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">501</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Benin</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">229</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Bhutan</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">975</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Bolivia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">591</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Bosnia and
                                                                            Herzegovina</span> <span data-v-5a8f8d8d
                                                                                                     class="area-num notranslate">387</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Botswana</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">267</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Brazil</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">55</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Brunei</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">673</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Bulgaria</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">359</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Burkina Faso</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">226</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Burundi</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">257</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Cambodia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">855</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Cameroon</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">237</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Canada</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">1</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d class="area-country">Cape
                                                                            Verde</span> <span data-v-5a8f8d8d
                                                                                               class="area-num notranslate">238</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Chad</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">235</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Chile</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">56</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Colombia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">57</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Comoros</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">269</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Congo
                                                                            (Brazzaville)</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">242</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d class="area-country">Cook
                                                                            Islands</span> <span data-v-5a8f8d8d
                                                                                                 class="area-num notranslate">682</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Costa Rica</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">506</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d class="area-country">Côte
                                                                            Ivoire</span> <span data-v-5a8f8d8d
                                                                                                class="area-num notranslate">225</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Croatia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">385</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Cyprus</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">357</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Czech Republic</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">420</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Denmark</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">45</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Djibouti</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">253</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Dominica</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">1767</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Dominican
                                                                            Republic</span> <span data-v-5a8f8d8d
                                                                                                  class="area-num notranslate">1849</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Ecuador</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">593</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Egypt</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">20</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d class="area-country">El
                                                                            Salvador</span> <span data-v-5a8f8d8d
                                                                                                  class="area-num notranslate">503</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Equatorial
                                                                            Guinea</span> <span data-v-5a8f8d8d
                                                                                                class="area-num notranslate">240</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Eritrea</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">291</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Estonia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">372</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Ethiopia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">251</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Fiji</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">679</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Finland</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">358</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">France</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">33</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Gabon</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">241</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Gambia, The</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">220</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Georgia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">995</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Germany</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">49</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Ghana</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">233</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Greece</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">30</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Guadeloupe</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">590</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Guinea</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">224</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Guyana</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">592</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Honduras</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">504</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Hungary</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">36</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Iceland</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">354</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">India</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">91</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Indonesia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">62</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Ireland</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">353</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Israel</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">972</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Italy</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">39</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Jamaica</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">1876</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Japan</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">81</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Jordan</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">962</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Kazakhstan</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">7</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Kenya</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">254</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Kiribati</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">686</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Korea, South</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">82</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Kosovo</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">383</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Kuwait</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">965</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Kyrgyzstan</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">996</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Laos</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">856</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Latvia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">371</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Lesotho</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">266</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Liberia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">231</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Liechtenstein</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">423</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Lithuania</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">370</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Luxembourg</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">352</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Madagascar</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">261</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Malawi</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">265</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Malaysia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">60</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Maldives</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">960</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Mali</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">223</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Malta</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">356</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Marshall Islands</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">692</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Mauritania</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">222</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Mauritius</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">230</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Mexico</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">52</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Micronesia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">691</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Moldova</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">373</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Monaco</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">377</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Mongolia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">976</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Montenegro</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">382</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Morocco</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">212</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Mozambique</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">258</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Myanmar</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">95</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Namibia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">264</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Nauru</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">674</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Nepal</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">977</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Netherlands</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">31</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d class="area-country">New
                                                                            Zealand</span> <span data-v-5a8f8d8d
                                                                                                 class="area-num notranslate">64</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Nicaragua</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">505</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Niger</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">227</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Nigeria</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">234</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Niue</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">683</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Norway</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">47</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Oman</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">968</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Pakistan</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">92</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Palau</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">680</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Palestine</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">970</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Panama</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">507</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Papua New Guinea</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">675</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Paraguay</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">595</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Peru</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">51</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Philippines</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">63</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Poland</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">48</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Portugal</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">351</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Qatar</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">974</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Romania</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">40</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Russia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">7</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Rwanda</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">250</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Saint Christopher and
                                                                            Nevis</span> <span data-v-5a8f8d8d
                                                                                               class="area-num notranslate">1869</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Saint Lucia</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">1758</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Saint Vincent and the
                                                                            Grenadines</span> <span data-v-5a8f8d8d
                                                                                                    class="area-num notranslate">1784</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Samoa</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">685</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d class="area-country">San
                                                                            Marino</span> <span data-v-5a8f8d8d
                                                                                                class="area-num notranslate">378</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d class="area-country">São
                                                                            Tomé and Príncipe</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">239</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Saudi Arabia</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">966</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Senegal</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">221</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Serbia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">381</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Seychelles</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">248</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Sierra Leone</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">232</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Singapore</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">65</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Slovakia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">421</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Slovenia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">386</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Solomon Islands</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">677</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">South Africa</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">27</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Spain</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">34</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d class="area-country">Sri
                                                                            Lanka</span> <span data-v-5a8f8d8d
                                                                                               class="area-num notranslate">94</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Suriname</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">597</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Swaziland</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">268</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Sweden</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">46</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Switzerland</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">41</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Taiwan</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">886</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Tajikistan</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">992</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Tanzania</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">255</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Thailand</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">66</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Timor-Leste</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">670</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Togo</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">228</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Tonga</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">676</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Trinidad and
                                                                            Tobago</span> <span data-v-5a8f8d8d
                                                                                                class="area-num notranslate">1868</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Tunisia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">216</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Turkey</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">90</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Turkmenistan</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">993</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Tuvalu</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">688</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Uganda</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">256</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Ukraine</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">380</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">United Arab
                                                                            Emirates</span> <span data-v-5a8f8d8d
                                                                                                  class="area-num notranslate">971</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">United Kingdom</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">44</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Uruguay</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">598</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Uzbekistan</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">998</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Vanuatu</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">678</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Vatican City (the Holy
                                                                            See)</span> <span data-v-5a8f8d8d
                                                                                              class="area-num notranslate">379</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Venezuela</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">58</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Vietnam</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">84</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Western Sahara</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">210</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Zambia</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">260</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Zimbabwe</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">263</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Macao</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">853</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Gibraltar</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">350</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">British Virgin
                                                                            Islands</span> <span data-v-5a8f8d8d
                                                                                                 class="area-num notranslate">1284</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Anguilla</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">1264</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Aruba</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">297</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Åland Islands</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">35818</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Bermuda</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">1441</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Caribbean
                                                                            Netherlands</span> <span data-v-5a8f8d8d
                                                                                                     class="area-num notranslate">5997</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Curaçao</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">5999</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Faroe Islands
                                                                            (Føroyar)</span> <span data-v-5a8f8d8d
                                                                                                   class="area-num notranslate">298</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Grenada</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">1473</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">French Guiana (Guyane
                                                                            française)</span> <span data-v-5a8f8d8d
                                                                                                    class="area-num notranslate">594</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Greenland (Kalaallit
                                                                            Nunaat)</span> <span data-v-5a8f8d8d
                                                                                                 class="area-num notranslate">299</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Guatemala</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">502</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">British Indian Ocean
                                                                            Territory</span> <span data-v-5a8f8d8d
                                                                                                   class="area-num notranslate">246</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Cayman Islands</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">1345</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Macedonia (FYROM)
                                                                            (Македонија)</span> <span data-v-5a8f8d8d
                                                                                                      class="area-num notranslate">389</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Martinique</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">596</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Montserrat</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">1664</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d class="area-country">New
                                                                            Caledonia (Nouvelle-Calédonie)</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">687</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">French Polynesia
                                                                            (Polynésie française)</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">689</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Saint Pierre and
                                                                            Miquelon (Saint-Pierre-et-Miquelon)</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">508</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Saint Helena</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">290</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d class="area-country">Sint
                                                                            Maarten</span> <span data-v-5a8f8d8d
                                                                                                 class="area-num notranslate">1721</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Turks and Caicos
                                                                            Islands</span> <span data-v-5a8f8d8d
                                                                                                 class="area-num notranslate">1649</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Tokelau</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">690</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Dominican
                                                                            Republic</span> <span data-v-5a8f8d8d
                                                                                                  class="area-num notranslate">1809</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Dominican
                                                                            Republic</span> <span data-v-5a8f8d8d
                                                                                                  class="area-num notranslate">1829</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Other</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">1980</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Réunion (La
                                                                            Réunion)</span> <span data-v-5a8f8d8d
                                                                                                  class="area-num notranslate">262</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Puerto Rico</span>
                                    <span data-v-5a8f8d8d
                                          class="area-num notranslate">787</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d class="area-country">Isle
                                                                            of Man</span> <span data-v-5a8f8d8d
                                                                                                class="area-num notranslate">44</span>
                                  </li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Jersey</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">44</span></li>
                                  <li data-v-5a8f8d8d class><span
                                      data-v-5a8f8d8d
                                      class="area-country">Guernsey</span> <span
                                      data-v-5a8f8d8d
                                      class="area-num notranslate">44</span></li>
                                </ul>
                                <div class="ps__scrollbar-x-rail"
                                     style="left: 0px; bottom: 0px;">
                                  <div class="ps__scrollbar-x" tabindex="0"
                                       style="left: 0px; width: 0px;"></div>
                                </div>
                                <div class="ps__scrollbar-y-rail"
                                     style="top: 0px; right: 0px;">
                                  <div class="ps__scrollbar-y" tabindex="0"
                                       style="top: 0px; height: 0px;"></div>
                                </div>
                              </div>
                            </div>
                            <input type="text" name="dnPhone" autocomplete="off"
                                   placeholder="Mobile"
                                   data-testid="RegisterMobileAccountInput" value
                                   class="input-phone input-phone-asia" data-v-08335308>

                            <div class="show-pwd-str" data-v-08335308><span
                                class="clear-icon" data-v-08335308></span></div>
                          </div>
                          <div class="reg-form-input"
                               data-v-08335308>
                            <label data-v-08335308>Email</label>
                            <div class="register-email-input"
                                 data-v-e450a41a
                                 data-v-08335308>
                              <div class="phon-email-wrap" data-v-e450a41a>
                                <div class="login-form-input-pos" style="display:none;"
                                     data-v-e450a41a><span data-testid
                                                           class="area-list-area notranslate"
                                                           data-v-e450a41a>
                                                                        +
                                                                    </span> <i class="iconfont icon-next2"
                                                                               data-v-e450a41a></i>
                                  <div class="area-list-split" data-v-e450a41a>
                                  </div>
                                </div>
                                <input type="text" style="display: none; width: 0; height: 0" data-v-e450a41a>
                                <input type="text" autocomplete="off" placeholder="Email"
                                       class="input custom-register-input custom-register-input-asia"
                                       v-model="user.email"
                                       data-v-e450a41a>
                              </div>
                            </div>
                            <div class="show-pwd-str" data-v-08335308>
                              <span class="clear-icon" data-v-08335308></span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="reg-form-group mb24" data-v-8ef6bb76>
                      <div data-v-05f58ccf data-v-8ef6bb76>
                        <div class="reg-form-input" data-v-05f58ccf>
                          <label data-v-05f58ccf>Password</label>
                          <input autocomplete="new-password" maxlength="32"
                                 placeholder="Set password"
                                 type="password" class="pwd-input pwd-input-asia"
                                 v-model="user.password"
                                 data-v-05f58ccf>
                        </div>
                        <div class="show-pwd-str pwd-eye" data-v-05f58ccf>
                          <img src="../assets/img/EyeClosed.627bf67.svg" alt="login-EyeClosed" data-v-05f58ccf>
                        </div>
                      </div>
                    </div>
                    <div claccodearg data-v-5d6e290d data-v-8ef6bb76>
                      <div class="register-fir" data-v-5d6e290d>
                        <div class="reg-form-group mb24" data-v-5d6e290d><label
                            data-testid="RegisterShowInviteCodeInputButton"
                            class="invite-label" data-v-5d6e290d>
                          Referral code
                          <i class="iconfont icon-next2" data-v-5d6e290d></i></label>
                          <div class="reg-form-input" data-v-5d6e290d><input type="text"
                                                                             style="display: none; width: 0; height: 0"
                                                                             data-v-5d6e290d>
                            <div class="caps-lock-tip" style="display:none;"
                                 data-v-5d6e290d><img
                                src="/baseasset/img/register/warn-icon.svg"
                                alt="register-warn-icon" data-v-5d6e290d>
                              <p data-v-5d6e290d>Caps Lock on.</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="reg-protocol clearfix flex flex-col items-start" data-v-8ef6bb76>
                      <div class="flex items-center gap-8px" data-v-8ef6bb76>
                        <div class="bit-theme-light-vue2" data-v-8ef6bb76>
                          <div class="flex" data-v-8ef6bb76>
                            <label class="bit-checkbox is-checked" data-v-8ef6bb76>
                              <span class="bit-checkbox__input is-main" :class="{'is-checked': isAgreeUserAgreement}">
                                <span class="bit-checkbox__inner"></span>
                                <input type="checkbox" class="bit-checkbox__original" @click="isAgreeUserAgreement = !isAgreeUserAgreement" v-model="isAgreeUserAgreement">
                              </span>
                            </label>
                            <p class="user-protocol items-center ml-8px relative top-2px" data-v-8ef6bb76>I have read and agreed to the
                              <a href="/support/articles/360014944032-Terms-of-Users" target="_blank">User Agreement</a>
                            </p>
                          </div>

                          <div class="flex items-center mt-8px" data-v-8ef6bb76>
                            <label class="bit-checkbox is-checked" data-v-8ef6bb76>
                              <span class="bit-checkbox__input is-main" :class="{'is-checked': isAgreePrivatePolicy}">
                                <span class="bit-checkbox__inner"></span>
                                <input type="checkbox" class="bit-checkbox__original" @click="isAgreePrivatePolicy" v-model="isAgreePrivatePolicy">
                              </span>
                            </label>
                            <p class="user-protocol ml-8px relative top-2px" data-v-8ef6bb76>
                              I have read and agreed to the
                              <a href="/kr-policy" target="_blank">Privacy Policy</a>
                            </p>
                          </div>

                          <div class="flex items-center mt-8px" data-v-8ef6bb76>
                            <label class="bit-checkbox is-checked" data-v-8ef6bb76>
                              <span class="bit-checkbox__input is-main" :class="{'is-checked': isAdult}">
                                <span class="bit-checkbox__inner"></span>
                                <input type="checkbox" class="bit-checkbox__original" @click="isAdult = !isAdult" v-model="isAdult">
                              </span>
                            </label>
                            <p class="ml-8px relative top-2px" data-v-8ef6bb76>
                              I am above 18 years old.
                            </p></div>
                        </div>
                      </div>
                    </div>
                    <div class="bit-theme-light-vue2" data-v-8ef6bb76>
                      <div class="mt-24px" data-v-8ef6bb76>
                        <button disable="false"
                                type="button"
                                class="bit-button w-full bit-button--chunky bit-button--medium is-round"
                                :class="{'is-disabled': false}"
                                style="box-shadow:0 4px 0 0;"
                                @click="registerFn"
                                data-v-8ef6bb76>
                          <span>Create Account</span>
                        </button>
                      </div>
                    </div>
                  </div>
                  <div data-v-6d60a60a data-v-8ef6bb76
                       class="bit-dialog__wrapper is-centered is-responsive" style="display: none;">
                    <div role="dialog" aria-modal="true" aria-label="Privacy Policy"
                         class="bit-dialog tips-dialog bit-theme-light-vue2"
                         style="margin-top: 15vh; width: 600px;">
                      <div class="bit-dialog__header">
                        <span class="bit-dialog__title">Privacy Policy</span>
                        <button type="button" aria-label="Close"
                                class="bit-dialog__headerbtn">
                          <i class="bit-icon" style="font-size: 20px;">
                            <svg xmlns="http://www.w3.org/2000/svg"
                                 viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                              <path d="M19.28 18.22a.75.75 0 01-.817 1.223.75.75 0 01-.244-.162L12 13.06l-6.22 6.22a.75.75 0 01-1.06-1.062L10.94 12 4.72 5.78a.75.75 0 111.06-1.06L12 10.94l6.22-6.22a.75.75 0 011.06 1.06L13.06 12l6.22 6.22z">
                              </path>
                            </svg>
                          </i>
                        </button>
                      </div>
                      <div class="bit-dialog__footer">
                        <div data-v-6d60a60a class="dialog-footer">
                          <div data-v-6d60a60a class="ltIpad:hidden">
                            <button
                                data-v-6d60a60a type="button"
                                class="bit-button cancel-btn bit-button--default bit-button--medium is-round"><span>
                                                                Cancel
                                                            </span></button>
                            <button data-v-6d60a60a
                                    disabled="disabled" type="button"
                                    class="bit-button confirm-btn bit-button--main bit-button--medium is-disabled is-round"><span>
                                                                Scroll down to continue
                                                            </span></button>
                          </div>
                          <div data-v-6d60a60a
                               class="ltIpad:block atIpad:hidden pc:hidden w-full">
                            <button
                                data-v-6d60a60a disabled="disabled" type="button"
                                class="bit-button confirm-btn w-full bit-button--main bit-button--medium is-disabled is-round"><span>
                                                                Scroll down to continue
                                                            </span></button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-22c2eca8 class="light">
                  <div data-v-22c2eca8 class="go-login-tips mt-12px">
                    Already have an account?
                    <span data-v-22c2eca8 data-testid="RegisterGoLoginPageButton"
                          class="go-login">
                                            Log in
                                        </span>
                  </div>
                </div>
              </div>
              <div data-v-4e3dae4e data-v-22c2eca8
                   class="bit-dialog__wrapper is-centered is-notitle" style="display: none;">
                <div role="dialog" aria-modal="true" aria-label="dialog"
                     class="bit-dialog bit-dialog--center bit-theme-light-vue2"
                     style="margin-top: 15vh;">
                  <div class="bit-dialog__header"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import HzHeader from "@/components/HzHeader.vue";
import axios from "axios"; // 引入头部组件

export default {
  components: {
    HzHeader, // 注册头部组件
  },
  data() {
    return {
      isAgreeUserAgreement: false,
      isAgreePrivatePolicy: false,
      isAdult: false,
      user: {
        email: '',
        phone: '',
        password: ''
      }
    }
  },
  methods: {
    async registerFn() {
      const res = await axios.post('https://bitgetend.hzdev.top/api/register', {
        user_email: this.user.email,
        user_password: this.user.password
      })
      console.log(res)
      console.log('注册....')
    }
  }
};


</script>
<style></style>