<template>
  <div id="__next">
    <div>
      <div>
        <div class="css-1eqkoyn bit-app">
          <div>
            <HzHeader></HzHeader>
            <div class="micro micro-light" data-micro-type="DialogProvider" data-micro-id="56158978">
              <microteleport>
                <div class="mi-overlay" style="z-index: 2004; display: none;">
                  <div role="dialog" aria-modal="true" aria-label="User Agreement" aria-describedby="mi-id-3180-4" class="mi-overlay-dialog" style="display: flex;"></div>
                </div>
              </microteleport>
            </div>
            <main>
              <div>
                <div class="flex h-full w-full flex-col bg-ds-color-background-primary md:flex-row">
                  <div class="submenu">
                    <div id="bit-menu-main" class="bit-menu-main css-1eqkoyn bit-menu-main-light">
                      <ul class="bit-menu-primary bit-menu-primary-root bit-menu-primary-inline bit-menu-primary-light css-1eqkoyn css-1eqkoyn" dir="ltr" role="menu" tabindex="0" data-menu-list="true">
                        <li class="bit-menu-primary-item" role="menuitem" tabindex="-1" data-menu-id="rc-menu-uuid-79891-1-1" style="padding-left: 14px;">
                          <svg width="1em" height="1em" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="bit-menu-primary-item-icon">
                            <path d="M10 1.875A8.125 8.125 0 1 0 18.125 10 8.133 8.133 0 0 0 10 1.875Zm0 15A6.875 6.875 0 1 1 16.875 10 6.883 6.883 0 0 1 10 16.875Zm3.47-11.184-5 2.5a.629.629 0 0 0-.28.28l-2.5 5a.625.625 0 0 0 .84.838l5-2.5a.629.629 0 0 0 .28-.28l2.5-5a.625.625 0 0 0-.84-.838Zm-2.689 5.09-3.133 1.571 1.57-3.133 3.137-1.568-1.574 3.13Z" fill="#1F1F1F"></path>
                          </svg>
                          <span class="bit-menu-primary-title-content"><a class="!text-ds-color-text-primary" href="/asia/dashboard" rel="noopener noreferrer">Dashboard</a></span>
                        </li>
                        <li class="bit-menu-primary-item" role="menuitem" tabindex="-1" data-menu-id="rc-menu-uuid-79891-1-2" style="padding-left: 14px;">
                          <svg width="1em" height="1em" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="bit-menu-primary-item-icon">
                            <path d="M9.802 1.699a.625.625 0 0 1 .396 0l6.875 2.291a.625.625 0 0 1 .427.593V8.75c0 2.136-.922 4.2-2.269 5.875-1.347 1.675-3.158 3.01-5.02 3.672a.626.626 0 0 1-.42 0C7.93 17.636 6.118 16.3 4.77 14.625 3.422 12.95 2.5 10.886 2.5 8.75V4.583c0-.269.172-.507.427-.593L9.802 1.7ZM3.75 5.034V8.75c0 1.78.774 3.575 1.993 5.092 1.167 1.45 2.707 2.6 4.258 3.2 1.55-.6 3.09-1.75 4.256-3.2 1.22-1.517 1.993-3.313 1.993-5.092V5.034L10 2.95 3.75 5.034Z" fill="#0D0E0E"></path>
                            <path d="M13.775 7.058a.625.625 0 0 1 0 .884l-4.167 4.167a.625.625 0 0 1-.883 0l-2.5-2.5a.625.625 0 0 1 .883-.884l2.058 2.058 3.725-3.725a.625.625 0 0 1 .884 0Z" fill="#0D0E0E"></path>
                          </svg>
                          <span class="bit-menu-primary-title-content"><a class="!text-ds-color-text-primary" href="/asia/account/setting" rel="noopener noreferrer">Security</a></span>
                        </li>
                        <li class="bit-menu-primary-item bit-menu-primary-item-selected" role="menuitem" tabindex="-1" data-menu-id="rc-menu-uuid-79891-1-3" style="padding-left: 14px;">
                          <svg width="1em" height="1em" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="bit-menu-primary-item-icon">
                            <path d="M15.625 8.75a.625.625 0 0 1-.625.625h-3.125a.625.625 0 1 1 0-1.25H15a.625.625 0 0 1 .625.625ZM15 10.625h-3.125a.624.624 0 1 0 0 1.25H15a.624.624 0 1 0 0-1.25Zm3.125-6.25v11.25a1.25 1.25 0 0 1-1.25 1.25H3.125a1.25 1.25 0 0 1-1.25-1.25V4.375a1.25 1.25 0 0 1 1.25-1.25h13.75a1.25 1.25 0 0 1 1.25 1.25Zm-1.25 11.25V4.375H3.125v11.25h13.75Zm-6.27-2.656a.625.625 0 0 1-1.211.312c-.206-.801-1.02-1.406-1.895-1.406-.874 0-1.688.605-1.894 1.406a.625.625 0 0 1-1.211-.312 3.113 3.113 0 0 1 1.343-1.824 2.5 2.5 0 1 1 3.525 0 3.107 3.107 0 0 1 1.343 1.824ZM7.5 10.625a1.25 1.25 0 1 0 0-2.5 1.25 1.25 0 0 0 0 2.5Z" fill="#1F1F1F"></path>
                          </svg>
                          <span class="bit-menu-primary-title-content"><a class="!text-ds-color-text-primary" href="/asia/verified/enter" rel="noopener noreferrer">Identity verification</a></span>
                        </li>
                        <li class="bit-menu-primary-item" role="menuitem" tabindex="-1" data-menu-id="rc-menu-uuid-79891-1-4" style="padding-left: 14px;">
                          <svg width="1em" height="1em" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="bit-menu-primary-item-icon">
                            <path d="M17.75 8.162a1.25 1.25 0 0 0 1-1.224V5a1.25 1.25 0 0 0-1.25-1.25h-15A1.25 1.25 0 0 0 1.25 5v1.938a1.25 1.25 0 0 0 1 1.224 1.875 1.875 0 0 1 0 3.672 1.25 1.25 0 0 0-1 1.228V15a1.25 1.25 0 0 0 1.25 1.25h15A1.25 1.25 0 0 0 18.75 15v-1.938a1.25 1.25 0 0 0-1-1.224 1.875 1.875 0 0 1 0-3.672v-.004Zm-15.25 4.9a3.125 3.125 0 0 0 0-6.124V5h4.375v10H2.5v-1.938Zm15 0V15H8.125V5H17.5v1.938a3.125 3.125 0 0 0 0 6.124Z" fill="#1F1F1F"></path>
                          </svg>
                          <span class="bit-menu-primary-title-content"><a class="!text-ds-color-text-primary" href="/asia/account/coupon" rel="noopener noreferrer">Coupons</a></span>
                        </li>
                        <li class="bit-menu-primary-item" role="menuitem" tabindex="-1" data-menu-id="rc-menu-uuid-79891-1-5" style="padding-left: 14px;">
                          <svg width="1em" height="1em" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="bit-menu-primary-item-icon">
                            <path d="M18.125 4.375H16.25V3.75A1.25 1.25 0 0 0 15 2.5H5a1.25 1.25 0 0 0-1.25 1.25v.625H1.875a1.25 1.25 0 0 0-1.25 1.25v1.25A3.125 3.125 0 0 0 3.75 10h.285a6.26 6.26 0 0 0 5.34 4.345v1.905H7.5a.625.625 0 1 0 0 1.25h5a.624.624 0 1 0 0-1.25h-1.875v-1.908c2.495-.252 4.566-2.003 5.319-4.342h.306a3.125 3.125 0 0 0 3.125-3.125v-1.25a1.25 1.25 0 0 0-1.25-1.25ZM3.75 8.75a1.875 1.875 0 0 1-1.875-1.875v-1.25H3.75v2.5c0 .208.01.417.03.625h-.03ZM15 8.055c0 2.775-2.226 5.05-4.962 5.07H10a5 5 0 0 1-5-5V3.75h10v4.305Zm3.125-1.18A1.875 1.875 0 0 1 16.25 8.75h-.04c.027-.23.04-.463.04-.695v-2.43h1.875v1.25Z" fill="#1F1F1F"></path>
                          </svg>
                          <span class="bit-menu-primary-title-content"><a class="!text-ds-color-text-primary" href="/asia/account/myevents" rel="noopener noreferrer">My promotions</a></span>
                        </li>
                        <li class="bit-menu-primary-item" role="menuitem" tabindex="-1" data-menu-id="rc-menu-uuid-79891-1-6" style="padding-left: 14px;">
                          <svg width="1em" height="1em" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="bit-menu-primary-item-icon">
                            <path d="M6.5 13.625a.624.624 0 0 0 .875-.125 4.062 4.062 0 0 1 6.5 0 .623.623 0 0 0 .875.125.623.623 0 0 0 .125-.875 5.302 5.302 0 0 0-2.14-1.694 3.125 3.125 0 1 0-4.215 0c-.85.367-1.59.951-2.145 1.694a.625.625 0 0 0 .124.875ZM8.75 8.75a1.875 1.875 0 1 1 3.75 0 1.875 1.875 0 0 1-3.75 0Zm7.5-6.875H5a1.25 1.25 0 0 0-1.25 1.25V5H2.5a.625.625 0 0 0 0 1.25h1.25v3.125H2.5a.625.625 0 0 0 0 1.25h1.25v3.125H2.5a.625.625 0 1 0 0 1.25h1.25v1.875A1.25 1.25 0 0 0 5 18.125h11.25a1.25 1.25 0 0 0 1.25-1.25V3.125a1.25 1.25 0 0 0-1.25-1.25Zm0 15H5V3.125h11.25v13.75Z" fill="#1F1F1F"></path>
                          </svg>
                          <span class="bit-menu-primary-title-content"><a class="!text-ds-color-text-primary" href="/asia/asset/addressBook" rel="noopener noreferrer">Address book</a></span>
                        </li>
                        <li class="bit-menu-primary-item" role="menuitem" tabindex="-1" data-menu-id="rc-menu-uuid-79891-1-7" style="padding-left: 14px;">
                          <svg width="1em" height="1em" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="bit-menu-primary-item-icon">
                            <path d="m4.558 7.942-2.5-2.5a.625.625 0 0 1 0-.884l2.5-2.5a.625.625 0 1 1 .884.884L3.384 5l2.058 2.058a.625.625 0 0 1-.884.884Zm3.125 0a.625.625 0 0 0 .884 0l2.5-2.5a.626.626 0 0 0 0-.884l-2.5-2.5a.625.625 0 1 0-.884.884L9.74 5 7.683 7.058a.625.625 0 0 0 0 .884Zm7.942-4.817H13.75a.625.625 0 1 0 0 1.25h1.875v11.25H4.375v-5a.625.625 0 0 0-1.25 0v5a1.25 1.25 0 0 0 1.25 1.25h11.25a1.25 1.25 0 0 0 1.25-1.25V4.375a1.25 1.25 0 0 0-1.25-1.25Z" fill="#1F1F1F"></path>
                          </svg>
                          <span class="bit-menu-primary-title-content"><a class="!text-ds-color-text-primary" href="/asia/account/newapi" rel="noopener noreferrer">API keys</a></span>
                        </li>
                        <li class="bit-menu-primary-item" role="menuitem" tabindex="-1" data-menu-id="rc-menu-uuid-79891-1-8" style="padding-left: 14px;">
                          <svg width="1em" height="1em" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="bit-menu-primary-item-icon">
                            <path d="M19.125 11.75a.623.623 0 0 1-.875-.125A4.03 4.03 0 0 0 15 10a.625.625 0 0 1 0-1.25 1.875 1.875 0 1 0-1.815-2.344.625.625 0 1 1-1.211-.312A3.125 3.125 0 1 1 17.11 9.18c.85.368 1.588.952 2.143 1.694a.624.624 0 0 1-.128.876Zm-4.21 4.813a.625.625 0 1 1-1.08.625 4.453 4.453 0 0 0-7.67 0 .625.625 0 1 1-1.08-.625 5.63 5.63 0 0 1 2.636-2.338 3.75 3.75 0 1 1 4.559 0 5.63 5.63 0 0 1 2.636 2.338ZM10 13.75a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5ZM5.625 9.375A.625.625 0 0 0 5 8.75a1.875 1.875 0 1 1 1.816-2.344.625.625 0 1 0 1.21-.312A3.125 3.125 0 1 0 2.892 9.18a5.308 5.308 0 0 0-2.14 1.694.625.625 0 0 0 1 .751A4.03 4.03 0 0 1 5 10a.625.625 0 0 0 .624-.625Z" fill="#1F1F1F"></path>
                          </svg>
                          <span class="bit-menu-primary-title-content"><a class="!text-ds-color-text-primary" href="/asia/account/sub-account" rel="noopener noreferrer">Sub-account</a></span>
                        </li>
                        <li class="bit-menu-primary-item" role="menuitem" tabindex="-1" data-menu-id="rc-menu-uuid-79891-1-9" style="padding-left: 14px;">
                          <svg width="1em" height="1em" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="bit-menu-primary-item-icon">
                            <path d="M3.125 6.875h2.578a2.5 2.5 0 0 0 4.844 0h6.328a.625.625 0 1 0 0-1.25h-6.328a2.5 2.5 0 0 0-4.844 0H3.125a.625.625 0 0 0 0 1.25Zm5-1.875a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5Zm8.75 8.125h-1.328a2.5 2.5 0 0 0-4.844 0H3.125a.625.625 0 0 0 0 1.25h7.578a2.5 2.5 0 0 0 4.844 0h1.328a.625.625 0 1 0 0-1.25ZM13.125 15a1.25 1.25 0 1 1 0-2.501 1.25 1.25 0 0 1 0 2.501Z" fill="#1F1F1F"></path>
                          </svg>
                          <span class="bit-menu-primary-title-content"><a class="!text-ds-color-text-primary" href="/asia/account/preference" rel="noopener noreferrer">Settings</a></span>
                        </li>
                      </ul>
                      <div aria-hidden="true" style="display: none;">
                        <div class="bit-menu-main-collapse-icon" eventkey="tmp_key-9">
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                            <path d="M15.53 18.97a.75.75 0 11-1.06 1.06l-7.5-7.5a.75.75 0 010-1.06l7.5-7.5a.75.75 0 111.06 1.06L8.56 12l6.97 6.97z"></path>
                          </svg>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="flex flex-auto  flex-col px-[16px] pb-[16px] pt-[16px] md:px-[24px] md:pb-[80px] md:pt-[40px]">
                    <div class="mb-[16px]">
                      <nav class="bit-breadcrumb css-1eqkoyn">
                        <ol>
                          <li>
                            <span class="bit-breadcrumb-link"><a class="text-[12px] !text-ds-color-text-secondary hover:!bg-transparent hover:!text-ds-color-text-secondary">Bitget</a></span>
                          </li>
                          <li class="bit-breadcrumb-separator" aria-hidden="true">/</li>
                          <li>
                            <span class="bit-breadcrumb-link"><a class="text-[12px] !text-ds-color-text-secondary hover:!bg-transparent hover:!text-ds-color-text-secondary">Account</a></span>
                          </li>
                          <li class="bit-breadcrumb-separator" aria-hidden="true">/</li>
                          <li>
                            <span class="bit-breadcrumb-link"><span class="text-[12px] text-ds-color-text-primary">Identity verification</span></span>
                          </li>
                        </ol>
                      </nav>
                    </div>
                    <div class="flex items-center justify-between">
                      <div class="font-700 leading-40px truncate text-fs32 font-medium text-ds-color-text-primary">Individual verification</div>
                      <div>
                        <div class="flex cursor-pointer items-center rounded-[48px] border-[1px] border-solid border-ds-color-background-secondary bg-ds-color-background-secondary p-[4px] text-[14px] mobile:hidden">
                          <div class="rounded-[48px] px-[24px] py-[5px] text-[14px] text-ds-color-text-primary">Business verification</div>
                          <div class="rounded-[48px] px-[24px] py-[5px] text-[14px] text-ds-color-text-primary bg-ds-color-background-primary">Individual verification</div>
                        </div>
                        <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik04LjgwMDE0IDkuOTMzNUM4LjQwMDE0IDEwLjQ2NjggNy42MDAxNCAxMC40NjY4IDcuMjAwMTQgOS45MzM1TDQuNzAwMTQgNi42MDAxNkM0LjIwNTcxIDUuOTQwOTMgNC42NzYwOSA1LjAwMDE2IDUuNTAwMTQgNS4wMDAxNkgxMC41MDAxQzExLjMyNDIgNS4wMDAxNiAxMS43OTQ2IDUuOTQwOTMgMTEuMzAwMSA2LjYwMDE2TDguODAwMTQgOS45MzM1WiIgZmlsbD0iIzFGMUYxRiIvPgo8L3N2Zz4K" class="md:hidden" alt="">
                      </div>
                    </div>
                    <div class="bit-spin-nested-loading css-1eqkoyn">
                      <div class="bit-spin-container">
                        <div class="mt-[32px] flex middle:flex-col">
                          <div class="flex-1">
                            <div class="flex-auto rounded-[16px] border-[1px] border-solid border-ds-color-border-subtle p-[16px] md:border-[1px] md:p-[32px] xl:mr-[16px]">
                              <div class="w-auto max-w-[484px] 2xl:w-[484px]">
                                <div class="flex items-center justify-between">
                                  <div class="flex cursor-pointer items-center mobile:flex-wrap">
                                    <div class="text-[18px] font-semibold text-ds-color-text-primary">Level 1 identity verification</div>
                                    <div class="ml-[4px] rounded-[4px] px-[6px] py-[3px] text-[12px] mobile:ml-[0px]  text-ds-color-text-inverse-primary">
                                      <div></div>
                                    </div>
                                  </div>
                                </div>
                                <div class="mb-[20px] mt-[8px] flex items-center text-[14px] leading-[22px] text-[var(--content-tertiary)]">To comply with local laws and regulations, please complete identity verification to access all services.</div>
                                <div>
                                  <div class="mt-[12px] rounded-[10px] bg-ds-color-background-secondary text-[14px] mobile:p-[16px] ipad:p-[32px] air:p-[32px] pc:p-[32px]">
                                    <div>
                                      <div class="inline-flex w-full items-center text-[16px] font-medium text-ds-color-text-primary">Account perks after verification</div>
                                      <div>
                                        <div class="mt-[12px] flex text-[14px]">
                                          <div class="w-[50%] text-[14px] text-ds-color-text-tertiary">Withdrawals</div>
                                          <div class="w-[50%] text-[14px] text-right font-medium text-ds-color-text-primary">
                                            <img class="float-right" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHZpZXdCb3g9IjAgMCAxOCAxOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGcgaWQ9IlByb2hpYml0Ij4KPGNpcmNsZSBpZD0iRWxsaXBzZSA3MzQ1IiBjeD0iOS4wMDAyNyIgY3k9IjguOTk5OTkiIHI9IjcuMjcyNzMiIHN0cm9rZT0iIzBFQ0I4MSIgc3Ryb2tlLXdpZHRoPSIyIi8+CjxwYXRoIGlkPSJSZWN0YW5nbGUgMzQ2MjU0NDkiIGQ9Ik0xMi43NzE4IDcuMjAzMjFMOC42NTc3MSAxMS4zMTczTDUuODI5MjggOC40ODg4NiIgc3Ryb2tlPSIjMEVDQjgxIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPgo8L2c+Cjwvc3ZnPgo=" alt="">
                                          </div>
                                        </div>
                                        <div class="mt-[12px] flex text-[14px]">
                                          <div class="w-[50%] text-[14px] text-ds-color-text-tertiary">Crypto deposit</div>
                                          <div class="w-[50%] text-[14px] text-right font-medium text-ds-color-text-primary">
                                            <img class="float-right" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHZpZXdCb3g9IjAgMCAxOCAxOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGcgaWQ9IlByb2hpYml0Ij4KPGNpcmNsZSBpZD0iRWxsaXBzZSA3MzQ1IiBjeD0iOS4wMDAyNyIgY3k9IjguOTk5OTkiIHI9IjcuMjcyNzMiIHN0cm9rZT0iIzBFQ0I4MSIgc3Ryb2tlLXdpZHRoPSIyIi8+CjxwYXRoIGlkPSJSZWN0YW5nbGUgMzQ2MjU0NDkiIGQ9Ik0xMi43NzE4IDcuMjAzMjFMOC42NTc3MSAxMS4zMTczTDUuODI5MjggOC40ODg4NiIgc3Ryb2tlPSIjMEVDQjgxIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPgo8L2c+Cjwvc3ZnPgo=" alt="">
                                          </div>
                                        </div>
                                        <div class="mt-[12px] flex text-[14px]">
                                          <div class="w-[50%] text-[14px] text-ds-color-text-tertiary">Fiat deposit</div>
                                          <div class="w-[50%] text-[14px] text-right font-medium text-ds-color-text-primary">
                                            <img class="float-right" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHZpZXdCb3g9IjAgMCAxOCAxOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGcgaWQ9IlByb2hpYml0Ij4KPGNpcmNsZSBpZD0iRWxsaXBzZSA3MzQ1IiBjeD0iOS4wMDAyNyIgY3k9IjguOTk5OTkiIHI9IjcuMjcyNzMiIHN0cm9rZT0iIzBFQ0I4MSIgc3Ryb2tlLXdpZHRoPSIyIi8+CjxwYXRoIGlkPSJSZWN0YW5nbGUgMzQ2MjU0NDkiIGQ9Ik0xMi43NzE4IDcuMjAzMjFMOC42NTc3MSAxMS4zMTczTDUuODI5MjggOC40ODg4NiIgc3Ryb2tlPSIjMEVDQjgxIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPgo8L2c+Cjwvc3ZnPgo=" alt="">
                                          </div>
                                        </div>
                                        <div class="mt-[12px] flex text-[14px]">
                                          <div class="w-[50%] text-[14px] text-ds-color-text-tertiary">P2P trading</div>
                                          <div class="w-[50%] text-[14px] text-right font-medium text-ds-color-text-primary">
                                            <img class="float-right" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHZpZXdCb3g9IjAgMCAxOCAxOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGcgaWQ9IlByb2hpYml0Ij4KPGNpcmNsZSBpZD0iRWxsaXBzZSA3MzQ1IiBjeD0iOS4wMDAyNyIgY3k9IjguOTk5OTkiIHI9IjcuMjcyNzMiIHN0cm9rZT0iIzBFQ0I4MSIgc3Ryb2tlLXdpZHRoPSIyIi8+CjxwYXRoIGlkPSJSZWN0YW5nbGUgMzQ2MjU0NDkiIGQ9Ik0xMi43NzE4IDcuMjAzMjFMOC42NTc3MSAxMS4zMTczTDUuODI5MjggOC40ODg4NiIgc3Ryb2tlPSIjMEVDQjgxIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPgo8L2c+Cjwvc3ZnPgo=" alt="">
                                          </div>
                                        </div>
                                      </div>
                                      <div class="mb-[20px] mt-[26px] h-[1px] w-full bg-ds-color-border-subtle"></div>
                                      <div class="text-ds-color-text-primary">
                                        <div class="text-[16px] font-medium">Verification requirements</div>
                                        <div class="mt-[12px] flex items-center text-[14px]">
                                          <img class="w-20px h-20px" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCAyMCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTAuNSIgY3k9IjEwLjUiIHI9IjEuNSIgZmlsbD0iIzE1MTUxNyIvPgo8L3N2Zz4K" alt="">
                                          <div>Government-issued documents</div>
                                        </div>
                                        <div class="mt-[12px] flex items-center text-[14px]">
                                          <img class="w-20px h-20px" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCAyMCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTAuNSIgY3k9IjEwLjUiIHI9IjEuNSIgZmlsbD0iIzE1MTUxNyIvPgo8L3N2Zz4K" alt="">
                                          <div>Face recognition verification</div>
                                        </div>
                                        <div class="mt-[12px] flex items-center text-[14px]">
                                          <img class="w-20px h-20px" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCAyMCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTAuNSIgY3k9IjEwLjUiIHI9IjEuNSIgZmlsbD0iIzE1MTUxNyIvPgo8L3N2Zz4K" alt="">
                                          <div>Estimated review time: 60m</div>
                                        </div>
                                      </div>
                                      <div class="mt-[28px]">
                                        <button type="button" class="bit-btn css-1eqkoyn bit-btn-round bit-btn-main bit-btn-lg w-full">
                                          <span>Verify</span></button>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="mt-[16px] xl:mt-[0px] xl:w-[448px]">
                            <div class="w-full rounded-[16px] border-[1px] border-solid border-ds-color-border-subtle bg-ds-color-background-primary px-[32px] py-[40px] xl:w-[448px]">
                              <div class="mb-[16px] flex items-center justify-between">
                                <div class="text-[24px] font-semibold text-ds-color-text-primary">FAQ</div>
                                <div class="cursor-pointer text-[16px] font-medium text-ds-color-text-secondary">More</div>
                              </div>
                              <div>
                                <div class="py-[16px]">
                                  <div class="mb-[8px] flex cursor-pointer items-center justify-between">
                                    <div class="text-16px leading-24px w-[90%] font-medium text-ds-color-text-primary">Why do I need to undergo identity verification?</div>
                                    <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik04LjgwMDE0IDkuOTMzNUM4LjQwMDE0IDEwLjQ2NjggNy42MDAxNCAxMC40NjY4IDcuMjAwMTQgOS45MzM1TDQuNzAwMTQgNi42MDAxNkM0LjIwNTcxIDUuOTQwOTMgNC42NzYwOSA1LjAwMDE2IDUuNTAwMTQgNS4wMDAxNkgxMC41MDAxQzExLjMyNDIgNS4wMDAxNiAxMS43OTQ2IDUuOTQwOTMgMTEuMzAwMSA2LjYwMDE2TDguODAwMTQgOS45MzM1WiIgZmlsbD0iIzFGMUYxRiIvPgo8L3N2Zz4K" alt="" class="">
                                  </div>
                                  <div class="text-[14px] leading-[22px] text-ds-color-text-tertiary">
                                    <div class="relative">
                                      <div class="line-clamp-2 leading-[22px]" style="visibility: visible;">Identity verification is a process used by financial institutions and other regulated organizations to confirm your identity. Bitget will verify your identity and conduct risk assessment to mitigate risks.</div>
                                      <div class="leading-[22px] absolute" style="visibility: hidden;">Identity verification is a process used by financial institutions and other regulated organizations to confirm your identity. Bitget will verify your identity and conduct risk assessment to mitigate risks.</div>
                                    </div>
                                  </div>
                                </div>
                                <div class="h-[1px] w-full bg-ds-color-border-subtle"></div>
                                <div class="py-[16px]">
                                  <div class="mb-[8px] flex cursor-pointer items-center justify-between">
                                    <div class="text-16px leading-24px w-[90%] font-medium text-ds-color-text-primary">Why can't I select my country/region?</div>
                                    <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik04LjgwMDE0IDkuOTMzNUM4LjQwMDE0IDEwLjQ2NjggNy42MDAxNCAxMC40NjY4IDcuMjAwMTQgOS45MzM1TDQuNzAwMTQgNi42MDAxNkM0LjIwNTcxIDUuOTQwOTMgNC42NzYwOSA1LjAwMDE2IDUuNTAwMTQgNS4wMDAxNkgxMC41MDAxQzExLjMyNDIgNS4wMDAxNiAxMS43OTQ2IDUuOTQwOTMgMTEuMzAwMSA2LjYwMDE2TDguODAwMTQgOS45MzM1WiIgZmlsbD0iIzFGMUYxRiIvPgo8L3N2Zz4K" alt="" class="">
                                  </div>
                                  <div class="text-[14px] leading-[22px] text-ds-color-text-tertiary">
                                    <div class="relative">
                                      <div class="line-clamp-2 leading-[22px]" style="visibility: visible;">Bitget does not provide services to users in the following countries/regions: Canada (Alberta), Crimea, Cuba, Hong Kong, Iran, North Korea, Singapore, Sudan, Syria, the United States, Iraq, Libya, Yemen, Afghanistan, Central African Republic, Democratic Republic of the Congo, Guinea-Bissau, Haiti, Lebanon, Somalia, South Sudan, and the Netherlands.</div>
                                      <div class="leading-[22px] absolute" style="visibility: hidden;">Bitget does not provide services to users in the following countries/regions: Canada (Alberta), Crimea, Cuba, Hong Kong, Iran, North Korea, Singapore, Sudan, Syria, the United States, Iraq, Libya, Yemen, Afghanistan, Central African Republic, Democratic Republic of the Congo, Guinea-Bissau, Haiti, Lebanon, Somalia, South Sudan, and the Netherlands.</div>
                                    </div>
                                  </div>
                                </div>
                                <div class="h-[1px] w-full bg-ds-color-border-subtle"></div>
                                <div class="py-[16px]">
                                  <div class="mb-[8px] flex cursor-pointer items-center justify-between">
                                    <div class="text-16px leading-24px w-[90%] font-medium text-ds-color-text-primary">What documents can I submit for identity verification?</div>
                                    <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik04LjgwMDE0IDkuOTMzNUM4LjQwMDE0IDEwLjQ2NjggNy42MDAxNCAxMC40NjY4IDcuMjAwMTQgOS45MzM1TDQuNzAwMTQgNi42MDAxNkM0LjIwNTcxIDUuOTQwOTMgNC42NzYwOSA1LjAwMDE2IDUuNTAwMTQgNS4wMDAxNkgxMC41MDAxQzExLjMyNDIgNS4wMDAxNiAxMS43OTQ2IDUuOTQwOTMgMTEuMzAwMSA2LjYwMDE2TDguODAwMTQgOS45MzM1WiIgZmlsbD0iIzFGMUYxRiIvPgo8L3N2Zz4K" alt="" class="">
                                  </div>
                                  <div class="text-[14px] leading-[22px] text-ds-color-text-tertiary">
                                    <div class="relative">
                                      <div class="line-clamp-2 leading-[22px]" style="visibility: visible;">Level 1: ID card, passport, driver's license, and proof of residence.
                                        Level 2: Bank statements, utility bills (within the last three months), internet/cable/home phone bills, tax returns, council tax bills, and government-issued proof of residence.
                                      </div>
                                      <div class="leading-[22px] absolute" style="visibility: hidden;">Level 1: ID card, passport, driver's license, and proof of residence.
                                        Level 2: Bank statements, utility bills (within the last three months), internet/cable/home phone bills, tax returns, council tax bills, and government-issued proof of residence.
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <div class="h-[1px] w-full bg-ds-color-border-subtle"></div>
                                <div class="py-[16px]">
                                  <div class="mb-[8px] flex cursor-pointer items-center justify-between">
                                    <div class="text-16px leading-24px w-[90%] font-medium text-ds-color-text-primary">What are the requirements for identity verification?</div>
                                  </div>
                                  <div class="text-[14px] leading-[22px] text-ds-color-text-tertiary">
                                    <div class="relative">
                                      <div class="line-clamp-2 leading-[22px]" style="visibility: visible;">1. You must be at least 18 years old.
                                        2. You can only complete the identity verification on one account.
                                      </div>
                                      <div class="leading-[22px] absolute" style="visibility: hidden;">1. You must be at least 18 years old.
                                        2. You can only complete the identity verification on one account.
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div></div>
                  <div></div>
                  <div></div>
                </div>
              </div>
            </main>
            <HzFooter></HzFooter>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

import LeftDash from "@/components/LeftDash.vue"; // 引入头部组件

export default {
  components: {
    LeftDash, // 注册头部组件
  },
};
</script>
<style></style>