<template>
  <div class="main-box lay-box clearfix">
    <div>
      <div data-fetch-key="data-v-08a1c11c:0" class="portal-wrapper" data-v-08a1c11c="">
        <div class="home" data-v-08a1c11c="">
          <div id="homeBanner" class="home-box minPhone:min-h-500px" data-v-08a1c11c="">
            <div class="h-500px pad:h-auto phone:hidden">
              <div class="overflow-hidden webHomeConfig relative" data-v-759fbb3f="">
                <div class="relative swiper-container swiper-container-horizontal h-500px pad:h-auto swiper-container-pc swiper-no-swiping phone:h-240px swiper-container-initialized" data-v-759fbb3f="">
                  <div class="h-500px swiper-wrapper relative phone:min-h-234px phone:h-234px" data-v-759fbb3f="" style="transition-duration: 0ms; transform: translate3d(-3634px, 0px, 0px);">
                    <div class="swiper-slide box-border overflow-hidden swiper-slide-duplicate swiper-slide-duplicate-next" data-v-759fbb3f="" data-swiper-slide-index="2" style="width: 1817px;">
                      <div class="mx-auto h-1/1" data-v-759fbb3f="">
                        <div class="mx-auto box-border" data-v-759fbb3f="">
                          <div id="contentBoxId" class="contentBox h-500px relative box-border flex overflow-hidden w-1/1 pad:h-906px  min-h-500px pad:min-h-906px phone:min-h-234px phone:h-234px" style="background-color: rgb(255, 255, 255);" data-v-3ded291d="">
                            <div class="relative justify-between flex w-1200px mx-auto box-border <xl:w-full <xl:px-24px pad:flex-col pad:flex-col-reverse pad:justify-end pad:items-center pad:px-24px phone:justify-around phone:items-center phone:px-16px" data-v-3ded291d="">
                              <div class="w-600px z-1 h-360px flex flex-col justify-start mt-80px box-border <xl:w-528px !pad:mt-16px !pad:w-full pad:h-302px !phone:w-full !phone:mt-0 phone:h-222px" data-v-3ded291d="">
                                <div class="phone:flex phone:justify-between phone:items-center phone:gap-8px" data-v-3ded291d="">
                                  <div class="flex flex-col phone:max-w-218px" data-v-3ded291d="">
                                    <h1 class="m-0 line-clamp-2 flex flex-wrap text-56px font-600 leading-67px text-v3PrimaryText pad:text-48px pad:font-700 pad:leading-[120%] phone:font-700 phone:text-16px phone:leading-22px" data-v-3ded291d="">
                                      Trade smarter with Bitget
                                    </h1>
                                    <div class="line-clamp-2 mt-18px text-20px leading-[140%] text-v3PrimaryText phone:line-clamp-1 phone:mt-4px phone:text-12px" data-v-3ded291d="">
                                      Join the largest copy trading platform today
                                    </div> <!----></div>
                                  <div class="top-banner-image w-500px h-500px mt-50px h-1/1 flex pad:mt-24px minPhone:hidden phone:w-132px phone:h-132px phone:mt-0" style="background-image: url(&quot;https://img.bitgetimg.com/multiLang/web/fc435e9f27bd2b1af619995b433ecdc0.png&quot;);" data-v-3ded291d=""></div>
                                </div>
                                <div data-v-71b06a1e="" data-v-3ded291d="" class="">
                                  <div class="w-1/1 pad:w-full phone:w-full" data-v-71b06a1e="">
                                    <div class="home-banner-login flex flex-col box-border text-v3PrimaryText font-400 leading-24px w-1/1 pc:mt-32px pad:w-full phone:w-full" data-v-55be6e78="" data-v-71b06a1e="">
                                      <span class="relative flex items-center text-20px leading-[140%] mr-8px cursor-pointer phone:text-12px phone:max-w-full phone:truncate" data-v-55be6e78=""><img src="/baseasset/img/v3-home/topbanner_rewards_icon_black.svg" loading="lazy" alt="Bitget Register Rewards10.0643665874960695" class="w-24px h-24px align-bottom mr-8px phone:w-14px" style="display: none;" data-v-55be6e78=""> <img src="../assets/img/topbanner_rewards_icon_white.svg" loading="lazy" alt="Bitget Register Rewards20.08322935458827385" class="w-24px h-24px align-bottom mr-8px phone:w-14px" style="" data-v-55be6e78=""> <span data-v-55be6e78="">Sign up now to claim a welcome pack of <span class="homepage-brand-color">6200 USDT</span>!</span></span>
                                      <div class="mt-24px w-1/1 flex flex-row box-border pad:mt-16px phone:hidden" data-v-55be6e78="">
                                        <div class="flex box-border w-full" data-v-55be6e78="">
                                          <div class="w-364px mr-8px pad:flex-auto phone:flex-auto phone:mr-6px bit-theme-light-vue2" style="background:transparent !important;" data-v-55be6e78="">
                                            <div class="home-login-input" style="background-color: rgb(255, 255, 255);" data-v-55be6e78="">
                                              <div class="bit-input bit-input--large bit-input--round" data-v-55be6e78=""><!----><!----><input type="text" autocomplete="off" placeholder="Email/Phone number" class="bit-input__inner"><!----><!----><!----><!----><!----><!---->
                                              </div>
                                            </div>
                                          </div>
                                          <div class="flex-shrink-0 w-160px <xl:w-140px pad:w-182px phone:w-117px" data-v-55be6e78="">
                                            <button type="button" class="bit-button resgiter-btn w-full bit-button--primary bit-button--large is-round" data-v-55be6e78=""><!----><!----><!----><span>Sign up</span><!---->
                                            </button>
                                          </div>
                                          <span class="pad:hidden <md:hidden" data-v-55be6e78=""><div role="tooltip" id="bit-popover-8078" aria-hidden="true" class="bit-popover bit-popper" style="width:120px;display:none;" tabindex="0"><!----><div class="bit-popover__message-text"><!----><div class="bit-popover__content"><div data-v-55be6e78="" class="flex flex-col justify-center items-center"><div data-v-55be6e78="" class="text-v3PrimaryText text-14px font-600 leading-20px">Scan to download</div> <div data-v-55be6e78="" class="w-108px h-108px box-border bg-v3ContentAlwaysWhite px-4px py-4px rounded-4px mt-12px mb-24px"><canvas height="100" width="100"></canvas></div> <button data-v-55be6e78="" type="button" class="bit-button bit-button--primary is-round"><!----><!----><!----><span><span data-v-55be6e78="" class="inline-block max-w-86px truncate">More downloads</span></span><!----></button></div> </div></div></div><span class="bit-popover__reference-wrapper"><div class="box-border w-48px h-48px rounded-1 flex justify-center items-center ml-8px bg-v3LinkDefaultText text-v3ContentAlwaysWhite bit-popover__reference" data-v-55be6e78="" aria-describedby="bit-popover-8078" tabindex="0"><i class="bit-icon" style="font-size:28px;" data-v-55be6e78=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" data-v-55be6e78=""><path d="M9.75 3.75h-4.5a1.5 1.5 0 00-1.5 1.5v4.5a1.5 1.5 0 001.5 1.5h4.5a1.5 1.5 0 001.5-1.5v-4.5a1.5 1.5 0 00-1.5-1.5zm0 6h-4.5v-4.5h4.5v4.5zm0 3h-4.5a1.5 1.5 0 00-1.5 1.5v4.5a1.5 1.5 0 001.5 1.5h4.5a1.5 1.5 0 001.5-1.5v-4.5a1.5 1.5 0 00-1.5-1.5zm0 6h-4.5v-4.5h4.5v4.5zm9-15h-4.5a1.5 1.5 0 00-1.5 1.5v4.5a1.5 1.5 0 001.5 1.5h4.5a1.5 1.5 0 001.5-1.5v-4.5a1.5 1.5 0 00-1.5-1.5zm0 6h-4.5v-4.5h4.5v4.5zm-6 6.75v-3a.75.75 0 111.5 0v3a.75.75 0 11-1.5 0zm7.5-1.5a.75.75 0 01-.75.75h-2.25v3.75a.75.75 0 01-.75.75h-3a.75.75 0 110-1.5h2.25V13.5a.75.75 0 111.5 0v.75h2.25a.75.75 0 01.75.75zm0 3v1.5a.75.75 0 11-1.5 0V18a.75.75 0 111.5 0z"></path></svg></i></div></span></span>
                                        </div>
                                      </div>
                                      <div class="mt-16px flex justify-around gap-4px minPhone:hidden" data-v-55be6e78="">
                                        <button type="button" class="bit-button register-button w-[50%] bit-button--default bit-button--large is-round" data-v-55be6e78=""><!----><!----><!----><span>Sign Up</span><!---->
                                        </button>
                                        <button type="button" class="bit-button w-[50%] bit-button--primary bit-button--large is-round" data-v-55be6e78=""><!----><!----><!----><span>Login</span><!---->
                                        </button>
                                      </div>
                                    </div>
                                  </div> <!----></div>
                              </div>
                              <div class="top-banner-image w-500px h-500px h-1/1 flex pad:mt-24px phone:hidden phone:w-132px phone:h-132px" style="background-image: url(&quot;https://img.bitgetimg.com/multiLang/web/fc435e9f27bd2b1af619995b433ecdc0.png&quot;);" data-v-3ded291d=""></div> <!---->
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="swiper-slide box-border overflow-hidden swiper-slide-prev" data-v-759fbb3f="" data-swiper-slide-index="0" style="width: 1817px;">
                      <div class="mx-auto h-1/1" data-v-759fbb3f="">
                        <div class="mx-auto box-border" data-v-759fbb3f="">
                          <div id="contentBoxId" class="contentBox h-500px relative box-border flex overflow-hidden w-1/1 pad:h-906px  min-h-500px pad:min-h-906px phone:min-h-234px phone:h-234px cursor-pointer" style="background-color: rgb(255, 255, 255);" data-v-3ded291d="">
                            <div class="relative justify-between flex w-1200px mx-auto box-border <xl:w-full <xl:px-24px pad:flex-col pad:flex-col-reverse pad:justify-end pad:items-center pad:px-24px phone:justify-around phone:items-center phone:px-16px" data-v-3ded291d="">
                              <div class="w-600px z-1 h-360px flex flex-col justify-start mt-80px box-border <xl:w-528px !pad:mt-16px !pad:w-full pad:h-302px !phone:w-full !phone:mt-0 phone:h-222px" data-v-3ded291d="">
                                <div class="phone:flex phone:justify-between phone:items-center phone:gap-8px" data-v-3ded291d="">
                                  <div class="flex flex-col phone:max-w-218px" data-v-3ded291d="">
                                    <h1 class="m-0 line-clamp-2 flex flex-wrap text-56px font-600 leading-67px text-v3PrimaryText pad:text-48px pad:font-700 pad:leading-[120%] phone:font-700 phone:text-16px phone:leading-22px" data-v-3ded291d="">
                                      Cheers to Oktoberfest !
                                    </h1>
                                    <div class="line-clamp-2 mt-18px text-20px leading-[140%] text-v3PrimaryText phone:line-clamp-1 phone:mt-4px phone:text-12px" data-v-3ded291d="">
                                      Trade to win your favorite beers and Munich Trip fund！
                                    </div> <!----></div>
                                  <div class="top-banner-image w-500px h-500px mt-50px h-1/1 flex pad:mt-24px minPhone:hidden phone:w-132px phone:h-132px phone:mt-0" style="background-image: url(&quot;https://img.bitgetimg.com/multiLang/web/8a362d707de0b30ae0c15f6bf6fadb7d.png&quot;);" data-v-3ded291d=""></div>
                                </div>
                                <div data-v-71b06a1e="" data-v-3ded291d="" class="">
                                  <div class="w-1/1 pad:w-full phone:w-full" data-v-71b06a1e="">
                                    <div class="home-banner-login flex flex-col box-border text-v3PrimaryText font-400 leading-24px w-1/1 pc:mt-32px pad:w-full phone:w-full" data-v-55be6e78="" data-v-71b06a1e="">
                                      <span class="relative flex items-center text-20px leading-[140%] mr-8px cursor-pointer phone:text-12px phone:max-w-full phone:truncate" data-v-55be6e78=""><img src="/baseasset/img/v3-home/topbanner_rewards_icon_black.svg" loading="lazy" alt="Bitget Register Rewards10.6431780374331608" class="w-24px h-24px align-bottom mr-8px phone:w-14px" style="display: none;" data-v-55be6e78=""> <img src="../assets/img/topbanner_rewards_icon_white.svg" loading="lazy" alt="Bitget Register Rewards20.47659121214864175" class="w-24px h-24px align-bottom mr-8px phone:w-14px" style="" data-v-55be6e78=""> <span data-v-55be6e78="">Sign up now to claim a welcome pack of <span class="homepage-brand-color">6200 USDT</span>!</span></span>
                                      <div class="mt-24px w-1/1 flex flex-row box-border pad:mt-16px phone:hidden" data-v-55be6e78="">
                                        <div class="flex box-border w-full" data-v-55be6e78="">
                                          <div class="w-364px mr-8px pad:flex-auto phone:flex-auto phone:mr-6px bit-theme-light-vue2" style="background:transparent !important;" data-v-55be6e78="">
                                            <div class="home-login-input" style="background-color: rgb(255, 255, 255);" data-v-55be6e78="">
                                              <div class="bit-input bit-input--large bit-input--round" data-v-55be6e78=""><!----><!----><input type="text" autocomplete="off" placeholder="Email/Phone number" class="bit-input__inner"><!----><!----><!----><!----><!----><!---->
                                              </div>
                                            </div>
                                          </div>
                                          <div class="flex-shrink-0 w-160px <xl:w-140px pad:w-182px phone:w-117px" data-v-55be6e78="">
                                            <button type="button" class="bit-button resgiter-btn w-full bit-button--primary bit-button--large is-round" data-v-55be6e78=""><!----><!----><!----><span>Sign up</span><!---->
                                            </button>
                                          </div>
                                          <span class="pad:hidden <md:hidden" data-v-55be6e78=""><div role="tooltip" id="bit-popover-1837" aria-hidden="true" class="bit-popover bit-popper" style="width:120px;display:none;" tabindex="0"><!----><div class="bit-popover__message-text"><!----><div class="bit-popover__content"><div data-v-55be6e78="" class="flex flex-col justify-center items-center"><div data-v-55be6e78="" class="text-v3PrimaryText text-14px font-600 leading-20px">Scan to download</div> <div data-v-55be6e78="" class="w-108px h-108px box-border bg-v3ContentAlwaysWhite px-4px py-4px rounded-4px mt-12px mb-24px"><canvas height="100" width="100"></canvas></div> <button data-v-55be6e78="" type="button" class="bit-button bit-button--primary is-round"><!----><!----><!----><span><span data-v-55be6e78="" class="inline-block max-w-86px truncate">More downloads</span></span><!----></button></div> </div></div></div><span class="bit-popover__reference-wrapper"><div class="box-border w-48px h-48px rounded-1 flex justify-center items-center ml-8px bg-v3LinkDefaultText text-v3ContentAlwaysWhite bit-popover__reference" data-v-55be6e78="" aria-describedby="bit-popover-1837" tabindex="0"><i class="bit-icon" style="font-size:28px;" data-v-55be6e78=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" data-v-55be6e78=""><path d="M9.75 3.75h-4.5a1.5 1.5 0 00-1.5 1.5v4.5a1.5 1.5 0 001.5 1.5h4.5a1.5 1.5 0 001.5-1.5v-4.5a1.5 1.5 0 00-1.5-1.5zm0 6h-4.5v-4.5h4.5v4.5zm0 3h-4.5a1.5 1.5 0 00-1.5 1.5v4.5a1.5 1.5 0 001.5 1.5h4.5a1.5 1.5 0 001.5-1.5v-4.5a1.5 1.5 0 00-1.5-1.5zm0 6h-4.5v-4.5h4.5v4.5zm9-15h-4.5a1.5 1.5 0 00-1.5 1.5v4.5a1.5 1.5 0 001.5 1.5h4.5a1.5 1.5 0 001.5-1.5v-4.5a1.5 1.5 0 00-1.5-1.5zm0 6h-4.5v-4.5h4.5v4.5zm-6 6.75v-3a.75.75 0 111.5 0v3a.75.75 0 11-1.5 0zm7.5-1.5a.75.75 0 01-.75.75h-2.25v3.75a.75.75 0 01-.75.75h-3a.75.75 0 110-1.5h2.25V13.5a.75.75 0 111.5 0v.75h2.25a.75.75 0 01.75.75zm0 3v1.5a.75.75 0 11-1.5 0V18a.75.75 0 111.5 0z"></path></svg></i></div></span></span>
                                        </div>
                                      </div>
                                      <div class="mt-16px flex justify-around gap-4px minPhone:hidden" data-v-55be6e78="">
                                        <button type="button" class="bit-button register-button w-[50%] bit-button--default bit-button--large is-round" data-v-55be6e78=""><!----><!----><!----><span>Sign Up</span><!---->
                                        </button>
                                        <button type="button" class="bit-button w-[50%] bit-button--primary bit-button--large is-round" data-v-55be6e78=""><!----><!----><!----><span>Login</span><!---->
                                        </button>
                                      </div>
                                    </div>
                                  </div> <!----></div>
                              </div>
                              <div class="top-banner-image w-500px h-500px h-1/1 flex pad:mt-24px phone:hidden phone:w-132px phone:h-132px" style="background-image: url(&quot;https://img.bitgetimg.com/multiLang/web/8a362d707de0b30ae0c15f6bf6fadb7d.png&quot;);" data-v-3ded291d=""></div> <!---->
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="swiper-slide box-border overflow-hidden swiper-slide-active" data-v-759fbb3f="" data-swiper-slide-index="1" style="width: 1817px;">
                      <div class="mx-auto h-1/1" data-v-759fbb3f="">
                        <div class="mx-auto box-border" data-v-759fbb3f="">
                          <div id="contentBoxId" class="contentBox h-500px relative box-border flex overflow-hidden w-1/1 pad:h-906px  min-h-500px pad:min-h-906px phone:min-h-234px phone:h-234px cursor-pointer" style="background-color: rgb(255, 255, 255);" data-v-3ded291d="">
                            <div class="relative justify-between flex w-1200px mx-auto box-border <xl:w-full <xl:px-24px pad:flex-col pad:flex-col-reverse pad:justify-end pad:items-center pad:px-24px phone:justify-around phone:items-center phone:px-16px" data-v-3ded291d="">
                              <div class="w-600px z-1 h-360px flex flex-col justify-start mt-80px box-border <xl:w-528px !pad:mt-16px !pad:w-full pad:h-302px !phone:w-full !phone:mt-0 phone:h-222px" data-v-3ded291d="">
                                <div class="phone:flex phone:justify-between phone:items-center phone:gap-8px" data-v-3ded291d="">
                                  <div class="flex flex-col phone:max-w-218px" data-v-3ded291d="">
                                    <h1 class="m-0 line-clamp-2 flex flex-wrap text-56px font-600 leading-67px text-v3PrimaryText pad:text-48px pad:font-700 pad:leading-[120%] phone:font-700 phone:text-16px phone:leading-22px" data-v-3ded291d="">
                                      Futures Elite Trader Leaderboard
                                    </h1>
                                    <div class="line-clamp-2 mt-18px text-20px leading-[140%] text-v3PrimaryText phone:line-clamp-1 phone:mt-4px phone:text-12px" data-v-3ded291d="">
                                      Make the leaderboard to grab a share of 356,000 USDT!
                                    </div>
                                    <div class="line-clamp-2 mt-18px text-20px leading-[140%] text-v3PrimaryText phone:line-clamp-1 phone:mt-4px phone:text-12px" data-v-3ded291d="">
                                      Up to 100 USDT Sunshine Award for everyone!
                                    </div> <!----></div>
                                  <div class="top-banner-image w-500px h-500px mt-50px h-1/1 flex pad:mt-24px minPhone:hidden phone:w-132px phone:h-132px phone:mt-0" style="background-image: url(&quot;https://img.bitgetimg.com/multiLang/web/6975ef3761e63b918e01164056ae4975.png&quot;);" data-v-3ded291d=""></div>
                                </div>
                                <div data-v-71b06a1e="" data-v-3ded291d="" class="">
                                  <div class="w-1/1 pad:w-full phone:w-full" data-v-71b06a1e="">
                                    <div class="home-banner-login flex flex-col box-border text-v3PrimaryText font-400 leading-24px w-1/1 pc:mt-32px pad:w-full phone:w-full" data-v-55be6e78="" data-v-71b06a1e="">
                                      <span class="relative flex items-center text-20px leading-[140%] mr-8px cursor-pointer phone:text-12px phone:max-w-full phone:truncate" data-v-55be6e78=""><img src="/baseasset/img/v3-home/topbanner_rewards_icon_black.svg" loading="lazy" alt="Bitget Register Rewards10.8693882227942433" class="w-24px h-24px align-bottom mr-8px phone:w-14px" style="display: none;" data-v-55be6e78=""> <img src="../assets/img/topbanner_rewards_icon_white.svg" loading="lazy" alt="Bitget Register Rewards20.418821450590283" class="w-24px h-24px align-bottom mr-8px phone:w-14px" style="" data-v-55be6e78=""> <span data-v-55be6e78="">Sign up now to claim a welcome pack of <span class="homepage-brand-color">6200 USDT</span>!</span></span>
                                      <div class="mt-24px w-1/1 flex flex-row box-border pad:mt-16px phone:hidden" data-v-55be6e78="">
                                        <div class="flex box-border w-full" data-v-55be6e78="">
                                          <div class="w-364px mr-8px pad:flex-auto phone:flex-auto phone:mr-6px bit-theme-light-vue2" style="background:transparent !important;" data-v-55be6e78="">
                                            <div class="home-login-input" style="background-color: rgb(255, 255, 255);" data-v-55be6e78="">
                                              <div class="bit-input bit-input--large bit-input--round" data-v-55be6e78=""><!----><!----><input type="text" autocomplete="off" placeholder="Email/Phone number" class="bit-input__inner"><!----><!----><!----><!----><!----><!---->
                                              </div>
                                            </div>
                                          </div>
                                          <div class="flex-shrink-0 w-160px <xl:w-140px pad:w-182px phone:w-117px" data-v-55be6e78="">
                                            <button type="button" class="bit-button resgiter-btn w-full bit-button--primary bit-button--large is-round" data-v-55be6e78=""><!----><!----><!----><span>Sign up</span><!---->
                                            </button>
                                          </div>
                                          <span class="pad:hidden <md:hidden" data-v-55be6e78=""><span class="bit-popover__reference-wrapper"><div class="box-border w-48px h-48px rounded-1 flex justify-center items-center ml-8px bg-v3LinkDefaultText text-v3ContentAlwaysWhite bit-popover__reference" data-v-55be6e78="" aria-describedby="bit-popover-3336" tabindex="0"><i class="bit-icon" style="font-size:28px;" data-v-55be6e78=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" data-v-55be6e78=""><path d="M9.75 3.75h-4.5a1.5 1.5 0 00-1.5 1.5v4.5a1.5 1.5 0 001.5 1.5h4.5a1.5 1.5 0 001.5-1.5v-4.5a1.5 1.5 0 00-1.5-1.5zm0 6h-4.5v-4.5h4.5v4.5zm0 3h-4.5a1.5 1.5 0 00-1.5 1.5v4.5a1.5 1.5 0 001.5 1.5h4.5a1.5 1.5 0 001.5-1.5v-4.5a1.5 1.5 0 00-1.5-1.5zm0 6h-4.5v-4.5h4.5v4.5zm9-15h-4.5a1.5 1.5 0 00-1.5 1.5v4.5a1.5 1.5 0 001.5 1.5h4.5a1.5 1.5 0 001.5-1.5v-4.5a1.5 1.5 0 00-1.5-1.5zm0 6h-4.5v-4.5h4.5v4.5zm-6 6.75v-3a.75.75 0 111.5 0v3a.75.75 0 11-1.5 0zm7.5-1.5a.75.75 0 01-.75.75h-2.25v3.75a.75.75 0 01-.75.75h-3a.75.75 0 110-1.5h2.25V13.5a.75.75 0 111.5 0v.75h2.25a.75.75 0 01.75.75zm0 3v1.5a.75.75 0 11-1.5 0V18a.75.75 0 111.5 0z"></path></svg></i></div></span></span>
                                        </div>
                                      </div>
                                      <div class="mt-16px flex justify-around gap-4px minPhone:hidden" data-v-55be6e78="">
                                        <button type="button" class="bit-button register-button w-[50%] bit-button--default bit-button--large is-round" data-v-55be6e78=""><!----><!----><!----><span>Sign Up</span><!---->
                                        </button>
                                        <button type="button" class="bit-button w-[50%] bit-button--primary bit-button--large is-round" data-v-55be6e78=""><!----><!----><!----><span>Login</span><!---->
                                        </button>
                                      </div>
                                    </div>
                                  </div> <!----></div>
                              </div>
                              <div class="top-banner-image w-500px h-500px h-1/1 flex pad:mt-24px phone:hidden phone:w-132px phone:h-132px" style="background-image: url(&quot;https://img.bitgetimg.com/multiLang/web/6975ef3761e63b918e01164056ae4975.png&quot;);" data-v-3ded291d=""></div> <!---->
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="swiper-slide box-border overflow-hidden swiper-slide-next" data-v-759fbb3f="" data-swiper-slide-index="2" style="width: 1817px;">
                      <div class="mx-auto h-1/1" data-v-759fbb3f="">
                        <div class="mx-auto box-border" data-v-759fbb3f="">
                          <div id="contentBoxId" class="contentBox h-500px relative box-border flex overflow-hidden w-1/1 pad:h-906px  min-h-500px pad:min-h-906px phone:min-h-234px phone:h-234px" style="background-color: rgb(255, 255, 255);" data-v-3ded291d="">
                            <div class="relative justify-between flex w-1200px mx-auto box-border <xl:w-full <xl:px-24px pad:flex-col pad:flex-col-reverse pad:justify-end pad:items-center pad:px-24px phone:justify-around phone:items-center phone:px-16px" data-v-3ded291d="">
                              <div class="w-600px z-1 h-360px flex flex-col justify-start mt-80px box-border <xl:w-528px !pad:mt-16px !pad:w-full pad:h-302px !phone:w-full !phone:mt-0 phone:h-222px" data-v-3ded291d="">
                                <div class="phone:flex phone:justify-between phone:items-center phone:gap-8px" data-v-3ded291d="">
                                  <div class="flex flex-col phone:max-w-218px" data-v-3ded291d="">
                                    <h1 class="m-0 line-clamp-2 flex flex-wrap text-56px font-600 leading-67px text-v3PrimaryText pad:text-48px pad:font-700 pad:leading-[120%] phone:font-700 phone:text-16px phone:leading-22px" data-v-3ded291d="">
                                      Trade smarter with Bitget
                                    </h1>
                                    <div class="line-clamp-2 mt-18px text-20px leading-[140%] text-v3PrimaryText phone:line-clamp-1 phone:mt-4px phone:text-12px" data-v-3ded291d="">
                                      Join the largest copy trading platform today
                                    </div> <!----></div>
                                  <div class="top-banner-image w-500px h-500px mt-50px h-1/1 flex pad:mt-24px minPhone:hidden phone:w-132px phone:h-132px phone:mt-0" style="background-image: url(&quot;https://img.bitgetimg.com/multiLang/web/fc435e9f27bd2b1af619995b433ecdc0.png&quot;);" data-v-3ded291d=""></div>
                                </div>
                                <div data-v-71b06a1e="" data-v-3ded291d="" class="">
                                  <div class="w-1/1 pad:w-full phone:w-full" data-v-71b06a1e="">
                                    <div class="home-banner-login flex flex-col box-border text-v3PrimaryText font-400 leading-24px w-1/1 pc:mt-32px pad:w-full phone:w-full" data-v-55be6e78="" data-v-71b06a1e="">
                                      <span class="relative flex items-center text-20px leading-[140%] mr-8px cursor-pointer phone:text-12px phone:max-w-full phone:truncate" data-v-55be6e78=""><img src="/baseasset/img/v3-home/topbanner_rewards_icon_black.svg" loading="lazy" alt="Bitget Register Rewards10.0643665874960695" class="w-24px h-24px align-bottom mr-8px phone:w-14px" style="display: none;" data-v-55be6e78=""> <img src="../assets/img/topbanner_rewards_icon_white.svg" loading="lazy" alt="Bitget Register Rewards20.08322935458827385" class="w-24px h-24px align-bottom mr-8px phone:w-14px" style="" data-v-55be6e78=""> <span data-v-55be6e78="">Sign up now to claim a welcome pack of <span class="homepage-brand-color">6200 USDT</span>!</span></span>
                                      <div class="mt-24px w-1/1 flex flex-row box-border pad:mt-16px phone:hidden" data-v-55be6e78="">
                                        <div class="flex box-border w-full" data-v-55be6e78="">
                                          <div class="w-364px mr-8px pad:flex-auto phone:flex-auto phone:mr-6px bit-theme-light-vue2" style="background:transparent !important;" data-v-55be6e78="">
                                            <div class="home-login-input" style="background-color: rgb(255, 255, 255);" data-v-55be6e78="">
                                              <div class="bit-input bit-input--large bit-input--round" data-v-55be6e78=""><!----><!----><input type="text" autocomplete="off" placeholder="Email/Phone number" class="bit-input__inner"><!----><!----><!----><!----><!----><!---->
                                              </div>
                                            </div>
                                          </div>
                                          <div class="flex-shrink-0 w-160px <xl:w-140px pad:w-182px phone:w-117px" data-v-55be6e78="">
                                            <button type="button" class="bit-button resgiter-btn w-full bit-button--primary bit-button--large is-round" data-v-55be6e78=""><!----><!----><!----><span>Sign up</span><!---->
                                            </button>
                                          </div>
                                          <span class="pad:hidden <md:hidden" data-v-55be6e78=""><span class="bit-popover__reference-wrapper"><div class="box-border w-48px h-48px rounded-1 flex justify-center items-center ml-8px bg-v3LinkDefaultText text-v3ContentAlwaysWhite bit-popover__reference" data-v-55be6e78="" aria-describedby="bit-popover-8078" tabindex="0"><i class="bit-icon" style="font-size:28px;" data-v-55be6e78=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" data-v-55be6e78=""><path d="M9.75 3.75h-4.5a1.5 1.5 0 00-1.5 1.5v4.5a1.5 1.5 0 001.5 1.5h4.5a1.5 1.5 0 001.5-1.5v-4.5a1.5 1.5 0 00-1.5-1.5zm0 6h-4.5v-4.5h4.5v4.5zm0 3h-4.5a1.5 1.5 0 00-1.5 1.5v4.5a1.5 1.5 0 001.5 1.5h4.5a1.5 1.5 0 001.5-1.5v-4.5a1.5 1.5 0 00-1.5-1.5zm0 6h-4.5v-4.5h4.5v4.5zm9-15h-4.5a1.5 1.5 0 00-1.5 1.5v4.5a1.5 1.5 0 001.5 1.5h4.5a1.5 1.5 0 001.5-1.5v-4.5a1.5 1.5 0 00-1.5-1.5zm0 6h-4.5v-4.5h4.5v4.5zm-6 6.75v-3a.75.75 0 111.5 0v3a.75.75 0 11-1.5 0zm7.5-1.5a.75.75 0 01-.75.75h-2.25v3.75a.75.75 0 01-.75.75h-3a.75.75 0 110-1.5h2.25V13.5a.75.75 0 111.5 0v.75h2.25a.75.75 0 01.75.75zm0 3v1.5a.75.75 0 11-1.5 0V18a.75.75 0 111.5 0z"></path></svg></i></div></span></span>
                                        </div>
                                      </div>
                                      <div class="mt-16px flex justify-around gap-4px minPhone:hidden" data-v-55be6e78="">
                                        <button type="button" class="bit-button register-button w-[50%] bit-button--default bit-button--large is-round" data-v-55be6e78=""><!----><!----><!----><span>Sign Up</span><!---->
                                        </button>
                                        <button type="button" class="bit-button w-[50%] bit-button--primary bit-button--large is-round" data-v-55be6e78=""><!----><!----><!----><span>Login</span><!---->
                                        </button>
                                      </div>
                                    </div>
                                  </div> <!----></div>
                              </div>
                              <div class="top-banner-image w-500px h-500px h-1/1 flex pad:mt-24px phone:hidden phone:w-132px phone:h-132px" style="background-image: url(&quot;https://img.bitgetimg.com/multiLang/web/fc435e9f27bd2b1af619995b433ecdc0.png&quot;);" data-v-3ded291d=""></div> <!---->
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="swiper-slide box-border overflow-hidden swiper-slide-duplicate swiper-slide-duplicate-prev" data-v-759fbb3f="" data-swiper-slide-index="0" style="width: 1817px;">
                      <div class="mx-auto h-1/1" data-v-759fbb3f="">
                        <div class="mx-auto box-border" data-v-759fbb3f="">
                          <div id="contentBoxId" class="contentBox h-500px relative box-border flex overflow-hidden w-1/1 pad:h-906px  min-h-500px pad:min-h-906px phone:min-h-234px phone:h-234px cursor-pointer" style="background-color: rgb(255, 255, 255);" data-v-3ded291d="">
                            <div class="relative justify-between flex w-1200px mx-auto box-border <xl:w-full <xl:px-24px pad:flex-col pad:flex-col-reverse pad:justify-end pad:items-center pad:px-24px phone:justify-around phone:items-center phone:px-16px" data-v-3ded291d="">
                              <div class="w-600px z-1 h-360px flex flex-col justify-start mt-80px box-border <xl:w-528px !pad:mt-16px !pad:w-full pad:h-302px !phone:w-full !phone:mt-0 phone:h-222px" data-v-3ded291d="">
                                <div class="phone:flex phone:justify-between phone:items-center phone:gap-8px" data-v-3ded291d="">
                                  <div class="flex flex-col phone:max-w-218px" data-v-3ded291d="">
                                    <h1 class="m-0 line-clamp-2 flex flex-wrap text-56px font-600 leading-67px text-v3PrimaryText pad:text-48px pad:font-700 pad:leading-[120%] phone:font-700 phone:text-16px phone:leading-22px" data-v-3ded291d="">
                                      Cheers to Oktoberfest !
                                    </h1>
                                    <div class="line-clamp-2 mt-18px text-20px leading-[140%] text-v3PrimaryText phone:line-clamp-1 phone:mt-4px phone:text-12px" data-v-3ded291d="">
                                      Trade to win your favorite beers and Munich Trip fund！
                                    </div> <!----></div>
                                  <div class="top-banner-image w-500px h-500px mt-50px h-1/1 flex pad:mt-24px minPhone:hidden phone:w-132px phone:h-132px phone:mt-0" style="background-image: url(&quot;https://img.bitgetimg.com/multiLang/web/8a362d707de0b30ae0c15f6bf6fadb7d.png&quot;);" data-v-3ded291d=""></div>
                                </div>
                                <div data-v-71b06a1e="" data-v-3ded291d="" class="">
                                  <div class="w-1/1 pad:w-full phone:w-full" data-v-71b06a1e="">
                                    <div class="home-banner-login flex flex-col box-border text-v3PrimaryText font-400 leading-24px w-1/1 pc:mt-32px pad:w-full phone:w-full" data-v-55be6e78="" data-v-71b06a1e="">
                                      <span class="relative flex items-center text-20px leading-[140%] mr-8px cursor-pointer phone:text-12px phone:max-w-full phone:truncate" data-v-55be6e78=""><img src="/baseasset/img/v3-home/topbanner_rewards_icon_black.svg" loading="lazy" alt="Bitget Register Rewards10.6431780374331608" class="w-24px h-24px align-bottom mr-8px phone:w-14px" style="display: none;" data-v-55be6e78=""> <img src="../assets/img/topbanner_rewards_icon_white.svg" loading="lazy" alt="Bitget Register Rewards20.47659121214864175" class="w-24px h-24px align-bottom mr-8px phone:w-14px" style="" data-v-55be6e78=""> <span data-v-55be6e78="">Sign up now to claim a welcome pack of <span class="homepage-brand-color">6200 USDT</span>!</span></span>
                                      <div class="mt-24px w-1/1 flex flex-row box-border pad:mt-16px phone:hidden" data-v-55be6e78="">
                                        <div class="flex box-border w-full" data-v-55be6e78="">
                                          <div class="w-364px mr-8px pad:flex-auto phone:flex-auto phone:mr-6px bit-theme-light-vue2" style="background:transparent !important;" data-v-55be6e78="">
                                            <div class="home-login-input" style="background-color: rgb(255, 255, 255);" data-v-55be6e78="">
                                              <div class="bit-input bit-input--large bit-input--round" data-v-55be6e78=""><!----><!----><input type="text" autocomplete="off" placeholder="Email/Phone number" class="bit-input__inner"><!----><!----><!----><!----><!----><!---->
                                              </div>
                                            </div>
                                          </div>
                                          <div class="flex-shrink-0 w-160px <xl:w-140px pad:w-182px phone:w-117px" data-v-55be6e78="">
                                            <button type="button" class="bit-button resgiter-btn w-full bit-button--primary bit-button--large is-round" data-v-55be6e78=""><!----><!----><!----><span>Sign up</span><!---->
                                            </button>
                                          </div>
                                          <span class="pad:hidden <md:hidden" data-v-55be6e78=""><div role="tooltip" id="bit-popover-1837" aria-hidden="true" class="bit-popover bit-popper" style="width:120px;display:none;" tabindex="0"><!----><div class="bit-popover__message-text"><!----><div class="bit-popover__content"><div data-v-55be6e78="" class="flex flex-col justify-center items-center"><div data-v-55be6e78="" class="text-v3PrimaryText text-14px font-600 leading-20px">Scan to download</div> <div data-v-55be6e78="" class="w-108px h-108px box-border bg-v3ContentAlwaysWhite px-4px py-4px rounded-4px mt-12px mb-24px"><canvas height="100" width="100"></canvas></div> <button data-v-55be6e78="" type="button" class="bit-button bit-button--primary is-round"><!----><!----><!----><span><span data-v-55be6e78="" class="inline-block max-w-86px truncate">More downloads</span></span><!----></button></div> </div></div></div><span class="bit-popover__reference-wrapper"><div class="box-border w-48px h-48px rounded-1 flex justify-center items-center ml-8px bg-v3LinkDefaultText text-v3ContentAlwaysWhite bit-popover__reference" data-v-55be6e78="" aria-describedby="bit-popover-1837" tabindex="0"><i class="bit-icon" style="font-size:28px;" data-v-55be6e78=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" data-v-55be6e78=""><path d="M9.75 3.75h-4.5a1.5 1.5 0 00-1.5 1.5v4.5a1.5 1.5 0 001.5 1.5h4.5a1.5 1.5 0 001.5-1.5v-4.5a1.5 1.5 0 00-1.5-1.5zm0 6h-4.5v-4.5h4.5v4.5zm0 3h-4.5a1.5 1.5 0 00-1.5 1.5v4.5a1.5 1.5 0 001.5 1.5h4.5a1.5 1.5 0 001.5-1.5v-4.5a1.5 1.5 0 00-1.5-1.5zm0 6h-4.5v-4.5h4.5v4.5zm9-15h-4.5a1.5 1.5 0 00-1.5 1.5v4.5a1.5 1.5 0 001.5 1.5h4.5a1.5 1.5 0 001.5-1.5v-4.5a1.5 1.5 0 00-1.5-1.5zm0 6h-4.5v-4.5h4.5v4.5zm-6 6.75v-3a.75.75 0 111.5 0v3a.75.75 0 11-1.5 0zm7.5-1.5a.75.75 0 01-.75.75h-2.25v3.75a.75.75 0 01-.75.75h-3a.75.75 0 110-1.5h2.25V13.5a.75.75 0 111.5 0v.75h2.25a.75.75 0 01.75.75zm0 3v1.5a.75.75 0 11-1.5 0V18a.75.75 0 111.5 0z"></path></svg></i></div></span></span>
                                        </div>
                                      </div>
                                      <div class="mt-16px flex justify-around gap-4px minPhone:hidden" data-v-55be6e78="">
                                        <button type="button" class="bit-button register-button w-[50%] bit-button--default bit-button--large is-round" data-v-55be6e78=""><!----><!----><!----><span>Sign Up</span><!---->
                                        </button>
                                        <button type="button" class="bit-button w-[50%] bit-button--primary bit-button--large is-round" data-v-55be6e78=""><!----><!----><!----><span>Login</span><!---->
                                        </button>
                                      </div>
                                    </div>
                                  </div> <!----></div>
                              </div>
                              <div class="top-banner-image w-500px h-500px h-1/1 flex pad:mt-24px phone:hidden phone:w-132px phone:h-132px" style="background-image: url(&quot;https://img.bitgetimg.com/multiLang/web/8a362d707de0b30ae0c15f6bf6fadb7d.png&quot;);" data-v-3ded291d=""></div> <!---->
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="swiper-pagination-banner absolute text-center z-3 !bottom-20px !pad:bottom-24px swiper-container-pc-pagination !phone:-bottom-4px swiper-pagination-clickable swiper-pagination-bullets" style="display:;" data-v-759fbb3f="">
                    <span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 1"></span><span class="swiper-pagination-bullet swiper-pagination-bullet-active" tabindex="0" role="button" aria-label="Go to slide 2"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 3"></span>
                  </div>
                  <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
              </div>
            </div> <!----> <!---->
            <div class="minPhone:hidden">
              <div class="bit-theme-dark-vue2" data-v-7259d6c5="">
                <div class="messi-top-banner h-600px relative box-border flex overflow-hidden w-1/1 pb-32px bg-[#00040C] pad:max-h-928px pad:h-auto pad:pb-54px phone:max-h-680px phone:h-auto phone:pb-12px" data-v-7259d6c5="">
                  <div class="relative justify-between flex w-1200px mx-auto box-border <xl:w-full <xl:px-24px pad:flex-col pad:items-center pad:px-24px phone:flex-col phone:items-center phone:px-16px" data-v-7259d6c5="">
                    <div class="minPhone:hidden phone:w-full phone:flex phone:justify-between phone:items-center phone:gap-8px" data-v-7259d6c5="">
                      <div class="flex flex-col" data-v-7259d6c5="">
                        <h1 class="m-0 leading-67px text-[var(--ds-color-function-brand)] whitespace-pre-line pad:text-48px pad:font-700 pad:leading-[120%] minPhone:hidden phone:max-w-full phone:text-20px phone:font-700 phone:leading-[120%]" data-v-7259d6c5="">6 Years of Trust</h1>
                        <h1 class="m-0 leading-67px text-v3PrimaryText whitespace-pre-line pad:text-48px pad:font-700 pad:leading-[120%] minPhone:hidden phone:max-w-full phone:text-20px phone:font-700 phone:leading-[120%]" data-v-7259d6c5="">Trade Smarter with Bitget</h1>
                      </div>
                      <img alt="messi-banner-h50.5718947667932099" fetchpriority="high" width="132" height="132" src="/baseasset/img/v3-home/6th_anniversary_h5.png?t=20240910" class="top-banner-image pro:hidden air:hidden pad:hidden phone:w-132px phone:h-132px" data-v-7259d6c5="">
                    </div>
                    <div class="w-600px h-360px z-1 flex flex-col mt-120px box-border <xl:w-448px !pad:w-full pad:mt-0 pad:h-auto phone:w-full phone:mt-10px phone:h-auto" data-v-7259d6c5="">
                      <h1 class="text-56px font-600 leading-67px text-[var(--ds-color-function-brand)] whitespace-pre-line pad:text-48px pad:font-700 pad:leading-[120%] phone:hidden phone:max-w-full phone:font-700 phone:text-32px phone:font-700 phone:leading-38px" data-v-7259d6c5="">6 Years of Trust</h1>
                      <h1 class="text-56px font-600 leading-67px text-v3PrimaryText whitespace-pre-line pad:text-48px pad:font-700 pad:leading-[120%] phone:hidden phone:max-w-full phone:font-700 phone:text-32px phone:font-700 phone:leading-38px" data-v-7259d6c5="">Trade Smarter with Bitget</h1>
                      <div class="mt-120px w-1/1 pc:mt-32px air:mt-55px pad:w-full pad:mt-68px phone:w-full phone:mt-0px" data-v-7259d6c5="">
                        <div data-v-55be6e78="" data-v-7259d6c5="" class="home-banner-login flex flex-col box-border text-v3PrimaryText font-400 leading-24px w-1/1 pc:mt-32px pad:w-full phone:w-full">
                          <span data-v-55be6e78="" class="relative flex items-center text-20px leading-[140%] mr-8px cursor-pointer phone:text-12px phone:max-w-full phone:truncate"><img data-v-55be6e78="" src="/baseasset/img/v3-home/topbanner_rewards_icon_black.svg" loading="lazy" alt="Bitget Register Rewards10.2998460856583589" class="w-24px h-24px align-bottom mr-8px phone:w-14px"> <img data-v-55be6e78="" src="../assets/img/topbanner_rewards_icon_white.svg" loading="lazy" alt="Bitget Register Rewards20.9116310723976784" class="w-24px h-24px align-bottom mr-8px phone:w-14px" style="display: none;"> <span data-v-55be6e78="">Sign up now to claim a welcome pack of <span class="homepage-brand-color">6200 USDT</span>!</span></span>
                          <div data-v-55be6e78="" class="mt-24px w-1/1 flex flex-row box-border pad:mt-16px phone:hidden">
                            <div data-v-55be6e78="" class="flex box-border w-full">
                              <div data-v-55be6e78="" class="w-364px mr-8px pad:flex-auto phone:flex-auto phone:mr-6px bit-theme-light-vue2" style="background: transparent !important;">
                                <div data-v-55be6e78="" class="home-login-input">
                                  <div data-v-55be6e78="" class="bit-input bit-input--large bit-input--round"><!----><!----><input type="text" autocomplete="off" placeholder="Email/Phone number" class="bit-input__inner"><!----><!----><!----><!----><!----><!---->
                                  </div>
                                </div>
                              </div>
                              <div data-v-55be6e78="" class="flex-shrink-0 w-160px <xl:w-140px pad:w-182px phone:w-117px">
                                <button data-v-55be6e78="" type="button" class="bit-button resgiter-btn w-full bit-button--primary bit-button--large is-round"><!----><!----><!----><span>Sign up</span><!---->
                                </button>
                              </div>
                              <span data-v-55be6e78="" class="pad:hidden <md:hidden"><div role="tooltip" id="bit-popover-677" aria-hidden="true" class="bit-popover bit-popper" tabindex="0" style="width: 120px; display: none;"><!----><div class="bit-popover__message-text"><!----><div class="bit-popover__content"><div data-v-55be6e78="" class="flex flex-col justify-center items-center"><div data-v-55be6e78="" class="text-v3PrimaryText text-14px font-600 leading-20px">Scan to download</div> <div data-v-55be6e78="" class="w-108px h-108px box-border bg-v3ContentAlwaysWhite px-4px py-4px rounded-4px mt-12px mb-24px"><canvas height="100" width="100"></canvas></div> <button data-v-55be6e78="" type="button" class="bit-button bit-button--primary is-round"><!----><!----><!----><span><span data-v-55be6e78="" class="inline-block max-w-86px truncate">More downloads</span></span><!----></button></div> </div></div></div><span class="bit-popover__reference-wrapper"><div data-v-55be6e78="" class="box-border w-48px h-48px rounded-1 flex justify-center items-center ml-8px bg-v3LinkDefaultText text-v3ContentAlwaysWhite bit-popover__reference" aria-describedby="bit-popover-677" tabindex="0"><i data-v-55be6e78="" class="bit-icon" style="font-size: 28px;"><svg data-v-55be6e78="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M9.75 3.75h-4.5a1.5 1.5 0 00-1.5 1.5v4.5a1.5 1.5 0 001.5 1.5h4.5a1.5 1.5 0 001.5-1.5v-4.5a1.5 1.5 0 00-1.5-1.5zm0 6h-4.5v-4.5h4.5v4.5zm0 3h-4.5a1.5 1.5 0 00-1.5 1.5v4.5a1.5 1.5 0 001.5 1.5h4.5a1.5 1.5 0 001.5-1.5v-4.5a1.5 1.5 0 00-1.5-1.5zm0 6h-4.5v-4.5h4.5v4.5zm9-15h-4.5a1.5 1.5 0 00-1.5 1.5v4.5a1.5 1.5 0 001.5 1.5h4.5a1.5 1.5 0 001.5-1.5v-4.5a1.5 1.5 0 00-1.5-1.5zm0 6h-4.5v-4.5h4.5v4.5zm-6 6.75v-3a.75.75 0 111.5 0v3a.75.75 0 11-1.5 0zm7.5-1.5a.75.75 0 01-.75.75h-2.25v3.75a.75.75 0 01-.75.75h-3a.75.75 0 110-1.5h2.25V13.5a.75.75 0 111.5 0v.75h2.25a.75.75 0 01.75.75zm0 3v1.5a.75.75 0 11-1.5 0V18a.75.75 0 111.5 0z"></path></svg></i></div></span></span>
                            </div>
                          </div>
                          <div data-v-55be6e78="" class="mt-16px flex justify-around gap-4px minPhone:hidden">
                            <button data-v-55be6e78="" type="button" class="bit-button register-button w-[50%] bit-button--default bit-button--large is-round"><!----><!----><!----><span>Sign Up</span><!---->
                            </button>
                            <button data-v-55be6e78="" type="button" class="bit-button w-[50%] bit-button--primary bit-button--large is-round"><!----><!----><!----><span>Login</span><!---->
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <img alt="messi-banner-pc0.006486881576160952" fetchpriority="high" width="560" height="560" src="/baseasset/img/v3-home/6th_brand.png?t=20240910" class="top-banner-image w-560px h-560px flex <xl:-ml-120px air:w-488px air:h-488px air:mt-50px pad:order-first pad:ml-0 !pad:m-auto phone:hidden" data-v-7259d6c5="">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="h5-kong-zone px-6px minPhone:hidden phone:mt-32px" data-v-08a1c11c="">
            <div class="flex justify-between">
              <div class="container-item flex flex-col items-center flex-1 break-word">
                <a href="events/rewards" class="border border-solid border-v3StrengthBorder0 rounded-[50%] w-46px h-46px flex items-center justify-center text-v3PrimaryText"><i class="bit-icon" style="font-size:24px;">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M12.054 3.486a4.712 4.712 0 00-1.648-1.638C8.69.828 6.783 1.142 6.15 2.55c-.416.925-.182 2.09.514 3.07H3a1 1 0 00-1 1v5.53a1 1 0 001 1h1V21a1 1 0 001 1h14a1 1 0 001-1v-7.85h1a1 1 0 001-1V6.62a1 1 0 00-1-1h-3.555c.695-.98.93-2.145.514-3.07-.635-1.408-2.541-1.723-4.258-.702a4.712 4.712 0 00-1.647 1.638zM10.24 5.44c-.325.053-.801-.013-1.311-.315-.51-.303-.832-.712-.981-1.047-.148-.333-.092-.48-.08-.506.01-.025.083-.163.405-.216.324-.054.801.012 1.31.315.51.303.833.712.982 1.047.148.332.092.48.08.505-.01.026-.084.164-.405.217zM18 13.15V20h-5v-6.85h5zm-7 0V20H6v-6.85h5zm9-2H4V7.62h16v3.53zm-6.54-5.927c-.01-.025-.067-.173.081-.505.15-.335.472-.744.982-1.047.51-.303.986-.369 1.31-.315.322.053.395.19.406.216.012.026.068.173-.08.506-.15.335-.472.744-.982 1.047-.51.302-.986.368-1.31.315-.322-.053-.395-.191-.406-.217z"></path>
                  </svg>
                </i></a> <span class="mt-10px text-12px text-v3PrimaryText text-center px-3px">Rewards Center</span>
              </div>
              <div class="container-item flex flex-col items-center flex-1 break-word">
                <a href="events/referral-all-program" class="border border-solid border-v3StrengthBorder0 rounded-[50%] w-46px h-46px flex items-center justify-center text-v3PrimaryText"><img src="/baseasset/img/home/home-referral-light.png" alt="home-referral-dark" class="w-24px h-24px"></a>
                <span class="mt-10px text-12px text-v3PrimaryText text-center px-3px">Referral</span></div>
              <div class="container-item flex flex-col items-center flex-1 break-word">
                <a href="pre-market" class="border border-solid border-v3StrengthBorder0 rounded-[50%] w-46px h-46px flex items-center justify-center text-v3PrimaryText"><i class="bit-icon" style="font-size:24px;">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path fill-rule="evenodd" d="M4 5v2.5h16V5H4zm13-3v1h3a2 2 0 012 2v14a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h3V2a1 1 0 112 0v1h6V2a1 1 0 112 0zM4 9.5V19h16V9.5H4zm4.134 6a1 1 0 101.732 1l1-1.732 1.732 1a1 1 0 001.366-.366l1.5-2.598a1 1 0 10-1.732-1l-1 1.732-1.732-1a1 1 0 00-1.366.366l-1.5 2.598z" clip-rule="evenodd"></path>
                  </svg>
                </i></a> <span class="mt-10px text-12px text-v3PrimaryText text-center px-3px">Pre-Market</span></div>
              <div class="container-item flex flex-col items-center flex-1 break-word">
                <a href="events/futures-tutorial?source=2" class="border border-solid border-v3StrengthBorder0 rounded-[50%] w-46px h-46px flex items-center justify-center text-v3PrimaryText"><i class="bit-icon" style="font-size:24px;">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M6 8a1 1 0 011-1h5a1 1 0 110 2H7a1 1 0 01-1-1zM7 12a1 1 0 100 2h5a1 1 0 100-2H7z"></path>
                    <path d="M3 22a1 1 0 01-1-1V3a1 1 0 011-1h13a1 1 0 011 1v11h4a1 1 0 011 1v6a1 1 0 01-1 1H3zm1-2h11V4H4v16zm13 0h3v-4h-3v4z"></path>
                  </svg>
                </i></a> <span class="mt-10px text-12px text-v3PrimaryText text-center px-3px">Futures Kickoff</span>
              </div>
            </div>
            <div class="mt-12px flex justify-between">
              <div class="container-item flex flex-col items-center flex-1 break-word">
                <a href="earning?source1=earn&amp;source2=earn_overview" class="border border-solid border-v3StrengthBorder0 rounded-[50%] w-46px h-46px flex items-center justify-center text-v3PrimaryText"><i class="bit-icon" style="font-size:24px;">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M10 9.457l2.457 2.456 2.456-2.456L12.457 7 10 9.457z"></path>
                    <path d="M20.14 13.229a8.5 8.5 0 10-14.338 1.506 3.996 3.996 0 00-1.312 1.572L4.166 17H2a1 1 0 100 2h2.484a1.5 1.5 0 001.36-.865l.458-.981A2 2 0 018.114 16h5.267l.004 1h-2.072a1 1 0 100 2h3.68c.222 0 .437-.072.614-.205l4.675-3.506a.486.486 0 01.604.76l-4.49 3.77A5.05 5.05 0 0113.148 21H2a1 1 0 100 2h11.149a7.05 7.05 0 004.532-1.65l4.49-3.769a2.486 2.486 0 00-2.03-4.352zM12.5 3a6.5 6.5 0 012.805 12.366A1.9 1.9 0 0013.482 14H8.114c-.099 0-.197.004-.294.01A6.5 6.5 0 0112.5 3z"></path>
                  </svg>
                </i></a> <span class="mt-10px text-12px text-v3PrimaryText  text-center px-3px">Earn</span></div>
              <div class="container-item flex flex-col items-center flex-1 break-word">
                <a href="events/deposit" class="border border-solid border-v3StrengthBorder0 rounded-[50%] w-46px h-46px flex items-center justify-center text-v3PrimaryText"><i class="bit-icon" style="font-size:24px;">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path fill-rule="evenodd" d="M13.5 6a2.5 2.5 0 100-5 2.5 2.5 0 000 5zm0-1.5a1 1 0 110-2 1 1 0 010 2zM11.81 13.37a3 3 0 015.87-1.25 1 1 0 101.956-.416 5 5 0 00-9.781 2.083 1 1 0 101.956-.417z" clip-rule="evenodd"></path>
                    <path fill-rule="evenodd" d="M2 15.722a2 2 0 012.598-1.909l4.414 1.383a10 10 0 005.976 0l4.414-1.383A2 2 0 0122 15.723V21a2 2 0 01-2 2H4a2 2 0 01-2-2v-5.278zm18 0l-4.414 1.382a12 12 0 01-7.172 0L4 15.722V21h16v-5.278zM10 7.5a3.5 3.5 0 11-7 0 3.5 3.5 0 017 0zm-2 0a1.5 1.5 0 10-3 0 1.5 1.5 0 003 0z" clip-rule="evenodd"></path>
                  </svg>
                </i></a> <span class="mt-10px text-12px text-v3PrimaryText  text-center px-3px">Deposit to List</span>
              </div>
              <div class="container-item flex flex-col items-center flex-1 break-word">
                <a href="buy-sell-crypto/cashier" class="border border-solid border-v3StrengthBorder0 rounded-[50%] w-46px h-46px flex items-center justify-center text-v3PrimaryText"><i class="bit-icon" style="font-size:24px;">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M13 3a1 1 0 10-2 0v8H3a1 1 0 100 2h8v8a1 1 0 102 0v-8h8a1 1 0 100-2h-8V3z"></path>
                  </svg>
                </i></a> <span class="mt-10px text-12px text-v3PrimaryText text-center px-3px">Quick buy</span></div>
              <div class="container-item flex flex-col items-center flex-1 break-word">
                <a href="/copy-trading/futures" class="border border-solid border-v3StrengthBorder0 rounded-[50%] w-46px h-46px flex items-center justify-center text-v3PrimaryText"><i class="bit-icon" style="font-size:24px;">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M12.755 9.042a1 1 0 01.336 1.374l-2.12 3.494-3.256-1.335-1.208 1.46a1 1 0 11-1.541-1.275l2.146-2.593 3.036 1.244 1.234-2.033a1 1 0 011.373-.336z"></path>
                    <path fill-rule="evenodd" d="M.22 5.138a2 2 0 011.707-2.255l11.368-1.574a2 2 0 012.255 1.707l.432 3.121 6.297 1.554a2 2 0 011.466 2.407L21.12 21.074a2 2 0 01-2.354 1.492l-5.224-1.092a.875.875 0 01-.024-.005L4.67 22.694a2 2 0 01-2.255-1.707L.22 5.138zm17.21 15.106l1.745.365L21.8 9.633 16.277 8.27l1.467 10.595c.07.502-.054.987-.314 1.379zM13.57 3.29L2.201 4.864l2.194 15.849 11.368-1.574L13.57 3.29z" clip-rule="evenodd"></path>
                  </svg>
                </i></a> <span class="mt-10px text-12px text-v3PrimaryText text-center px-3px">Copy trading</span></div>
            </div>
          </div>
          <div data-fetch-key="0" class="trad max-w-[calc(100%-48px)] w-1200px !mx-auto <xl:mx-24px <lg-new:w-895px phone:mx-16px phone:mt-32px phone:w-full phone:max-w-[calc(100%-32px)]" data-v-08a1c11c="">
            <div class="trad-card relative" data-v-0863e2f6="">
              <div class="swiper-container-con swiper-container-initialized swiper-container-horizontal" data-v-0863e2f6="">
                <div class="swiper-wrapper" data-v-0863e2f6="" style="transform: translate3d(0px, 0px, 0px);">
                  <div class="trad-card-con swiper-slide swiper-slide-active" style="margin-right: 16px;" data-v-0863e2f6="">
                    <div class="trad-card-con-item" data-v-0863e2f6="">
                      <a href="/asia/events/launchpool/1220235662020993024" target="_blank" class="bit-link bit-link--default" data-v-0863e2f6=""><span class="bit-link--inner"><img fetchpriority="high" width="288" height="144" src="https://img.bitgetimg.com/multiLang/web/51d42f3d4222b421f645aa50d52fd7e3.png" alt="trad-card-con-item-img-1" class="trad-card-con-item-img" data-v-0863e2f6=""></span>
                      </a></div>
                  </div>
                  <div class="trad-card-con swiper-slide swiper-slide-next" style="margin-right: 16px;" data-v-0863e2f6="">
                    <div class="trad-card-con-item" data-v-0863e2f6="">
                      <a href="/asia/events/activities/6d21afc220ab54c6a2fcefcf50af0d1f?color=black" target="_blank" class="bit-link bit-link--default" data-v-0863e2f6=""><span class="bit-link--inner"><img fetchpriority="high" width="288" height="144" src="https://img.bitgetimg.com/multiLang/web/fbd9e793765b41b672247285a528c3b0.jpg" alt="trad-card-con-item-img-2" class="trad-card-con-item-img" data-v-0863e2f6=""></span>
                      </a></div>
                  </div>
                  <div class="trad-card-con swiper-slide" style="margin-right: 16px;" data-v-0863e2f6="">
                    <div class="trad-card-con-item" data-v-0863e2f6="">
                      <a href="/asia/events/activities/e25a51d3003b5823bd073962afb707b8?color=black" target="_blank" class="bit-link bit-link--default" data-v-0863e2f6=""><span class="bit-link--inner"><img fetchpriority="high" width="288" height="144" src="https://img.bitgetimg.com/multiLang/web/f5d09323c83e49b1dde936bcacbe969b.jpg" alt="trad-card-con-item-img-3" class="trad-card-con-item-img" data-v-0863e2f6=""></span>
                      </a></div>
                  </div>
                  <div class="trad-card-con swiper-slide" style="margin-right: 16px;" data-v-0863e2f6="">
                    <div class="trad-card-con-item" data-v-0863e2f6="">
                      <a href="/asia/events/activities/685ec5af1c205faeaa0722cd09af5a12?color=black" target="_blank" class="bit-link bit-link--default" data-v-0863e2f6=""><span class="bit-link--inner"><img fetchpriority="high" width="288" height="144" src="https://img.bitgetimg.com/multiLang/web/053625720431387c124a5ee8aab78633.jpg" alt="trad-card-con-item-img-4" class="trad-card-con-item-img" data-v-0863e2f6=""></span>
                      </a></div>
                  </div>
                </div>
                <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
              <div class="home-swiper-btn btn-prev flex rtl-rotate ltr:flex-row rtl:flex-row-reverse" data-v-0863e2f6="" tabindex="0" role="button" aria-label="Previous slide" aria-disabled="true">
                <div class="text-primaryText" data-v-0863e2f6="">
                  <i class="bit-icon" style="font-size:18px;" data-v-0863e2f6="">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" data-v-0863e2f6="">
                      <path d="M15.53 18.97a.75.75 0 11-1.06 1.06l-7.5-7.5a.75.75 0 010-1.06l7.5-7.5a.75.75 0 111.06 1.06L8.56 12l6.97 6.97z"></path>
                    </svg>
                  </i></div>
              </div>
              <div class="home-swiper-btn btn-next flex rtl-rotate ltr:flex-row rtl:flex-row-reverse" data-v-0863e2f6="" tabindex="0" role="button" aria-label="Next slide" aria-disabled="true">
                <div class="text-primaryText" data-v-0863e2f6="">
                  <i class="bit-icon" style="font-size:18px;" data-v-0863e2f6="">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" data-v-0863e2f6="">
                      <path d="M17.03 12.53l-7.5 7.5a.75.75 0 11-1.06-1.06L15.44 12 8.47 5.03a.75.75 0 111.06-1.06l7.5 7.5a.75.75 0 010 1.06z"></path>
                    </svg>
                  </i></div>
              </div>
              <div class="pagination-box" data-v-0863e2f6="">
                <div class="swiper-pagination-1 swiper-pagination-bullets" data-v-0863e2f6="">
                  <span class="swiper-pagination-bullet swiper-pagination-bullet-active"></span></div>
              </div>
            </div>
            <div class="trad-horn">
              <div class="flex flex-row justify-between mt-24px phone:mt-16px" data-v-6ca8e267="">
                <div class="notice w-7/10 !minIpad:w-1/1" data-v-6ca8e267="">
                  <img src="../assets/img/notice.png" loading="lazy" alt="home-hornBlack" class="notice-img rtl-rotate" data-v-6ca8e267="">
                  <div class="notice-container bit-carousel bit-carousel--vertical" data-v-6ca8e267="">
                    <div class="bit-carousel__container">
                      <div class="bit-carousel__item notice-container-item is-animating" style="transform: translateY(-32px) scale(1);" data-v-6ca8e267="">
                        <a href="/asia/support/articles/12560603813487" target="_blank" rel="noopener" class="notice-container-item-sp_box notice-container-item-sp_box-text leading-normal-14px relative text-14px font-normal-400 not-italic text-primaryText phone:text-12px bit-link bit-link--default is-underline" data-v-6ca8e267=""><span class="bit-link--inner">
                    Bitget to launch USDC/USDT spot trading zero transaction fee promotion
                </span></a></div>
                      <div class="bit-carousel__item notice-container-item is-active is-animating" style="transform: translateY(0px) scale(1);" data-v-6ca8e267="">
                        <a href="/asia/support/articles/12560603805495" target="_blank" rel="noopener" class="notice-container-item-sp_box notice-container-item-sp_box-text leading-normal-14px relative text-14px font-normal-400 not-italic text-primaryText phone:text-12px bit-link bit-link--default is-underline" data-v-6ca8e267=""><span class="bit-link--inner">
                    Spot copy trading: Leverage elite experts' investment wisdom and techniques
                </span></a></div>
                    </div>
                  </div>
                </div>
                <div class="trad-card-footer-seemore w-3/10 flex justify-end text-primary" data-v-6ca8e267="">
                  <a href="/asia/support/categories/360002621832" target="_blank" class="flex items-center text-primary text-16px whitespace-nowrap phone:text-12px" data-v-6ca8e267="">
                    View more
                    <i class="bit-icon ml-10px rtl-rotate" style="font-size:18px;" data-v-6ca8e267="">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" data-v-6ca8e267="">
                        <path d="M20.78 12.53l-6.75 6.75a.75.75 0 01-1.06-1.06l5.47-5.47H3.75a.75.75 0 110-1.5h14.69l-5.47-5.47a.75.75 0 111.06-1.06l6.75 6.75a.747.747 0 010 1.06z"></path>
                      </svg>
                    </i></a></div>
              </div>
            </div>
          </div>
          <div class="phone:hidden home-trend" data-v-08a1c11c="">
            <div class="v2-home-markets mx-auto max-w-1200px box-border mt-140px <xl:w-full <xl:max-w-none <xl:px-24px <xl:mt-90px pad:mt-80px phone:mt-58px phone:px-16px" data-v-08a1c11c="">
              <div>
                <h1 class="market-title text-primaryText leading-58px text-48px font-600 mb-32px atIpad:text-40px atIpad:leading-48px phone:mb-16px phone:text-32px phone:leading-40px">
                  Popular Cryptocurrencies
                </h1></div>
              <div>
                <div data-micro-type="RecommendCoins" class="micro micro-light" data-micro-id="135981258">
                  <div class="flex gap-16px flex-col lg:flex-row mb-32px phone:mb-16px !hidden">
                    <div class="lg:w-[calc(50%-8px)] hidden">
                      <div data-v-e20b0ac4="" class="w-auto overflow-hidden flex flex-1 flex-col gap-15px md:gap-23px coin-card border-1px border-solid border-borderStrengthOne px-16px py-15px md:p-24px cursor-pointer !pb-15px bg-bg rounded-8px">
                        <div data-v-e20b0ac4="" class="flex flex-1 overflow-hidden items-start gap-12px md:!gap-20px lg:!gap-12px 2xl:!gap-20px">
                          <div data-v-e20b0ac4="" class="mi-skeleton w-40px h-40px md:w-48px md:h-48px w-40px h-40px md:w-48px md:h-48px">
                            <div data-v-e20b0ac4="" class="mi-skeleton__item mi-skeleton__circle mi-skeleton__circle--default w-40px h-40px md:w-48px md:h-48px"><!--v-if--></div>
                          </div>
                          <div data-v-e20b0ac4="" class="flex flex-1 flex-col gap-12px md:gap-16px overflow-hidden">
                            <div class="flex gap-24px md:!gap-64px lg:!gap-48px 2xl:!gap-64px">
                              <div class="flex flex-col gap-y-4px max-w-70px whitespace-nowrap">
                                <div class="text-ellipsis overflow-hidden text-14px leading-20px text-dsColorTextPrimary font-600">--</div>
                                <div class="text-ellipsis overflow-hidden text-12px leading-120% text-dsColorTextTertiary">--</div>
                              </div>
                              <div class="flex flex-col gap-y-4px">
                                <div class="text-ellipsis overflow-hidden text-14px leading-20px text-dsColorTextPrimary font-600">--</div>
                                <div class="text-ellipsis overflow-hidden text-12px leading-120% text-dsColorTextTertiary">Last price</div>
                              </div>
                              <div class="flex flex-col gap-y-4px">
                                <div class="text-14px leading-20px text-contentInverseTertiary font-600">--</div>
                                <div class="text-ellipsis overflow-hidden text-12px leading-120% text-dsColorTextTertiary">24h rise</div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div data-v-e20b0ac4="" class="pt-16px border-t-1px border-line border-[#DEDFE0]">
                          <div data-v-f24d17e3="" data-v-e20b0ac4="" class="flex items-center flex-nowrap cursor-pointer">
                            <svg data-v-f24d17e3="" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" class="w-16px h-16px text-primaryText">
                              <rect x="1.5" y="4.95453" width="2.36364" height="4.72727" fill="var(--content-primary)"></rect>
                              <path d="M5.04565 4.65909L11.2198 2.13331C11.3753 2.06969 11.5457 2.18406 11.5457 2.35207V12.2843C11.5457 12.4523 11.3753 12.5667 11.2198 12.5031L5.04565 9.97727V4.65909Z" fill="var(--content-primary)"></path>
                              <path d="M4.32642 10.2727L4.0309 12.0455" stroke="var(--content-primary)" stroke-width="1.77273" stroke-linecap="square"></path>
                              <path fill-rule="evenodd" clip-rule="evenodd" d="M12.1365 9.6818C12.1365 9.6818 12.1366 9.6818 12.1367 9.6818C13.4421 9.6818 14.5003 8.62357 14.5003 7.31817C14.5003 6.01276 13.4421 4.95453 12.1367 4.95453C12.1366 4.95453 12.1365 4.95453 12.1365 4.95453V9.6818Z" fill="#8E8E92"></path>
                            </svg>
                            <div data-v-f24d17e3="" class="h-16px text-ellipsis overflow-hidden whitespace-nowrap mx-4px flex-1 text-12px leading-16px text-dsColorTextPrimary">--</div>
                            <i data-v-f24d17e3="" class="mi-icon cursor-pointer color-contentTertiary" style="font-size: 12px;">
                              <svg data-v-f24d17e3="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                                <path d="M17.03 12.53l-7.5 7.5a.75.75 0 11-1.06-1.06L15.44 12 8.47 5.03a.75.75 0 111.06-1.06l7.5 7.5a.75.75 0 010 1.06z"></path>
                              </svg>
                            </i></div>
                        </div>
                      </div>
                    </div>
                    <div class="lg:w-[calc(50%-8px)] hidden">
                      <div data-v-e20b0ac4="" class="w-auto overflow-hidden flex flex-1 flex-col gap-15px md:gap-23px coin-card border-1px border-solid border-borderStrengthOne px-16px py-15px md:p-24px cursor-pointer !pb-15px bg-bg rounded-8px">
                        <div data-v-e20b0ac4="" class="flex flex-1 overflow-hidden items-start gap-12px md:!gap-20px lg:!gap-12px 2xl:!gap-20px">
                          <div data-v-e20b0ac4="" class="mi-skeleton w-40px h-40px md:w-48px md:h-48px w-40px h-40px md:w-48px md:h-48px">
                            <div data-v-e20b0ac4="" class="mi-skeleton__item mi-skeleton__circle mi-skeleton__circle--default w-40px h-40px md:w-48px md:h-48px"><!--v-if--></div>
                          </div>
                          <div data-v-e20b0ac4="" class="flex flex-1 flex-col gap-12px md:gap-16px overflow-hidden">
                            <div class="min-h-38px"></div>
                          </div>
                        </div>
                        <div data-v-e20b0ac4="" class="pt-16px border-t-1px border-line border-[#DEDFE0]">
                          <div data-v-f24d17e3="" data-v-e20b0ac4="" class="flex items-center flex-nowrap cursor-pointer">
                            <svg data-v-f24d17e3="" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" class="w-16px h-16px text-primaryText">
                              <rect x="1.5" y="4.95453" width="2.36364" height="4.72727" fill="var(--content-primary)"></rect>
                              <path d="M5.04565 4.65909L11.2198 2.13331C11.3753 2.06969 11.5457 2.18406 11.5457 2.35207V12.2843C11.5457 12.4523 11.3753 12.5667 11.2198 12.5031L5.04565 9.97727V4.65909Z" fill="var(--content-primary)"></path>
                              <path d="M4.32642 10.2727L4.0309 12.0455" stroke="var(--content-primary)" stroke-width="1.77273" stroke-linecap="square"></path>
                              <path fill-rule="evenodd" clip-rule="evenodd" d="M12.1365 9.6818C12.1365 9.6818 12.1366 9.6818 12.1367 9.6818C13.4421 9.6818 14.5003 8.62357 14.5003 7.31817C14.5003 6.01276 13.4421 4.95453 12.1367 4.95453C12.1366 4.95453 12.1365 4.95453 12.1365 4.95453V9.6818Z" fill="#8E8E92"></path>
                            </svg>
                            <div data-v-f24d17e3="" class="h-16px text-ellipsis overflow-hidden whitespace-nowrap mx-4px flex-1 text-12px leading-16px text-dsColorTextPrimary">--</div>
                            <i data-v-f24d17e3="" class="mi-icon cursor-pointer color-contentTertiary" style="font-size: 12px;">
                              <svg data-v-f24d17e3="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                                <path d="M17.03 12.53l-7.5 7.5a.75.75 0 11-1.06-1.06L15.44 12 8.47 5.03a.75.75 0 111.06-1.06l7.5 7.5a.75.75 0 010 1.06z"></path>
                              </svg>
                            </i></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div style="top: 64px;" class="">
                <div class="market-v2-tab pb-16px bg-v3levelsurface0 pt-8px phone:pb-16px" data-v-08ab0a86="">
                  <div class="flex flex-row" data-v-08ab0a86="">
                    <a href="" class="alink px-16px py-11px min-w-60px text-14px box-border h-42px cursor-pointer flex justify-center items-center rounded-35px bg-v3levelsurface0 text-v3TertiaryText mr-12px !phone:px-16px !phone:py-8px !phone:min-w-42px !phone:text-14px !phone:rounded-38px !phone:h-32px active" data-v-08ab0a86="">
                      Gainers
                    </a><a href="" class="alink px-16px py-11px min-w-60px text-14px box-border h-42px cursor-pointer flex justify-center items-center rounded-35px bg-v3levelsurface0 text-v3TertiaryText mr-12px !phone:px-16px !phone:py-8px !phone:min-w-42px !phone:text-14px !phone:rounded-38px !phone:h-32px" data-v-08ab0a86="">
                    Losers
                  </a><a href="" class="alink px-16px py-11px min-w-60px text-14px box-border h-42px cursor-pointer flex justify-center items-center rounded-35px bg-v3levelsurface0 text-v3TertiaryText mr-12px !phone:px-16px !phone:py-8px !phone:min-w-42px !phone:text-14px !phone:rounded-38px !phone:h-32px" data-v-08ab0a86="">
                    New Listing
                  </a><a href="" class="alink px-16px py-11px min-w-60px text-14px box-border h-42px cursor-pointer flex justify-center items-center rounded-35px bg-v3levelsurface0 text-v3TertiaryText mr-12px !phone:px-16px !phone:py-8px !phone:min-w-42px !phone:text-14px !phone:rounded-38px !phone:h-32px" data-v-08ab0a86="">
                    Volume
                  </a></div>
                </div>
              </div>
              <div style="min-height: 194px;">
                <div data-v-0e18dafb="" class="v3-marketList-box">
                  <div data-v-0e18dafb="">
                    <div data-v-0e18dafb="">
                      <div data-v-539e5ed0="" data-v-0e18dafb="" class="v3-marketTable-box">
                        <div data-v-539e5ed0="" class="bit-table bit-table--fit bit-table--header-border bit-table--enable-row-transition" style="width: 100%;">
                          <div class="hidden-columns">
                            <div data-v-539e5ed0=""></div>
                            <div data-v-539e5ed0=""></div>
                            <div data-v-539e5ed0=""></div>
                            <div data-v-539e5ed0=""></div>
                            <div data-v-539e5ed0=""></div>
                            <div data-v-539e5ed0=""></div>
                          </div>
                          <div class="bit-table__header-wrapper">
                            <table cellspacing="0" cellpadding="0" border="0" class="bit-table__header" style="width: 1173px;">
                              <colgroup>
                                <col name="bit-table_1_column_1" width="37">
                                <col name="bit-table_1_column_2" width="210">
                                <col name="bit-table_1_column_3" width="248">
                                <col name="bit-table_1_column_4" width="279">
                                <col name="bit-table_1_column_5" width="279">
                                <col name="bit-table_1_column_6" width="120">
                                <col name="gutter" width="0">
                              </colgroup>
                              <thead class="has-gutter">
                              <tr class="">
                                <th colspan="1" rowspan="1" class="bit-table_1_column_1  is-right   is-hidden is-leaf bit-table__cell">
                                  <div class="cell">#</div>
                                </th>
                                <th colspan="1" rowspan="1" class="bit-table_1_column_2     is-hidden is-leaf bit-table__cell">
                                  <div class="cell">Name</div>
                                </th>
                                <th colspan="1" rowspan="1" class="bit-table_1_column_3     is-leaf is-sortable bit-table__cell">
                                  <div class="cell">Last price<span class="caret-wrapper"><i class="bit-icon sort-caret ascending" style="font-size: 8px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M1.364 17.586C.414 19.046 1.435 21 3.147 21h17.707c1.711 0 2.732-1.955 1.783-3.414L13.783 3.978a2.115 2.115 0 00-3.566 0L1.364 17.586z"></path></svg></i><i class="bit-icon sort-caret descending" style="font-size: 8px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M22.637 6.414C23.586 4.954 22.565 3 20.853 3H3.148C1.435 3 .414 4.955 1.364 6.414l8.853 13.608a2.115 2.115 0 003.566 0l8.854-13.608z"></path></svg></i></span>
                                  </div>
                                </th>
                                <th colspan="1" rowspan="1" class="bit-table_1_column_4     is-leaf is-sortable bit-table__cell">
                                  <div class="cell">Today<span class="caret-wrapper"><i class="bit-icon sort-caret ascending" style="font-size: 8px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M1.364 17.586C.414 19.046 1.435 21 3.147 21h17.707c1.711 0 2.732-1.955 1.783-3.414L13.783 3.978a2.115 2.115 0 00-3.566 0L1.364 17.586z"></path></svg></i><i class="bit-icon sort-caret descending" style="font-size: 8px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M22.637 6.414C23.586 4.954 22.565 3 20.853 3H3.148C1.435 3 .414 4.955 1.364 6.414l8.853 13.608a2.115 2.115 0 003.566 0l8.854-13.608z"></path></svg></i></span>
                                  </div>
                                </th>
                                <th colspan="1" rowspan="1" class="bit-table_1_column_5     is-leaf is-sortable bit-table__cell">
                                  <div class="cell">24h volume<span class="caret-wrapper"><i class="bit-icon sort-caret ascending" style="font-size: 8px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M1.364 17.586C.414 19.046 1.435 21 3.147 21h17.707c1.711 0 2.732-1.955 1.783-3.414L13.783 3.978a2.115 2.115 0 00-3.566 0L1.364 17.586z"></path></svg></i><i class="bit-icon sort-caret descending" style="font-size: 8px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M22.637 6.414C23.586 4.954 22.565 3 20.853 3H3.148C1.435 3 .414 4.955 1.364 6.414l8.853 13.608a2.115 2.115 0 003.566 0l8.854-13.608z"></path></svg></i></span>
                                  </div>
                                </th>
                                <th colspan="1" rowspan="1" class="bit-table_1_column_6     is-leaf bit-table__cell">
                                  <div class="cell">Action</div>
                                </th>
                                <th class="bit-table__cell gutter" style="width: 0px; display: none;"></th>
                              </tr>
                              </thead>
                            </table>
                          </div>
                          <div class="bit-table__body-wrapper is-scrolling-none">
                            <table cellspacing="0" cellpadding="0" border="0" class="bit-table__body" style="width: 1173px;">
                              <colgroup>
                                <col name="bit-table_1_column_1" width="37">
                                <col name="bit-table_1_column_2" width="210">
                                <col name="bit-table_1_column_3" width="248">
                                <col name="bit-table_1_column_4" width="279">
                                <col name="bit-table_1_column_5" width="279">
                                <col name="bit-table_1_column_6" width="120">
                              </colgroup>
                              <tbody>
                              <tr class="bit-table__row" style="height: 80px;">
                                <td rowspan="1" colspan="1" class="bit-table_1_column_1 is-right  is-hidden bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-v3TertiaryText text-12px leading-16px isIndexActive">
                        1
                    </span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_2   is-hidden bit-table__cell">
                                  <div class="cell">
                                    <div data-v-539e5ed0="" class="flex flex-row items-center">
                                      <img data-v-539e5ed0="" alt="symbol" loading="lazy" src="https://img.bitgetimg.com/multiLang/web/0b5daaea87e8b5d16defb2b1ec9b6f5f.png" class="w-28px h-28px mr-8px rounded-28px">
                                      <span data-v-539e5ed0="" class="flex flex-wrap items-center text-16px font-500 text-primaryText"><span data-v-539e5ed0="" class="flex items-center">
                                    RBTC
                                     <span data-v-539e5ed0="" class="font-400 text-12px text-v3TertiaryText">
                                        / USDT
                                       </span></span> <img data-v-539e5ed0="" src="https://img.bitgetimg.com/multiLang/web/c5006cc153f4fa04e28d23751a6a094a.png" alt="RBTCNEWUSDT_SPBL_label_icon" loading="lazy" class="relative h-16px ml-4px"></span>
                                    </div>
                                  </div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_3   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText flex flex-row"><div data-v-539e5ed0="" class="mr-3px">
                            0.0000053523
                        </div></span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_4   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-22px text-primaryText floatNum"><span data-v-539e5ed0="" dir="ltr" class="text-v3TradeBuyText">+2576.15%
</span></span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_5   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText">
                        281.59B
                    </span>
                                    <span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText" style="display: none;">
                        1.84M
                    </span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_6   bit-table__cell">
                                  <div class="cell">
                                    <a data-v-539e5ed0="" href="https://www.bitget.com/asia/spot/RBTCUSDT">
                                      <div data-v-539e5ed0="" class="gotoLinkBox"><span data-v-539e5ed0="" class="text-12px font-500 leading-20px !text-primaryHoverBg font-500 cursor-pointer gotoLink">
                                Trade
                            </span></div>
                                    </a></div>
                                </td>
                              </tr>
                              <tr class="bit-table__row" style="height: 80px;">
                                <td rowspan="1" colspan="1" class="bit-table_1_column_1 is-right  is-hidden bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-v3TertiaryText text-12px leading-16px isIndexActive">
                        2
                    </span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_2   is-hidden bit-table__cell">
                                  <div class="cell">
                                    <div data-v-539e5ed0="" class="flex flex-row items-center">
                                      <img data-v-539e5ed0="" alt="symbol" loading="lazy" src="https://img.bitgetimg.com/multiLang/web/50860ce741334bee7cb1300669c0357c.png" class="w-28px h-28px mr-8px rounded-28px">
                                      <span data-v-539e5ed0="" class="flex flex-wrap items-center text-16px font-500 text-primaryText"><span data-v-539e5ed0="" class="flex items-center">
                                    WAT
                                     <span data-v-539e5ed0="" class="font-400 text-12px text-v3TertiaryText">
                                        / USDT
                                       </span></span> <img data-v-539e5ed0="" src="https://img.bitgetimg.com/multiLang/web/8209f82e444e768cb948f6bceb8b222d.png" alt="WATUSDT_SPBL_label_icon" loading="lazy" class="relative h-16px ml-4px"></span>
                                    </div>
                                  </div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_3   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText flex flex-row"><div data-v-539e5ed0="" class="mr-3px">
                            0.00075100
                        </div></span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_4   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-22px text-primaryText floatNum"><span data-v-539e5ed0="" dir="ltr" class="text-v3TradeBuyText">+838.75%
</span></span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_5   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText">
                        4.16B
                    </span>
                                    <span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText" style="display: none;">
                        4.73M
                    </span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_6   bit-table__cell">
                                  <div class="cell">
                                    <a data-v-539e5ed0="" href="https://www.bitget.com/asia/spot/WATUSDT">
                                      <div data-v-539e5ed0="" class="gotoLinkBox"><span data-v-539e5ed0="" class="text-12px font-500 leading-20px !text-primaryHoverBg font-500 cursor-pointer gotoLink">
                                Trade
                            </span></div>
                                    </a></div>
                                </td>
                              </tr>
                              <tr class="bit-table__row" style="height: 80px;">
                                <td rowspan="1" colspan="1" class="bit-table_1_column_1 is-right  is-hidden bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-v3TertiaryText text-12px leading-16px isIndexActive">
                        3
                    </span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_2   is-hidden bit-table__cell">
                                  <div class="cell">
                                    <div data-v-539e5ed0="" class="flex flex-row items-center">
                                      <img data-v-539e5ed0="" alt="symbol" loading="lazy" src="https://img.bitgetimg.com/multiLang/coin_img/21bdfba4d8c2632e2c907e69c4dc381a.png" class="w-28px h-28px mr-8px rounded-28px">
                                      <span data-v-539e5ed0="" class="flex flex-wrap items-center text-16px font-500 text-primaryText"><span data-v-539e5ed0="" class="flex items-center">
                                    CEL
                                     <span data-v-539e5ed0="" class="font-400 text-12px text-v3TertiaryText">
                                        / USDT
                                       </span></span> </span></div>
                                  </div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_3   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText flex flex-row"><div data-v-539e5ed0="" class="mr-3px">
                            0.5810
                        </div></span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_4   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-22px text-primaryText floatNum"><span data-v-539e5ed0="" dir="ltr" class="text-v3TradeBuyText">+56.65%
</span></span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_5   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText">
                        1.11M
                    </span>
                                    <span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText" style="display: none;">
                        587.51K
                    </span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_6   bit-table__cell">
                                  <div class="cell">
                                    <a data-v-539e5ed0="" href="https://www.bitget.com/asia/spot/CELUSDT">
                                      <div data-v-539e5ed0="" class="gotoLinkBox"><span data-v-539e5ed0="" class="text-12px font-500 leading-20px !text-primaryHoverBg font-500 cursor-pointer gotoLink">
                                Trade
                            </span></div>
                                    </a></div>
                                </td>
                              </tr>
                              <tr class="bit-table__row" style="height: 80px;">
                                <td rowspan="1" colspan="1" class="bit-table_1_column_1 is-right  is-hidden bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-v3TertiaryText text-12px leading-16px">
                        4
                    </span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_2   is-hidden bit-table__cell">
                                  <div class="cell">
                                    <div data-v-539e5ed0="" class="flex flex-row items-center">
                                      <img data-v-539e5ed0="" alt="symbol" loading="lazy" src="https://img.bitgetimg.com/multiLang/web/4ec26e6d6c35e57b213617a035297768.png" class="w-28px h-28px mr-8px rounded-28px">
                                      <span data-v-539e5ed0="" class="flex flex-wrap items-center text-16px font-500 text-primaryText"><span data-v-539e5ed0="" class="flex items-center">
                                    AIT
                                     <span data-v-539e5ed0="" class="font-400 text-12px text-v3TertiaryText">
                                        / USDT
                                       </span></span> </span></div>
                                  </div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_3   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText flex flex-row"><div data-v-539e5ed0="" class="mr-3px">
                            0.14000
                        </div></span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_4   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-22px text-primaryText floatNum"><span data-v-539e5ed0="" dir="ltr" class="text-v3TradeBuyText">+47.21%
</span></span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_5   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText">
                        4.58M
                    </span>
                                    <span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText" style="display: none;">
                        555.76K
                    </span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_6   bit-table__cell">
                                  <div class="cell">
                                    <a data-v-539e5ed0="" href="https://www.bitget.com/asia/spot/AITUSDT">
                                      <div data-v-539e5ed0="" class="gotoLinkBox"><span data-v-539e5ed0="" class="text-12px font-500 leading-20px !text-primaryHoverBg font-500 cursor-pointer gotoLink">
                                Trade
                            </span></div>
                                    </a></div>
                                </td>
                              </tr>
                              <tr class="bit-table__row" style="height: 80px;">
                                <td rowspan="1" colspan="1" class="bit-table_1_column_1 is-right  is-hidden bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-v3TertiaryText text-12px leading-16px">
                        5
                    </span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_2   is-hidden bit-table__cell">
                                  <div class="cell">
                                    <div data-v-539e5ed0="" class="flex flex-row items-center">
                                      <img data-v-539e5ed0="" alt="symbol" loading="lazy" src="https://img.bitgetimg.com/multiLang/web/7098504c1c869e66e3c234b625bc6f98.png" class="w-28px h-28px mr-8px rounded-28px">
                                      <span data-v-539e5ed0="" class="flex flex-wrap items-center text-16px font-500 text-primaryText"><span data-v-539e5ed0="" class="flex items-center">
                                    AIN
                                     <span data-v-539e5ed0="" class="font-400 text-12px text-v3TertiaryText">
                                        / USDT
                                       </span></span> </span></div>
                                  </div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_3   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText flex flex-row"><div data-v-539e5ed0="" class="mr-3px">
                            0.010952
                        </div></span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_4   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-22px text-primaryText floatNum"><span data-v-539e5ed0="" dir="ltr" class="text-v3TradeBuyText">+32.1%
</span></span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_5   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText">
                        4.75M
                    </span>
                                    <span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText" style="display: none;">
                        43.68K
                    </span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_6   bit-table__cell">
                                  <div class="cell">
                                    <a data-v-539e5ed0="" href="https://www.bitget.com/asia/spot/AINUSDT">
                                      <div data-v-539e5ed0="" class="gotoLinkBox"><span data-v-539e5ed0="" class="text-12px font-500 leading-20px !text-primaryHoverBg font-500 cursor-pointer gotoLink">
                                Trade
                            </span></div>
                                    </a></div>
                                </td>
                              </tr>
                              <tr class="bit-table__row" style="height: 80px;">
                                <td rowspan="1" colspan="1" class="bit-table_1_column_1 is-right  is-hidden bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-v3TertiaryText text-12px leading-16px">
                        6
                    </span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_2   is-hidden bit-table__cell">
                                  <div class="cell">
                                    <div data-v-539e5ed0="" class="flex flex-row items-center">
                                      <img data-v-539e5ed0="" alt="symbol" loading="lazy" src="https://img.bitgetimg.com/multiLang/web/de6cadbb112a4a96402080e5e8550bc1.jpeg" class="w-28px h-28px mr-8px rounded-28px">
                                      <span data-v-539e5ed0="" class="flex flex-wrap items-center text-16px font-500 text-primaryText"><span data-v-539e5ed0="" class="flex items-center">
                                    OFN
                                     <span data-v-539e5ed0="" class="font-400 text-12px text-v3TertiaryText">
                                        / USDT
                                       </span></span> </span></div>
                                  </div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_3   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText flex flex-row"><div data-v-539e5ed0="" class="mr-3px">
                            0.11042
                        </div></span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_4   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-22px text-primaryText floatNum"><span data-v-539e5ed0="" dir="ltr" class="text-v3TradeBuyText">+31.26%
</span></span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_5   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText">
                        431.29K
                    </span>
                                    <span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText" style="display: none;">
                        41.63K
                    </span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_6   bit-table__cell">
                                  <div class="cell">
                                    <a data-v-539e5ed0="" href="https://www.bitget.com/asia/spot/OFNUSDT">
                                      <div data-v-539e5ed0="" class="gotoLinkBox"><span data-v-539e5ed0="" class="text-12px font-500 leading-20px !text-primaryHoverBg font-500 cursor-pointer gotoLink">
                                Trade
                            </span></div>
                                    </a></div>
                                </td>
                              </tr>
                              <tr class="bit-table__row" style="height: 80px;">
                                <td rowspan="1" colspan="1" class="bit-table_1_column_1 is-right  is-hidden bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-v3TertiaryText text-12px leading-16px">
                        7
                    </span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_2   is-hidden bit-table__cell">
                                  <div class="cell">
                                    <div data-v-539e5ed0="" class="flex flex-row items-center">
                                      <img data-v-539e5ed0="" alt="symbol" loading="lazy" src="https://img.bitgetimg.com/multiLang/web/fb3d394ef659510efc96eef92a6e2135.jpeg" class="w-28px h-28px mr-8px rounded-28px">
                                      <span data-v-539e5ed0="" class="flex flex-wrap items-center text-16px font-500 text-primaryText"><span data-v-539e5ed0="" class="flex items-center">
                                    NMT
                                     <span data-v-539e5ed0="" class="font-400 text-12px text-v3TertiaryText">
                                        / USDT
                                       </span></span> </span></div>
                                  </div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_3   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText flex flex-row"><div data-v-539e5ed0="" class="mr-3px">
                            3.87956
                        </div></span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_4   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-22px text-primaryText floatNum"><span data-v-539e5ed0="" dir="ltr" class="text-v3TradeBuyText">+31.21%
</span></span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_5   bit-table__cell">
                                  <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText">
                        1.01M
                    </span>
                                    <span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText" style="display: none;">
                        3.46M
                    </span></div>
                                </td>
                                <td rowspan="1" colspan="1" class="bit-table_1_column_6   bit-table__cell">
                                  <div class="cell">
                                    <a data-v-539e5ed0="" href="https://www.bitget.com/asia/spot/NMTUSDT">
                                      <div data-v-539e5ed0="" class="gotoLinkBox"><span data-v-539e5ed0="" class="text-12px font-500 leading-20px !text-primaryHoverBg font-500 cursor-pointer gotoLink">
                                Trade
                            </span></div>
                                    </a></div>
                                </td>
                              </tr>
                              </tbody>
                            </table>
                          </div>
                          <div class="bit-table__fixed" style="width: 247px; height: 603px;">
                            <div class="bit-table__fixed-header-wrapper">
                              <table cellspacing="0" cellpadding="0" border="0" class="bit-table__header" style="width: 1173px;">
                                <colgroup>
                                  <col name="bit-table_1_column_1" width="37">
                                  <col name="bit-table_1_column_2" width="210">
                                  <col name="bit-table_1_column_3" width="248">
                                  <col name="bit-table_1_column_4" width="279">
                                  <col name="bit-table_1_column_5" width="279">
                                  <col name="bit-table_1_column_6" width="120">
                                </colgroup>
                                <thead class="">
                                <tr class="">
                                  <th colspan="1" rowspan="1" class="bit-table_1_column_1  is-right   is-leaf bit-table__cell">
                                    <div class="cell">#</div>
                                  </th>
                                  <th colspan="1" rowspan="1" class="bit-table_1_column_2     is-leaf bit-table__cell">
                                    <div class="cell">Name</div>
                                  </th>
                                  <th colspan="1" rowspan="1" class="bit-table_1_column_3     is-hidden is-leaf is-sortable bit-table__cell">
                                    <div class="cell">Last price<span class="caret-wrapper"><i class="bit-icon sort-caret ascending" style="font-size: 8px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M1.364 17.586C.414 19.046 1.435 21 3.147 21h17.707c1.711 0 2.732-1.955 1.783-3.414L13.783 3.978a2.115 2.115 0 00-3.566 0L1.364 17.586z"></path></svg></i><i class="bit-icon sort-caret descending" style="font-size: 8px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M22.637 6.414C23.586 4.954 22.565 3 20.853 3H3.148C1.435 3 .414 4.955 1.364 6.414l8.853 13.608a2.115 2.115 0 003.566 0l8.854-13.608z"></path></svg></i></span>
                                    </div>
                                  </th>
                                  <th colspan="1" rowspan="1" class="bit-table_1_column_4     is-hidden is-leaf is-sortable bit-table__cell">
                                    <div class="cell">Today<span class="caret-wrapper"><i class="bit-icon sort-caret ascending" style="font-size: 8px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M1.364 17.586C.414 19.046 1.435 21 3.147 21h17.707c1.711 0 2.732-1.955 1.783-3.414L13.783 3.978a2.115 2.115 0 00-3.566 0L1.364 17.586z"></path></svg></i><i class="bit-icon sort-caret descending" style="font-size: 8px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M22.637 6.414C23.586 4.954 22.565 3 20.853 3H3.148C1.435 3 .414 4.955 1.364 6.414l8.853 13.608a2.115 2.115 0 003.566 0l8.854-13.608z"></path></svg></i></span>
                                    </div>
                                  </th>
                                  <th colspan="1" rowspan="1" class="bit-table_1_column_5     is-hidden is-leaf is-sortable bit-table__cell">
                                    <div class="cell">24h volume<span class="caret-wrapper"><i class="bit-icon sort-caret ascending" style="font-size: 8px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M1.364 17.586C.414 19.046 1.435 21 3.147 21h17.707c1.711 0 2.732-1.955 1.783-3.414L13.783 3.978a2.115 2.115 0 00-3.566 0L1.364 17.586z"></path></svg></i><i class="bit-icon sort-caret descending" style="font-size: 8px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M22.637 6.414C23.586 4.954 22.565 3 20.853 3H3.148C1.435 3 .414 4.955 1.364 6.414l8.853 13.608a2.115 2.115 0 003.566 0l8.854-13.608z"></path></svg></i></span>
                                    </div>
                                  </th>
                                  <th colspan="1" rowspan="1" class="bit-table_1_column_6     is-hidden is-leaf bit-table__cell">
                                    <div class="cell">Action</div>
                                  </th>
                                </tr>
                                </thead>
                              </table>
                            </div>
                            <div class="bit-table__fixed-body-wrapper" style="top: 43px;">
                              <table cellspacing="0" cellpadding="0" border="0" class="bit-table__body" style="width: 1173px;">
                                <colgroup>
                                  <col name="bit-table_1_column_1" width="37">
                                  <col name="bit-table_1_column_2" width="210">
                                  <col name="bit-table_1_column_3" width="248">
                                  <col name="bit-table_1_column_4" width="279">
                                  <col name="bit-table_1_column_5" width="279">
                                  <col name="bit-table_1_column_6" width="120">
                                </colgroup>
                                <tbody>
                                <tr class="bit-table__row" style="height: 80px;">
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_1 is-right  bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-v3TertiaryText text-12px leading-16px isIndexActive">
                        1
                    </span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_2   bit-table__cell">
                                    <div class="cell">
                                      <div data-v-539e5ed0="" class="flex flex-row items-center">
                                        <img data-v-539e5ed0="" alt="symbol" loading="lazy" src="https://img.bitgetimg.com/multiLang/web/0b5daaea87e8b5d16defb2b1ec9b6f5f.png" class="w-28px h-28px mr-8px rounded-28px">
                                        <span data-v-539e5ed0="" class="flex flex-wrap items-center text-16px font-500 text-primaryText"><span data-v-539e5ed0="" class="flex items-center">
                                    RBTC
                                     <span data-v-539e5ed0="" class="font-400 text-12px text-v3TertiaryText">
                                        / USDT
                                       </span></span> <img data-v-539e5ed0="" src="https://img.bitgetimg.com/multiLang/web/c5006cc153f4fa04e28d23751a6a094a.png" alt="RBTCNEWUSDT_SPBL_label_icon" loading="lazy" class="relative h-16px ml-4px"></span>
                                      </div>
                                    </div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_3   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText flex flex-row"><div data-v-539e5ed0="" class="mr-3px">
                            0.0000053523
                        </div></span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_4   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-22px text-primaryText floatNum"><span data-v-539e5ed0="" dir="ltr" class="text-v3TradeBuyText">+2576.15%
</span></span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_5   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText">
                        281.59B
                    </span>
                                      <span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText" style="display: none;">
                        1.84M
                    </span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_6   is-hidden bit-table__cell">
                                    <div class="cell">
                                      <a data-v-539e5ed0="" href="https://www.bitget.com/asia/spot/RBTCUSDT">
                                        <div data-v-539e5ed0="" class="gotoLinkBox"><span data-v-539e5ed0="" class="text-12px font-500 leading-20px !text-primaryHoverBg font-500 cursor-pointer gotoLink">
                                Trade
                            </span></div>
                                      </a></div>
                                  </td>
                                </tr>
                                <tr class="bit-table__row" style="height: 80px;">
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_1 is-right  bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-v3TertiaryText text-12px leading-16px isIndexActive">
                        2
                    </span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_2   bit-table__cell">
                                    <div class="cell">
                                      <div data-v-539e5ed0="" class="flex flex-row items-center">
                                        <img data-v-539e5ed0="" alt="symbol" loading="lazy" src="https://img.bitgetimg.com/multiLang/web/50860ce741334bee7cb1300669c0357c.png" class="w-28px h-28px mr-8px rounded-28px">
                                        <span data-v-539e5ed0="" class="flex flex-wrap items-center text-16px font-500 text-primaryText"><span data-v-539e5ed0="" class="flex items-center">
                                    WAT
                                     <span data-v-539e5ed0="" class="font-400 text-12px text-v3TertiaryText">
                                        / USDT
                                       </span></span> <img data-v-539e5ed0="" src="https://img.bitgetimg.com/multiLang/web/8209f82e444e768cb948f6bceb8b222d.png" alt="WATUSDT_SPBL_label_icon" loading="lazy" class="relative h-16px ml-4px"></span>
                                      </div>
                                    </div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_3   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText flex flex-row"><div data-v-539e5ed0="" class="mr-3px">
                            0.00075100
                        </div></span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_4   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-22px text-primaryText floatNum"><span data-v-539e5ed0="" dir="ltr" class="text-v3TradeBuyText">+838.75%
</span></span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_5   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText">
                        4.16B
                    </span>
                                      <span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText" style="display: none;">
                        4.73M
                    </span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_6   is-hidden bit-table__cell">
                                    <div class="cell">
                                      <a data-v-539e5ed0="" href="https://www.bitget.com/asia/spot/WATUSDT">
                                        <div data-v-539e5ed0="" class="gotoLinkBox"><span data-v-539e5ed0="" class="text-12px font-500 leading-20px !text-primaryHoverBg font-500 cursor-pointer gotoLink">
                                Trade
                            </span></div>
                                      </a></div>
                                  </td>
                                </tr>
                                <tr class="bit-table__row" style="height: 80px;">
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_1 is-right  bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-v3TertiaryText text-12px leading-16px isIndexActive">
                        3
                    </span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_2   bit-table__cell">
                                    <div class="cell">
                                      <div data-v-539e5ed0="" class="flex flex-row items-center">
                                        <img data-v-539e5ed0="" alt="symbol" loading="lazy" src="https://img.bitgetimg.com/multiLang/coin_img/21bdfba4d8c2632e2c907e69c4dc381a.png" class="w-28px h-28px mr-8px rounded-28px">
                                        <span data-v-539e5ed0="" class="flex flex-wrap items-center text-16px font-500 text-primaryText"><span data-v-539e5ed0="" class="flex items-center">
                                    CEL
                                     <span data-v-539e5ed0="" class="font-400 text-12px text-v3TertiaryText">
                                        / USDT
                                       </span></span> </span></div>
                                    </div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_3   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText flex flex-row"><div data-v-539e5ed0="" class="mr-3px">
                            0.5810
                        </div></span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_4   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-22px text-primaryText floatNum"><span data-v-539e5ed0="" dir="ltr" class="text-v3TradeBuyText">+56.65%
</span></span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_5   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText">
                        1.11M
                    </span>
                                      <span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText" style="display: none;">
                        587.51K
                    </span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_6   is-hidden bit-table__cell">
                                    <div class="cell">
                                      <a data-v-539e5ed0="" href="https://www.bitget.com/asia/spot/CELUSDT">
                                        <div data-v-539e5ed0="" class="gotoLinkBox"><span data-v-539e5ed0="" class="text-12px font-500 leading-20px !text-primaryHoverBg font-500 cursor-pointer gotoLink">
                                Trade
                            </span></div>
                                      </a></div>
                                  </td>
                                </tr>
                                <tr class="bit-table__row" style="height: 80px;">
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_1 is-right  bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-v3TertiaryText text-12px leading-16px">
                        4
                    </span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_2   bit-table__cell">
                                    <div class="cell">
                                      <div data-v-539e5ed0="" class="flex flex-row items-center">
                                        <img data-v-539e5ed0="" alt="symbol" loading="lazy" src="https://img.bitgetimg.com/multiLang/web/4ec26e6d6c35e57b213617a035297768.png" class="w-28px h-28px mr-8px rounded-28px">
                                        <span data-v-539e5ed0="" class="flex flex-wrap items-center text-16px font-500 text-primaryText"><span data-v-539e5ed0="" class="flex items-center">
                                    AIT
                                     <span data-v-539e5ed0="" class="font-400 text-12px text-v3TertiaryText">
                                        / USDT
                                       </span></span> </span></div>
                                    </div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_3   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText flex flex-row"><div data-v-539e5ed0="" class="mr-3px">
                            0.14000
                        </div></span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_4   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-22px text-primaryText floatNum"><span data-v-539e5ed0="" dir="ltr" class="text-v3TradeBuyText">+47.21%
</span></span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_5   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText">
                        4.58M
                    </span>
                                      <span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText" style="display: none;">
                        555.76K
                    </span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_6   is-hidden bit-table__cell">
                                    <div class="cell">
                                      <a data-v-539e5ed0="" href="https://www.bitget.com/asia/spot/AITUSDT">
                                        <div data-v-539e5ed0="" class="gotoLinkBox"><span data-v-539e5ed0="" class="text-12px font-500 leading-20px !text-primaryHoverBg font-500 cursor-pointer gotoLink">
                                Trade
                            </span></div>
                                      </a></div>
                                  </td>
                                </tr>
                                <tr class="bit-table__row" style="height: 80px;">
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_1 is-right  bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-v3TertiaryText text-12px leading-16px">
                        5
                    </span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_2   bit-table__cell">
                                    <div class="cell">
                                      <div data-v-539e5ed0="" class="flex flex-row items-center">
                                        <img data-v-539e5ed0="" alt="symbol" loading="lazy" src="https://img.bitgetimg.com/multiLang/web/7098504c1c869e66e3c234b625bc6f98.png" class="w-28px h-28px mr-8px rounded-28px">
                                        <span data-v-539e5ed0="" class="flex flex-wrap items-center text-16px font-500 text-primaryText"><span data-v-539e5ed0="" class="flex items-center">
                                    AIN
                                     <span data-v-539e5ed0="" class="font-400 text-12px text-v3TertiaryText">
                                        / USDT
                                       </span></span> </span></div>
                                    </div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_3   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText flex flex-row"><div data-v-539e5ed0="" class="mr-3px">
                            0.010952
                        </div></span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_4   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-22px text-primaryText floatNum"><span data-v-539e5ed0="" dir="ltr" class="text-v3TradeBuyText">+32.1%
</span></span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_5   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText">
                        4.75M
                    </span>
                                      <span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText" style="display: none;">
                        43.68K
                    </span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_6   is-hidden bit-table__cell">
                                    <div class="cell">
                                      <a data-v-539e5ed0="" href="https://www.bitget.com/asia/spot/AINUSDT">
                                        <div data-v-539e5ed0="" class="gotoLinkBox"><span data-v-539e5ed0="" class="text-12px font-500 leading-20px !text-primaryHoverBg font-500 cursor-pointer gotoLink">
                                Trade
                            </span></div>
                                      </a></div>
                                  </td>
                                </tr>
                                <tr class="bit-table__row" style="height: 80px;">
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_1 is-right  bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-v3TertiaryText text-12px leading-16px">
                        6
                    </span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_2   bit-table__cell">
                                    <div class="cell">
                                      <div data-v-539e5ed0="" class="flex flex-row items-center">
                                        <img data-v-539e5ed0="" alt="symbol" loading="lazy" src="https://img.bitgetimg.com/multiLang/web/de6cadbb112a4a96402080e5e8550bc1.jpeg" class="w-28px h-28px mr-8px rounded-28px">
                                        <span data-v-539e5ed0="" class="flex flex-wrap items-center text-16px font-500 text-primaryText"><span data-v-539e5ed0="" class="flex items-center">
                                    OFN
                                     <span data-v-539e5ed0="" class="font-400 text-12px text-v3TertiaryText">
                                        / USDT
                                       </span></span> </span></div>
                                    </div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_3   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText flex flex-row"><div data-v-539e5ed0="" class="mr-3px">
                            0.11042
                        </div></span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_4   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-22px text-primaryText floatNum"><span data-v-539e5ed0="" dir="ltr" class="text-v3TradeBuyText">+31.26%
</span></span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_5   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText">
                        431.29K
                    </span>
                                      <span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText" style="display: none;">
                        41.63K
                    </span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_6   is-hidden bit-table__cell">
                                    <div class="cell">
                                      <a data-v-539e5ed0="" href="https://www.bitget.com/asia/spot/OFNUSDT">
                                        <div data-v-539e5ed0="" class="gotoLinkBox"><span data-v-539e5ed0="" class="text-12px font-500 leading-20px !text-primaryHoverBg font-500 cursor-pointer gotoLink">
                                Trade
                            </span></div>
                                      </a></div>
                                  </td>
                                </tr>
                                <tr class="bit-table__row" style="height: 80px;">
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_1 is-right  bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-v3TertiaryText text-12px leading-16px">
                        7
                    </span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_2   bit-table__cell">
                                    <div class="cell">
                                      <div data-v-539e5ed0="" class="flex flex-row items-center">
                                        <img data-v-539e5ed0="" alt="symbol" loading="lazy" src="https://img.bitgetimg.com/multiLang/web/fb3d394ef659510efc96eef92a6e2135.jpeg" class="w-28px h-28px mr-8px rounded-28px">
                                        <span data-v-539e5ed0="" class="flex flex-wrap items-center text-16px font-500 text-primaryText"><span data-v-539e5ed0="" class="flex items-center">
                                    NMT
                                     <span data-v-539e5ed0="" class="font-400 text-12px text-v3TertiaryText">
                                        / USDT
                                       </span></span> </span></div>
                                    </div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_3   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText flex flex-row"><div data-v-539e5ed0="" class="mr-3px">
                            3.87956
                        </div></span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_4   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-22px text-primaryText floatNum"><span data-v-539e5ed0="" dir="ltr" class="text-v3TradeBuyText">+31.21%
</span></span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_5   is-hidden bit-table__cell">
                                    <div class="cell"><span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText">
                        1.01M
                    </span>
                                      <span data-v-539e5ed0="" class="text-14px font-500 leading-20px text-primaryText" style="display: none;">
                        3.46M
                    </span></div>
                                  </td>
                                  <td rowspan="1" colspan="1" class="bit-table_1_column_6   is-hidden bit-table__cell">
                                    <div class="cell">
                                      <a data-v-539e5ed0="" href="https://www.bitget.com/asia/spot/NMTUSDT">
                                        <div data-v-539e5ed0="" class="gotoLinkBox"><span data-v-539e5ed0="" class="text-12px font-500 leading-20px !text-primaryHoverBg font-500 cursor-pointer gotoLink">
                                Trade
                            </span></div>
                                      </a></div>
                                  </td>
                                </tr>
                                </tbody>
                              </table>
                            </div>
                          </div>
                          <div class="bit-table__column-resize-proxy" style="display: none;"></div>
                        </div>
                        <div data-v-539e5ed0="" class="flex justify-center mt-48px">
                          <a data-v-539e5ed0="" href="/asia/register" class="bit-link bit-link--default"><span class="bit-link--inner"><button data-v-539e5ed0="" type="button" class="bit-button bit-button--default bit-button--medium is-round"><span><span data-v-539e5ed0="">
                            View all
                        </span> <i data-v-539e5ed0="" class="bit-icon rtl-rotate" style="font-size: 14px;"><svg data-v-539e5ed0="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.03 12.53l-7.5 7.5a.75.75 0 11-1.06-1.06L15.44 12 8.47 5.03a.75.75 0 111.06-1.06l7.5 7.5a.75.75 0 010 1.06z"></path></svg></i></span></button></span>
                          </a></div>
                        <div data-v-539e5ed0="" class="bit-dialog__wrapper is-centered is-responsive" style="display: none;">
                          <div role="dialog" aria-modal="true" aria-label="New category" class="bit-dialog add-group-modal" style="margin-top: 15vh; width: 396px;">
                            <div class="bit-dialog__header"><span class="bit-dialog__title">New category</span>
                              <button type="button" aria-label="Close" class="bit-dialog__headerbtn">
                                <i class="bit-icon" style="font-size: 20px;">
                                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                                    <path d="M19.28 18.22a.75.75 0 01-.817 1.223.75.75 0 01-.244-.162L12 13.06l-6.22 6.22a.75.75 0 01-1.06-1.062L10.94 12 4.72 5.78a.75.75 0 111.06-1.06L12 10.94l6.22-6.22a.75.75 0 011.06 1.06L13.06 12l6.22 6.22z"></path>
                                  </svg>
                                </i></button>
                            </div>
                            <div class="bit-dialog__footer"><span class="dialog-footer"><button type="button" class="bit-button bit-button--default bit-button--medium is-round"><span>
                Cancel
            </span></button> <button disabled="disabled" type="button" class="bit-button bit-button--main bit-button--medium is-disabled is-round"><span>
                Confirm
            </span></button></span></div>
                          </div>
                        </div>
                        <div data-v-48355fc5="" data-v-539e5ed0="" class="bit-dialog__wrapper is-centered is-responsive" style="display: none;">
                          <div role="dialog" aria-modal="true" aria-label="Customized category" class="bit-dialog batch-group-list-modal" style="margin-top: 15vh; width: 480px;">
                            <div class="bit-dialog__header"><span class="bit-dialog__title">Customized category</span>
                              <button type="button" aria-label="Close" class="bit-dialog__headerbtn">
                                <i class="bit-icon" style="font-size: 20px;">
                                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                                    <path d="M19.28 18.22a.75.75 0 01-.817 1.223.75.75 0 01-.244-.162L12 13.06l-6.22 6.22a.75.75 0 01-1.06-1.062L10.94 12 4.72 5.78a.75.75 0 111.06-1.06L12 10.94l6.22-6.22a.75.75 0 011.06 1.06L13.06 12l6.22 6.22z"></path>
                                  </svg>
                                </i></button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-08a1c11c="" style="min-height: 0px;">
            <div data-v-02a41350="" data-v-08a1c11c="" class="copytrading">
              <div data-v-02a41350="">
                <div data-v-02a41350="" class="mb-65px">
                  <div class="mt-160px pad:mt-80px phone:mt-32px px-24px text-v3PrimaryText text-fs48 font-700 leading-58px pb-16px font-semibold hidden <lg-new:block  phone:text-fs20 phone:pb-8px">
                    Copy Trading
                  </div>
                  <div class="mx-24px mt-20px pb-24px text-fs20 font-400 text-v3TertiaryText leading-28px hidden <lg-new:block border-0 border-b-1px border-line border-solid border-v3StrengthBorder0  phone:text-fs12 phone:mt-0 phone:pb-20px">
                    The world's largest crypto copy trading platform
                  </div>
                  <div class="flex m-auto max-w-1200px mt-160px px-24px flex justify-around items-center <lg-new:mt-0px">
                    <div class="<lg-new:flex <lg-new:justify-between <lg-new:items-center">
                      <div class="w-1/1 flex flex-col">
                        <div class="text-fs48 text-v3PrimaryText font-700 leading-58px pb-16px font-semibold <lg-new:hidden">
                          Copy Trading
                        </div>
                        <div class="mt-20px text-fs20 font-400 text-v3TertiaryText leading-28px <lg-new:hidden">
                          The world's largest crypto copy trading platform
                        </div>
                        <div class="pt-24px pb-24px grid mt-50px grid-cols-3 grid-rows-1 gap-y-20px <lg-new:grid-cols-1 <lg-new:grid-rows-3 <lg-new:gap-y-32px <md:gap-y-22px border-0 border-solid border-t-1px border-line border-v3StrengthBorder0 <lg-new:mt-0px <lg-new:border-0">
                          <div class="flex flex-col <md:items-start"><span class="text-fs32 font-700 text-v3PrimaryText phone:text-fs16">
                            180,000+
                        </span> <span class="text-fs12 text-v3TertiaryText  phone:text-fs12">
                            Elite traders
                        </span></div>
                          <div class="flex flex-col <md:items-start"><span class="text-fs32 font-700 text-v3PrimaryText phone:text-fs16">
                            800,000+
                        </span> <span class="text-fs12 text-v3TertiaryText  phone:text-fs12">
                            Followers
                        </span></div>
                          <div class="flex flex-col <md:items-start"><span class="text-fs32 font-700 text-v3PrimaryText phone:text-fs16">
                            $500,000,000+
                        </span> <span class="text-fs12 text-v3TertiaryText  phone:text-fs12">
                            Realized PnL
                        </span></div>
                        </div>
                        <div class="<lg-new:hidden">
                          <button type="button" class="bit-button bit-button--primary bit-button--medium is-round"><span><span class="leading-14px text-12px">
                            Start Copy Trading
                        </span> <i class="bit-icon rtl-rotate ml-10px" style="font-size: 14px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M20.78 12.53l-6.75 6.75a.75.75 0 01-1.06-1.06l5.47-5.47H3.75a.75.75 0 110-1.5h14.69l-5.47-5.47a.75.75 0 111.06-1.06l6.75 6.75a.747.747 0 010 1.06z"></path></svg></i></span>
                          </button>
                        </div>
                      </div>
                      <div class="hidden <lg-new:block">
                        <div class="max-w-520px max-h-438px w-1/1 h-1/1">
                          <img loading="lazy" src="/baseasset/img/home/cartoon/home-copy-bg-dark.png" alt="Copy Trading" class="block w-9/10 h-9/10">
                        </div>
                      </div>
                    </div>
                    <div class="flex-1 ml-64px !rtl:ml-0 rtl:mr-64px <lg-new:hidden">
                      <div class="max-w-520px max-h-438px w-1/1 h-1/1">
                        <img loading="lazy" src="/baseasset/img/home/cartoon/home-copy-bg-dark.png" alt="Copy Trading" class="block w-9/10 h-9/10">
                      </div>
                    </div>
                  </div>
                  <div class="m-auto max-w-1200px px-24px text-center mt-60px hidden <lg-new:block">
                    <button type="button" class="bit-button bit-button--primary bit-button--medium is-round"><span><span class="leading-14px text-12px">
                Start Copy Trading
            </span> <i class="bit-icon rtl-rotate ml-10px" style="font-size: 14px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M20.78 12.53l-6.75 6.75a.75.75 0 01-1.06-1.06l5.47-5.47H3.75a.75.75 0 110-1.5h14.69l-5.47-5.47a.75.75 0 111.06-1.06l6.75 6.75a.747.747 0 010 1.06z"></path></svg></i></span>
                    </button>
                  </div>
                </div>
              </div>
              <div data-v-02a41350="" class="copytrading-postLogin mt-60px !phone:hidden">
                <div data-v-02a41350="" class="login-trade-swiper mx-auto">
                  <div data-v-02a41350="" class="trade-card trade_for_home-swiper-container swiper-container-initialized swiper-container-horizontal">
                    <div data-v-02a41350="" class="trade-web swiper-wrapper pt-10px" style="transition-duration: 0ms; transform: translate3d(-7800px, 0px, 0px);">
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="0" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bfb74a728bb13154a797" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header first" chartid="1727148861531_home_chart_bfb74a728bb13154a797" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box first">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20231214/1702521877803.png" alt="BountyHunter-Q" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">BountyHunter-Q</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        1,284
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bfb74a728bb13154a797" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -37.63%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$77,041.34
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $761,440.26
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="1" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_beb347718db6395ea592" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header second" chartid="1727148861531_home_chart_beb347718db6395ea592" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box second">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240117/1705428132483.png" alt="buylow" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">buylow</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        300
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_beb347718db6395ea592" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +26.21%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$326.31
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $8,780.61
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="2" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_beb04c7e8bbb3d57a594" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header third" chartid="1727148861531_home_chart_beb04c7e8bbb3d57a594" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box third">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240806/1722932291284.png" alt="RocketMan·" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">RocketMan·</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        992
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_beb04c7e8bbb3d57a594" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -33.34%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$26,211.61
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $700,940.75
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="3" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_b0b5477386b33d55a197" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_b0b5477386b33d55a197" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240806/1722934872568.png" alt="BG-ACC-Travel" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">BG-ACC-Travel</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        750
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_b0b5477386b33d55a197" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -39.34%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$30,531.15
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $720,819.34
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="4" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_b1b54f7787b33154ad97" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_b1b54f7787b33154ad97" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240907/1725640135208.png" alt="WolfClub" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">WolfClub</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        964
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_b1b54f7787b33154ad97" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +44.58%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $223,124.25
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $738,032.84
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate swiper-slide-duplicate-prev" islogincard="true" data-swiper-slide-index="5" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bdb34c718ab23c57a495" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bdb34c718ab23c57a495" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240907/1725641796995.png" alt="ROIROIROI" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">ROIROIROI</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        976
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bdb34c718ab23c57a495" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -5.55%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $245,415.14
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $712,610.38
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate swiper-slide-duplicate-active" islogincard="true" data-swiper-slide-index="6" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bfbc48718bbb3f51a493" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bfbc48718bbb3f51a493" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240904/1725438038189.png" alt="DAO-" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">DAO-</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        995
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bfbc48718bbb3f51a493" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +35.88%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $184,672.67
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $723,189.71
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate swiper-slide-duplicate-next" islogincard="true" data-swiper-slide-index="7" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bfb347738dbb3854a593" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bfb347738dbb3854a593" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240630/1719753029811.jpeg" alt="Winner2" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">Winner2</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        399
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bfb347738dbb3854a593" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +138.82%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$4,622.4
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $116,028.50
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="8" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bbb04e7287b13d54a29d" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bbb04e7287b13d54a29d" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240717/1721187569319.png" alt="Satoshit" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">Satoshit</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        854
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bbb04e7287b13d54a29d" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +86.98%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $25,693.94
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $306,620.18
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="9" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_b1b248738db63d5fa39d" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_b1b248738db63d5fa39d" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240423/1713860265905.png" alt="BountyHunter-W" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">BountyHunter-W</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        690
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_b1b248738db63d5fa39d" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -20.1%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$2,642.53
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $91,723.49
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="10" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bdb74c7f89b63c5fa69c" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bdb74c7f89b63c5fa69c" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240319/1710837001164.jpg" alt="elbullmino" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">elbullmino</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        382
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bdb74c7f89b63c5fa69c" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +10.36%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$4,253.13
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $69,004.28
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="11" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bfb746758fb63857a69d" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bfb746758fb63857a69d" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240523/1716466472678.png" alt="BB-K" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">BB-K</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        796
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bfb746758fb63857a69d" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +25.41%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $3,984.70
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $87,736.13
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="12" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bdb34d7187b13c57a294" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bdb34d7187b13c57a294" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240318/1710710969452.png" alt="onaliskuu" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">onaliskuu</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        574
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bdb34d7187b13c57a294" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -3.88%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$21,300.38
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $337,369.63
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="13" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bbb14a7e8fb73d51ad96" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bbb14a7e8fb73d51ad96" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="/baseasset/img/common/avatar-default.svg" alt="BGUSER-GJHSFNUE" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">BGUSER-GJHSFNUE</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        501
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bbb14a7e8fb73d51ad96" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +37.51%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$37,340.49
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $97,841.67
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="14" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bfb34d7588b43050a695" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bfb34d7588b43050a695" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20220907/57788457-ddd8-42a4-b389-88c6bda8b4f6.jpg" alt="Trading_Dom" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">Trading_Dom</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        793
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bfb34d7588b43050a695" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +13.61%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $4,783.92
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $100,975.52
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="15" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bab04e708bb33f54a697" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bab04e708bb33f54a697" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="/baseasset/img/common/avatar-default.svg" alt="BGUSER-GQBXPF73" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">BGUSER-GQBXPF73</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        448
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bab04e708bb33f54a697" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -2.84%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$481.85
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $98,396.39
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="16" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_b1bc4d708ab03152a492" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_b1bc4d708ab03152a492" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240625/1719291059567.jpg" alt="Anticipation" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">Anticipation</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        281
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_b1bc4d708ab03152a492" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +34.29%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$65,959.26
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $95,637.09
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="17" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_beb34a7188bb3f57a392" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_beb34a7188bb3f57a392" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240911/1726064024415.png" alt="ATTIC" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">ATTIC</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        362
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_beb34a7188bb3f57a392" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +9.24%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $519.14
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $658,991.55
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="18" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bcb74a778fb23b53ad96" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bcb74a778fb23b53ad96" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240219/1708286777248.jpeg" alt="garufi-cryptocopy" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">garufi-cryptocopy</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        764
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bcb74a778fb23b53ad96" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -12.48%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$75,051.83
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $613,323.59
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="19" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bdb247768db63156a695" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bdb247768db63156a695" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240908/1725733102371.png" alt="ckrAnaliz" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">ckrAnaliz</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        526
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bdb247768db63156a695" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +18.85%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $17,647.15
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $179,496.99
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow" islogincard="true" data-swiper-slide-index="0" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bfb74a728bb13154a797" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header first" chartid="1727148861531_home_chart_bfb74a728bb13154a797" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box first">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20231214/1702521877803.png" alt="BountyHunter-Q" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">BountyHunter-Q</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        1,284
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bfb74a728bb13154a797" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -37.63%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$77,041.34
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $761,440.26
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow" islogincard="true" data-swiper-slide-index="1" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_beb347718db6395ea592" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header second" chartid="1727148861531_home_chart_beb347718db6395ea592" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box second">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240117/1705428132483.png" alt="buylow" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">buylow</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        300
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_beb347718db6395ea592" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +26.21%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$326.31
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $8,780.61
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow" islogincard="true" data-swiper-slide-index="2" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_beb04c7e8bbb3d57a594" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header third" chartid="1727148861531_home_chart_beb04c7e8bbb3d57a594" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box third">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240806/1722932291284.png" alt="RocketMan·" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">RocketMan·</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        992
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_beb04c7e8bbb3d57a594" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -33.34%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$26,211.61
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $700,940.75
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow" islogincard="true" data-swiper-slide-index="3" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_b0b5477386b33d55a197" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_b0b5477386b33d55a197" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240806/1722934872568.png" alt="BG-ACC-Travel" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">BG-ACC-Travel</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        750
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_b0b5477386b33d55a197" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -39.34%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$30,531.15
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $720,819.34
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow" islogincard="true" data-swiper-slide-index="4" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_b1b54f7787b33154ad97" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_b1b54f7787b33154ad97" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240907/1725640135208.png" alt="WolfClub" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">WolfClub</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        964
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_b1b54f7787b33154ad97" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +44.58%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $223,124.25
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $738,032.84
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-prev" islogincard="true" data-swiper-slide-index="5" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bdb34c718ab23c57a495" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bdb34c718ab23c57a495" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240907/1725641796995.png" alt="ROIROIROI" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">ROIROIROI</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        976
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bdb34c718ab23c57a495" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -5.55%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $245,415.14
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $712,610.38
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-active" islogincard="true" data-swiper-slide-index="6" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bfbc48718bbb3f51a493" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bfbc48718bbb3f51a493" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240904/1725438038189.png" alt="DAO-" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">DAO-</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        995
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bfbc48718bbb3f51a493" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +35.88%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $184,672.67
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $723,189.71
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-next" islogincard="true" data-swiper-slide-index="7" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bfb347738dbb3854a593" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bfb347738dbb3854a593" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240630/1719753029811.jpeg" alt="Winner2" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">Winner2</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        399
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bfb347738dbb3854a593" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +138.82%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$4,622.4
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $116,028.50
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow" islogincard="true" data-swiper-slide-index="8" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bbb04e7287b13d54a29d" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bbb04e7287b13d54a29d" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240717/1721187569319.png" alt="Satoshit" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">Satoshit</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        854
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bbb04e7287b13d54a29d" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +86.98%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $25,693.94
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $306,620.18
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow" islogincard="true" data-swiper-slide-index="9" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_b1b248738db63d5fa39d" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_b1b248738db63d5fa39d" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240423/1713860265905.png" alt="BountyHunter-W" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">BountyHunter-W</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        690
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_b1b248738db63d5fa39d" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -20.1%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$2,642.53
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $91,723.49
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow" islogincard="true" data-swiper-slide-index="10" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bdb74c7f89b63c5fa69c" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bdb74c7f89b63c5fa69c" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240319/1710837001164.jpg" alt="elbullmino" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">elbullmino</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        382
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bdb74c7f89b63c5fa69c" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +10.36%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$4,253.13
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $69,004.28
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow" islogincard="true" data-swiper-slide-index="11" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bfb746758fb63857a69d" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bfb746758fb63857a69d" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240523/1716466472678.png" alt="BB-K" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">BB-K</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        796
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bfb746758fb63857a69d" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +25.41%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $3,984.70
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $87,736.13
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow" islogincard="true" data-swiper-slide-index="12" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bdb34d7187b13c57a294" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bdb34d7187b13c57a294" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240318/1710710969452.png" alt="onaliskuu" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">onaliskuu</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        574
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bdb34d7187b13c57a294" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -3.88%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$21,300.38
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $337,369.63
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow" islogincard="true" data-swiper-slide-index="13" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bbb14a7e8fb73d51ad96" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bbb14a7e8fb73d51ad96" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="/baseasset/img/common/avatar-default.svg" alt="BGUSER-GJHSFNUE" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">BGUSER-GJHSFNUE</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        501
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bbb14a7e8fb73d51ad96" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +37.51%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$37,340.49
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $97,841.67
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow" islogincard="true" data-swiper-slide-index="14" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bfb34d7588b43050a695" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bfb34d7588b43050a695" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20220907/57788457-ddd8-42a4-b389-88c6bda8b4f6.jpg" alt="Trading_Dom" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">Trading_Dom</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        793
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bfb34d7588b43050a695" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +13.61%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $4,783.92
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $100,975.52
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow" islogincard="true" data-swiper-slide-index="15" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bab04e708bb33f54a697" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bab04e708bb33f54a697" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="/baseasset/img/common/avatar-default.svg" alt="BGUSER-GQBXPF73" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">BGUSER-GQBXPF73</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        448
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bab04e708bb33f54a697" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -2.84%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$481.85
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $98,396.39
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow" islogincard="true" data-swiper-slide-index="16" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_b1bc4d708ab03152a492" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_b1bc4d708ab03152a492" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240625/1719291059567.jpg" alt="Anticipation" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">Anticipation</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        281
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_b1bc4d708ab03152a492" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +34.29%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$65,959.26
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $95,637.09
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow" islogincard="true" data-swiper-slide-index="17" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_beb34a7188bb3f57a392" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_beb34a7188bb3f57a392" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240911/1726064024415.png" alt="ATTIC" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">ATTIC</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        362
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_beb34a7188bb3f57a392" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +9.24%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $519.14
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $658,991.55
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow" islogincard="true" data-swiper-slide-index="18" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bcb74a778fb23b53ad96" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bcb74a778fb23b53ad96" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240219/1708286777248.jpeg" alt="garufi-cryptocopy" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">garufi-cryptocopy</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        764
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bcb74a778fb23b53ad96" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -12.48%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$75,051.83
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $613,323.59
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow" islogincard="true" data-swiper-slide-index="19" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bdb247768db63156a695" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bdb247768db63156a695" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240908/1725733102371.png" alt="ckrAnaliz" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">ckrAnaliz</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        526
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bdb247768db63156a695" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +18.85%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $17,647.15
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $179,496.99
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="0" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bfb74a728bb13154a797" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header first" chartid="1727148861531_home_chart_bfb74a728bb13154a797" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box first">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20231214/1702521877803.png" alt="BountyHunter-Q" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">BountyHunter-Q</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        1,284
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bfb74a728bb13154a797" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -37.63%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$77,041.34
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $761,440.26
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="1" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_beb347718db6395ea592" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header second" chartid="1727148861531_home_chart_beb347718db6395ea592" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box second">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240117/1705428132483.png" alt="buylow" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">buylow</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        300
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_beb347718db6395ea592" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +26.21%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$326.31
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $8,780.61
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="2" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_beb04c7e8bbb3d57a594" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header third" chartid="1727148861531_home_chart_beb04c7e8bbb3d57a594" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box third">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240806/1722932291284.png" alt="RocketMan·" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">RocketMan·</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        992
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_beb04c7e8bbb3d57a594" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -33.34%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$26,211.61
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $700,940.75
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="3" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_b0b5477386b33d55a197" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_b0b5477386b33d55a197" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240806/1722934872568.png" alt="BG-ACC-Travel" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">BG-ACC-Travel</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        750
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_b0b5477386b33d55a197" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -39.34%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$30,531.15
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $720,819.34
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="4" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_b1b54f7787b33154ad97" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_b1b54f7787b33154ad97" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240907/1725640135208.png" alt="WolfClub" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">WolfClub</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        964
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_b1b54f7787b33154ad97" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +44.58%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $223,124.25
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $738,032.84
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate swiper-slide-duplicate-prev" islogincard="true" data-swiper-slide-index="5" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bdb34c718ab23c57a495" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bdb34c718ab23c57a495" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240907/1725641796995.png" alt="ROIROIROI" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">ROIROIROI</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        976
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bdb34c718ab23c57a495" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -5.55%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $245,415.14
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $712,610.38
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate swiper-slide-duplicate-active" islogincard="true" data-swiper-slide-index="6" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bfbc48718bbb3f51a493" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bfbc48718bbb3f51a493" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240904/1725438038189.png" alt="DAO-" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">DAO-</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        995
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bfbc48718bbb3f51a493" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +35.88%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $184,672.67
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $723,189.71
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate swiper-slide-duplicate-next" islogincard="true" data-swiper-slide-index="7" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bfb347738dbb3854a593" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bfb347738dbb3854a593" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240630/1719753029811.jpeg" alt="Winner2" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">Winner2</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        399
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bfb347738dbb3854a593" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +138.82%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$4,622.4
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $116,028.50
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="8" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bbb04e7287b13d54a29d" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bbb04e7287b13d54a29d" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240717/1721187569319.png" alt="Satoshit" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">Satoshit</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        854
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bbb04e7287b13d54a29d" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +86.98%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $25,693.94
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $306,620.18
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="9" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_b1b248738db63d5fa39d" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_b1b248738db63d5fa39d" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240423/1713860265905.png" alt="BountyHunter-W" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">BountyHunter-W</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        690
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_b1b248738db63d5fa39d" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -20.1%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$2,642.53
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $91,723.49
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="10" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bdb74c7f89b63c5fa69c" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bdb74c7f89b63c5fa69c" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240319/1710837001164.jpg" alt="elbullmino" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">elbullmino</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        382
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bdb74c7f89b63c5fa69c" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +10.36%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$4,253.13
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $69,004.28
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="11" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bfb746758fb63857a69d" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bfb746758fb63857a69d" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240523/1716466472678.png" alt="BB-K" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">BB-K</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        796
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bfb746758fb63857a69d" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +25.41%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $3,984.70
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $87,736.13
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="12" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bdb34d7187b13c57a294" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bdb34d7187b13c57a294" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240318/1710710969452.png" alt="onaliskuu" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">onaliskuu</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        574
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bdb34d7187b13c57a294" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -3.88%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$21,300.38
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $337,369.63
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="13" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bbb14a7e8fb73d51ad96" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bbb14a7e8fb73d51ad96" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="/baseasset/img/common/avatar-default.svg" alt="BGUSER-GJHSFNUE" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">BGUSER-GJHSFNUE</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        501
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bbb14a7e8fb73d51ad96" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +37.51%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$37,340.49
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $97,841.67
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="14" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bfb34d7588b43050a695" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bfb34d7588b43050a695" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20220907/57788457-ddd8-42a4-b389-88c6bda8b4f6.jpg" alt="Trading_Dom" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">Trading_Dom</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        793
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bfb34d7588b43050a695" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +13.61%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $4,783.92
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $100,975.52
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="15" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bab04e708bb33f54a697" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bab04e708bb33f54a697" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="/baseasset/img/common/avatar-default.svg" alt="BGUSER-GQBXPF73" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">BGUSER-GQBXPF73</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        448
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bab04e708bb33f54a697" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -2.84%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$481.85
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $98,396.39
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="16" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_b1bc4d708ab03152a492" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_b1bc4d708ab03152a492" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240625/1719291059567.jpg" alt="Anticipation" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">Anticipation</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        281
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_b1bc4d708ab03152a492" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +34.29%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$65,959.26
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $95,637.09
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="17" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_beb34a7188bb3f57a392" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_beb34a7188bb3f57a392" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240911/1726064024415.png" alt="ATTIC" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">ATTIC</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        362
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_beb34a7188bb3f57a392" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +9.24%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $519.14
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $658,991.55
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="18" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bcb74a778fb23b53ad96" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bcb74a778fb23b53ad96" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240219/1708286777248.jpeg" alt="garufi-cryptocopy" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">garufi-cryptocopy</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        764
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bcb74a778fb23b53ad96" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color red-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-sell">
    -12.48%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    -$75,051.83
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $613,323.59
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                      <div data-v-0d127db0="" data-v-b138bda8="" data-v-02a41350="" class="trade-box swiper-slide interact-card-allow swiper-slide-duplicate" islogincard="true" data-swiper-slide-index="19" style="margin-right: 16px;">
                        <a data-v-b138bda8="" data-v-0d127db0="" class="w-100% cursor-default">
                          <div data-v-b138bda8="" data-v-0d127db0="" data-test-id="go_trader_chart_item_bdb247768db63156a695" class="chart-view-item pb-20px min-w-282px cursor-pointer">
                            <div data-v-5cbca040="" data-v-b138bda8="" class="chart-view-item-header" chartid="1727148861531_home_chart_bdb247768db63156a695" data-v-0d127db0="">
                              <div data-v-5cbca040="" class="user-info-box">
                                <div data-v-5cbca040="" class="avatar">
                                  <img data-v-5cbca040="" loading="lazy" src="https://qrc.bitgetimg.com/otc/images/20240908/1725733102371.png" alt="ckrAnaliz" class="avatar-img">
                                </div>
                                <div data-v-5cbca040="">
                                  <div data-v-5cbca040="" class="flex text-v3PrimaryText">
                                    <span data-v-5cbca040="">ckrAnaliz</span></div>
                                  <div data-v-5cbca040="" class="flex">
                                    <div data-v-5cbca040="" class="other-tip"><span data-v-5cbca040="" class="text-primary font-medium text-fs12 leading-16px font-500">
                        526
                    </span> <span data-v-5cbca040="" class="mx-3px text-v3TertiaryText font-400">·</span>
                                      <span data-v-5cbca040="" class="text-fs12 text-v3TertiaryText font-400">
                        Copiers
                    </span></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div data-v-b138bda8="" class="chart-view-item-content" chartid="1727148861531_home_chart_bdb247768db63156a695" data-v-0d127db0="">
                              <div class="mb-30px px-24px pt-26px">
                                <div class="num num-color green-num"><span dir="ltr"><span dir="ltr" class="break-words text-fs24 font-700 text-v3TradeBuyText">
    +18.85%
</span></span></div>
                                <div class="flex justify-between">
                                  <div class="title"><span class="pt-3px text-fs12 font-500 text-v3PrimaryText">
                    30D ROI
                </span></div>
                                </div>
                              </div>
                              <div class="min-h-82px">
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>30d copiers' profit</span>
                                    </div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $17,647.15
</span></div>
                                  </div>
                                </div>
                                <div class="pt-8px px-24px">
                                  <div class="flex justify-between">
                                    <div class="text-fs14 text-v3TertiaryText font-400"><span>AUM</span></div>
                                    <div class="text-fs14 font-500"><span dir="ltr" class="break-words text-primaryText">
    $179,496.99
</span></div>
                                  </div>
                                </div>
                              </div>
                              <div class="mt-36px mb-18px mx-24px border-0 border-t-1px border-line border-solid border-v3StrengthBorder0"></div>
                              <div class="mt-12px px-24px">
                                <button type="button" class="bit-button !flex w-full items-center justify-center mt-18px bit-button--primary bit-button--medium is-round"><span>
            Copy
        </span></button>
                              </div>
                            </div>
                          </div>
                        </a></div>
                    </div>
                    <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
                </div>
              </div>
            </div>
          </div>
          <div class="exchange mt-160px mb-196px mx-auto max-w-1200px box-border <xl:w-full <xl:max-w-none <xl:px-24px pad:mt-80px pad:mb-120px phone:w-auto phone:mt-32px phone:mb-0 phone:pl-16px phone:pr-0" data-v-7c20b99d="" data-v-08a1c11c="">
            <div class="mb-60px pad:mb-32px phone:mb-20px" data-v-7c20b99d="">
              <div class="text-32px font-700 leading-[120%] text-v3PrimaryText pad:text-32px phone:text-20px phone:leading-28px" data-v-7c20b99d="">
                A trustworthy crypto exchange
              </div>
              <div class="mt-10px text-20px leading-[140%] text-v3TertiaryText pad:mt-12px pad:text-14px phone:mt-8px phone:text-12px" data-v-7c20b99d="">
                When it comes to security, we go the extra mile.
              </div>
            </div>
            <div class="exchange-body" data-v-7c20b99d="">
              <div class="exchange-body-left" data-v-7c20b99d="">
                <div class="exchange-body-left-top" data-v-7c20b99d="">
                  <a href="/asia/academy/data-story-merkle-tree-proof-of-reserves" class="exchange-body-left-top-item hover:cursor-pointer" data-v-7c20b99d="">
                    <div class="exchange-body-left-top-item-imgcon" data-v-7c20b99d="">
                      <img loading="lazy" src="../assets/img/one_proof_white.png" alt="one_proof" class="exchange-body-left-top-item-imgcon-img" data-v-7c20b99d="">
                    </div>
                    <div data-v-7c20b99d="">
                      <div class="exchange-body-left-top-item-title" data-v-7c20b99d="">
                        Proof of Reserves
                      </div>
                      <div class="exchange-body-left-top-item-des" data-v-7c20b99d="">
                        We guarantee at least a 1:1 reserve ratio of our customer funds.
                      </div>
                    </div>
                  </a>
                  <a href="/asia/academy/bitget-cold-storage-introduction" class="exchange-body-left-top-item hover:cursor-pointer" data-v-7c20b99d="">
                    <div class="exchange-body-left-top-item-imgcon" data-v-7c20b99d="">
                      <img loading="lazy" src="../assets/img/two_storage_white.png" alt="two_storage" class="exchange-body-left-top-item-imgcon-img" data-v-7c20b99d="">
                    </div>
                    <div data-v-7c20b99d="">
                      <div class="exchange-body-left-top-item-title" data-v-7c20b99d="">
                        Cold storage
                      </div>
                      <div class="exchange-body-left-top-item-des" data-v-7c20b99d="">
                        We store most digital assets in offline, multi-signature wallets.
                      </div>
                    </div>
                  </a>
                  <a href="/asia/academy/bitget-protection-fund-to-protect-user-assets" class="exchange-body-left-top-item hover:cursor-pointer" data-v-7c20b99d="">
                    <div class="exchange-body-left-top-item-imgcon" data-v-7c20b99d="">
                      <img loading="lazy" src="../assets/img/three_protection_white.png" alt="three_protection" class="exchange-body-left-top-item-imgcon-img" data-v-7c20b99d="">
                    </div>
                    <div data-v-7c20b99d="">
                      <div class="exchange-body-left-top-item-title" data-v-7c20b99d="">
                        Protection Fund
                      </div>
                      <div class="exchange-body-left-top-item-des" data-v-7c20b99d="">
                        Our 300M USDT fund gives an extra layer of protection against security threats.
                      </div>
                    </div>
                  </a></div>
              </div>
            </div>
          </div>
          <div data-v-08a1c11c="" style="min-height: 0px;">
            <div data-v-9d50a56e="" data-v-08a1c11c="" class="mt-160px <xl:mt-80px bit-theme-light-vue2">
              <div data-v-9d50a56e="" class="download text-primaryText white !bg-bg">
                <div data-v-9d50a56e="" class="mx-auto lg-new:w-987px lg-new:max-w-[calc(100%-203px)] pad:w-640px phone:w-full">
                  <div data-v-9d50a56e="" class="download-top">
                    <div data-v-9d50a56e="" class="download-top-title">
                      <span class="homepage-brand-color">Trade</span> anytime, anywhere!
                    </div>
                  </div>
                  <div data-v-9d50a56e="" class="download-middle">
                    <img data-v-9d50a56e="" src="../assets/img/download-overview.png?202402051109" loading="lazy" alt="download-middle-left" class="download-middle-left ">
                    <div data-v-9d50a56e="" class="download-middle-right">
                      <div data-v-9d50a56e="" class="mb-72px text-48px font-700 !leading-[120%] pad:mb-60px pad:text-32px phone:hidden">
                        <span class="homepage-brand-color">Trade</span> anytime, anywhere!
                      </div>
                      <div data-v-9d50a56e="" class="download-middle-right-top mb-24px">
                        <div data-v-9d50a56e="" class="relative">
                          <div data-v-9d50a56e="" class="img-scan">
                            <div data-v-9d50a56e="" class="download-middle-right-top-img">
                              <canvas height="166" width="166"></canvas>
                            </div>
                          </div>
                          <img data-v-9d50a56e="" src="../assets/img/logo-simple2.svg" loading="lazy" alt="home-logo-simple2" class="absolute ltIpad:left-4/10 ltIpad:top-4/10 ltIpad:w-20px logo_simple">
                        </div>
                        <div data-v-9d50a56e="" class="download-middle-right-top-right">
                          <div data-v-9d50a56e="" class="download-middle-right-top-right-title">
                            Scan to download the app
                          </div>
                          <div data-v-9d50a56e="" class="download-middle-right-top-right-des">
                            iOS/Android
                          </div>
                        </div>
                      </div>
                      <div data-v-9d50a56e="" class="download-middle-right-bottom lg-new:hidden">
                        <a data-v-9d50a56e="" target="_blank" href="https://apps.apple.com/app/id1442778704" class="download-middle-right-bottom-item">
                          <div data-v-9d50a56e="" class="download-middle-right-bottom-item-top">
                            <i data-v-9d50a56e="" class="iconfont icon-ios download-middle-right-bottom-item-top-icon"></i>
                          </div>
                          <div data-v-9d50a56e="" class="download-middle-right-bottom-item-bottom">App Store</div>
                        </a>
                        <a data-v-9d50a56e="" target="_blank" href="https://play.google.com/store/apps/details?id=com.bitget.exchange" class="download-middle-right-bottom-item">
                          <div data-v-9d50a56e="" class="download-middle-right-bottom-item-top">
                            <i data-v-9d50a56e="" class="iconfont icon-google-play download-middle-right-bottom-item-top-icon"></i>
                          </div>
                          <div data-v-9d50a56e="" class="download-middle-right-bottom-item-bottom">
                            Google Play
                          </div>
                        </a>
                        <a data-v-9d50a56e="" target="_blank" href="/asia/download" class="download-middle-right-bottom-item android-apk flex-1">
                          <div data-v-9d50a56e="" class="download-middle-right-bottom-item-top">
                            <i data-v-9d50a56e="" class="iconfont icon-a-AndroidAPK download-middle-right-bottom-item-top-icon"></i>
                          </div>
                          <div data-v-9d50a56e="" class="download-middle-right-bottom-item-bottom">
                            APK
                          </div>
                        </a></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-08a1c11c="" style="min-height: 0px;">
            <div data-v-08a1c11c="" class="home-con-journey-box home-parent-journey mt-140px pad:mt-100px phone:mt-32px">
              <div data-v-6a9227b3="" data-v-08a1c11c="" class="journey home-con-partner-journey">
                <div data-v-6a9227b3="" style="min-height: 45px;"></div>
                <div data-v-6a9227b3="" class="journey-crypto !bg-v3levelsurface1 mx-auto mt-50px py-100px pad:py-60px !pad:mt-20px phone:py-32px !phone:mt-32px">
                  <div data-v-6a9227b3="" class="journey-crypto-content">
                    <div data-v-6a9227b3="" class="journey-crypto-content-head">
                      <div data-v-6a9227b3="" class="journey-crypto-content-head-title">
                        Start your crypto journey now!
                      </div>
                      <div data-v-6a9227b3="" class="journey-crypto-content-head-desc">
                        Trade on Bitget. Trade smarter.
                      </div>
                    </div>
                    <div data-v-6a9227b3="" class="journey-crypto-content-body">
                      <div data-v-6a9227b3="" class="journey-crypto-content-body-item max-w-1/2">
                        <div data-v-6a9227b3="" class="journey-crypto-content-body-item-title">
                          $20,992,141,920
                        </div>
                        <div data-v-6a9227b3="" class="journey-crypto-content-body-item-desc">24h trading volume</div>
                      </div>
                      <div data-v-6a9227b3="" class="journey-crypto-content-body-item max-w-1/2">
                        <div data-v-6a9227b3="" class="journey-crypto-content-body-item-title">
                          800+
                        </div>
                        <div data-v-6a9227b3="" class="journey-crypto-content-body-item-desc">Cryptocurrencies</div>
                      </div>
                      <div data-v-6a9227b3="" class="journey-crypto-content-body-item max-w-1/2">
                        <div data-v-6a9227b3="" class="journey-crypto-content-body-item-title">
                          30 million
                        </div>
                        <div data-v-6a9227b3="" class="journey-crypto-content-body-item-desc">Registered users</div>
                      </div>
                      <div data-v-6a9227b3="" class="journey-crypto-content-body-item max-w-1/2">
                        <div data-v-6a9227b3="" class="journey-crypto-content-body-item-title">
                          180,000+
                        </div>
                        <div data-v-6a9227b3="" class="journey-crypto-content-body-item-desc">Elite traders</div>
                      </div>
                    </div>
                    <div data-v-6a9227b3="" class="flex items-center justify-center gap-42px mt-82px pad:mt-60px phone:flex-col phone:gap-19px phone:mt-28px">
                      <button data-v-6a9227b3="" type="button" class="bit-button journey-crypto-content-footer bit-button--main is-round"><span>
                    Sign Up
                    <i data-v-6a9227b3="" class="bit-icon rtl-rotate ml-10px" style="font-size: 14px;"><svg data-v-6a9227b3="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M20.78 12.53l-6.75 6.75a.75.75 0 01-1.06-1.06l5.47-5.47H3.75a.75.75 0 110-1.5h14.69l-5.47-5.47a.75.75 0 111.06-1.06l6.75 6.75a.747.747 0 010 1.06z"></path></svg></i></span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="minPhone:hidden mt-32px flex justify-center text-12px text-v3DisabledText" data-v-08a1c11c="">© 2024 Bitget</div>
          <div class="springking-welfare-fixed-box" data-v-08a1c11c="">
            <a><img src="https://img.bitgetimg.com/multiLang/web/60d60ea578f352627365a656c2b67ca7.png" alt="suspension-banner-1"></a><a><img src="https://img.bitgetimg.com/multiLang/web/3d8e8966c9de122f68ae886a8d90581f.png" alt="suspension-banner-2"></a>
          </div>
          <div data-v-08a1c11c="" class="bit-dialog__wrapper register-kyc-guide__wrapper is-centered is-responsive is-notitle" style="display: none;">
            <div role="dialog" aria-modal="true" aria-label="dialog" class="bit-dialog register-kyc-guide__dialog" style="margin-top: 15vh;">
              <div class="bit-dialog__header"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup>

</script>

<style scoped>

</style>