<template>
    <div>
       

    <div class="header-main-box !ltIpad:px-4" data-v-3a9783fb="">
        <div class="header-main" data-v-3a9783fb="">
            <div class="header-logo" data-v-3a9783fb=""><a href="/" class="cursor-pointer" data-v-3a9783fb=""><img
                        src="../assets/img/logo-light.svg" alt="register-logo-light"
                        class="w-103px h-32px block" data-v-3a9783fb=""></a></div>
        </div>
        <div class="header-right" data-v-3a9783fb="">
            <div class="header-main" data-v-3a9783fb="">
                <div class="other-box" style="display: flex; flex-direction: row" data-v-3a9783fb="">
                    <div class="nav-box has-sub download-qr !mr-16px white" data-v-078b2050="" data-v-3a9783fb=""><a
                            href="javascript:;" data-v-078b2050=""><svg width="24" height="24" viewBox="0 0 24 24"
                                fill="none" xmlns="http://www.w3.org/2000/svg" data-v-078b2050="">
                                <path
                                    d="M19.4301 6.99984C19.7062 6.99984 19.9301 6.77599 19.9301 6.49984V2.93984C19.9301 2.71441 19.8405 2.49821 19.6811 2.3388C19.5217 2.1794 19.3055 2.08984 19.0801 2.08984H4.91006C4.68462 2.08984 4.46842 2.1794 4.30901 2.3388C4.14961 2.49821 4.06006 2.71441 4.06006 2.93984V21.5298C4.06006 21.7553 4.14961 21.9715 4.30901 22.1309C4.46842 22.2903 4.68462 22.3798 4.91006 22.3798H19.0801C19.3055 22.3798 19.5217 22.2903 19.6811 22.1309C19.8405 21.9715 19.9301 21.7553 19.9301 21.5298V10.2498C19.9301 9.9737 19.7062 9.74984 19.4301 9.74984H18.7301C18.4539 9.74984 18.2301 9.9737 18.2301 10.2498V20.6798H5.76006V3.77984H18.2301V6.49984C18.2301 6.77599 18.4539 6.99984 18.7301 6.99984H19.4301Z"
                                    fill="var(--color-primary-text)" data-v-078b2050=""></path>
                                <path
                                    d="M12.8499 13.0899V7.87988C12.8499 7.60374 12.6261 7.37988 12.3499 7.37988H11.6499C11.3738 7.37988 11.1499 7.60374 11.1499 7.87988V13.0899H9.88893C9.48083 13.0899 9.24461 13.5524 9.48386 13.883L11.5942 16.7992C11.794 17.0753 12.2054 17.075 12.4048 16.7986L14.5083 13.8824C14.7468 13.5517 14.5105 13.0899 14.1028 13.0899H12.8499Z"
                                    fill="var(--color-primary)" data-v-078b2050=""></path>
                            </svg></a>
                        <div class="subnav-box mobile" data-v-078b2050="">
                            <div class="download" data-v-078b2050="">
                                <div style="display: none" data-v-078b2050="">https://www.bitget.com/asia/download</div>
                                <div class="box" data-v-078b2050=""></div>
                                <div class="img-container" data-v-078b2050="">
                                    <div style="background:#fff;margin-bottom:10px;" data-v-078b2050="">
                                        <qriously size="150" value="https://bitget.onelink.me/XqvW/a97627e1"><canvas
                                                height="150" width="150"></canvas></qriously>
                                    </div>
                                    Scan to download
                                    <a href="https://www.bitget.com/asia/download" target="_blank"
                                        class="download-click-btn bit-link bit-link--default is-underline"
                                        data-v-078b2050=""><!----><span class="bit-link--inner">
                                            <div class="download-click-btn-text" data-v-078b2050="">
                                                More downloads
                                            </div>
                                        </span><!----></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="nav-box has-sub !mr-10px" data-v-c0e48fb4="" data-v-3a9783fb=""><a href="javascript:;"
                            class="list-content" data-v-c0e48fb4=""><span class="white" data-v-c0e48fb4=""><svg
                                    width="24" height="24" viewBox="0 0 24 24" fill="none"
                                    xmlns="http://www.w3.org/2000/svg" data-v-c0e48fb4="">
                                    <path
                                        d="M21.504 11.9368H16.344C16.074 11.9368 16.064 12.5868 16.064 12.6568C16.064 12.7268 16.064 13.3668 16.344 13.3668H21.504C21.774 13.3668 21.784 12.7768 21.784 12.6568C21.784 12.5368 21.774 11.9368 21.504 11.9368Z"
                                        fill="var(--color-primary)" data-v-c0e48fb4=""></path>
                                    <path
                                        d="M12.454 2.28735C10.4026 2.28735 8.39724 2.8958 6.69169 4.03571C4.98613 5.17562 3.65699 6.79579 2.8724 8.69124C2.08782 10.5867 1.88304 12.6723 2.28398 14.6841C2.68492 16.696 3.67356 18.5437 5.12483 19.9936C6.5761 21.4435 8.4248 22.4303 10.437 22.8293C12.4493 23.2283 14.5347 23.0215 16.4293 22.2351C18.324 21.4487 19.9429 20.118 21.0812 18.4113C22.2195 16.7047 22.826 14.6988 22.824 12.6474C22.8213 9.89879 21.7276 7.26371 19.7832 5.32112C17.8387 3.37853 15.2026 2.28735 12.454 2.28735ZM21.244 12.6474C21.244 14.3859 20.7285 16.0853 19.7626 17.5308C18.7967 18.9763 17.4239 20.103 15.8178 20.7683C14.2116 21.4335 12.4442 21.6076 10.7391 21.2685C9.03405 20.9293 7.46782 20.0921 6.23851 18.8628C5.00921 17.6335 4.17205 16.0673 3.83288 14.3622C3.49372 12.6571 3.66779 10.8897 4.33308 9.28357C4.99837 7.6774 6.12501 6.30459 7.57052 5.33874C9.01603 4.37288 10.7155 3.85735 12.454 3.85735C14.7844 3.86 17.0187 4.78694 18.6665 6.43481C20.3144 8.08268 21.2413 10.3169 21.244 12.6474Z"
                                        fill="var(--color-primary-text)" data-v-c0e48fb4=""></path>
                                    <path
                                        d="M16.9639 9.02725C16.438 7.02958 15.4283 5.19215 14.0239 3.67725C13.9239 3.56725 13.8139 3.44725 13.6839 3.32725C13.5761 3.21813 13.4349 3.14808 13.2828 3.12816C13.1307 3.10824 12.9762 3.13958 12.8439 3.21725C12.7195 3.16317 12.5825 3.14481 12.4483 3.16424C12.314 3.18367 12.1879 3.24012 12.0839 3.32725L11.7439 3.64725C10.2812 5.03218 9.17042 6.74639 8.50391 8.64725C8.15057 9.70125 7.93872 10.7975 7.87391 11.9072H3.54392C3.37474 11.9297 3.22119 12.0178 3.11642 12.1525C3.01165 12.2872 2.96405 12.4577 2.98391 12.6272C2.96683 12.7951 3.01571 12.9631 3.12022 13.0956C3.22473 13.2281 3.37667 13.3147 3.54392 13.3372H7.86392C8.00004 16.3129 9.19937 19.1409 11.2439 21.3072V21.4172C11.1304 21.5534 11.0719 21.727 11.0799 21.904C11.0879 22.0811 11.1618 22.2487 11.2871 22.374C11.4125 22.4993 11.5801 22.5732 11.7571 22.5812C11.9342 22.5892 12.1078 22.5307 12.2439 22.4172C12.3156 22.4785 12.399 22.5244 12.4891 22.5522C12.5792 22.5799 12.674 22.5889 12.7677 22.5786C12.8614 22.5683 12.952 22.5389 13.0339 22.4923C13.1158 22.4456 13.1873 22.3826 13.2439 22.3072C13.3356 22.2034 13.3933 22.0739 13.4094 21.9363C13.4255 21.7987 13.3991 21.6595 13.3339 21.5372L13.4439 21.4372C14.537 20.4052 15.4317 19.1817 16.0839 17.8272C16.8274 16.3058 17.2528 14.6487 17.3339 12.9572C17.3339 12.7672 17.3339 12.5572 17.3339 12.3372C17.3607 11.2223 17.2363 10.1088 16.9639 9.02725ZM15.8739 13.4172V13.7572C15.7209 14.9136 15.3833 16.0379 14.8739 17.0872C14.2918 18.2884 13.4993 19.3755 12.5339 20.2972L12.4239 20.3872L12.3439 20.3072C11.4377 19.33 10.713 18.1989 10.2039 16.9672C9.72984 15.812 9.45591 14.5845 9.39391 13.3372L15.8739 13.4172ZM15.9239 11.9872H9.30391C9.49407 9.22503 10.7189 6.63612 12.7339 4.73725C12.7781 4.68812 12.8248 4.64138 12.8739 4.59725L12.9639 4.69725C14.2094 6.03158 15.106 7.65295 15.5739 9.41725C15.7605 10.1472 15.8711 10.8945 15.9039 11.6472C15.9139 11.7272 15.9139 11.8272 15.9239 11.9372V11.9872Z"
                                        fill="var(--color-primary-text)" data-v-c0e48fb4=""></path>
                                </svg></span></a>
                        <div data-v-053d8b4c="" data-v-c0e48fb4="" class="language-dialog__container"
                            language-list="[object Object],[object Object],[object Object],[object Object],[object Object],[object Object],[object Object],[object Object],[object Object],[object Object],[object Object],[object Object],[object Object],[object Object],[object Object],[object Object],[object Object],[object Object],[object Object],[object Object],[object Object],[object Object],[object Object]">
                            <div data-v-053d8b4c="" class="bit-dialog__wrapper is-centered is-responsive is-notitle"
                                style="display: none;">
                                <div role="dialog" aria-modal="true" aria-label="dialog"
                                    class="bit-dialog bit-dialog--center language-dialog__container"
                                    style="margin-top: 15vh; width: 840px;">
                                    <div class="bit-dialog__header"><!----><button type="button" aria-label="Close"
                                            class="bit-dialog__headerbtn"><i class="bit-icon"
                                                style="font-size: 20px;"><svg xmlns="http://www.w3.org/2000/svg"
                                                    viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                                                    <path
                                                        d="M19.28 18.22a.75.75 0 01-.817 1.223.75.75 0 01-.244-.162L12 13.06l-6.22 6.22a.75.75 0 01-1.06-1.062L10.94 12 4.72 5.78a.75.75 0 111.06-1.06L12 10.94l6.22-6.22a.75.75 0 011.06 1.06L13.06 12l6.22 6.22z">
                                                    </path>
                                                </svg></i></button></div><!----><!---->
                                </div>
                            </div>
                        </div> <!---->
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- <div data-v-79755347="" data-v-201148b6="" class="ip-alert-box flex justify-center items-center text-14px leading-20px w-full px-20px py-10px ltIpad:text-12px ltIpad:leading-18px white"><div data-v-79755347="" class="flex items-center ltIpad:justify-between"><img data-v-79755347="" alt="" src="/baseasset/img/ipLimit/i-warning-white.svg" class="warn-icon">
        Unfortunately, we are unable to provide services in your country/region: Republic of Singapore.
    </div> <span data-v-79755347="" class="el-icon-close ml-24px p-5px text-16px ltIpad:ml-12px"></span></div> -->
</div>
</template>


<script>

</script>

<style scoped></style>