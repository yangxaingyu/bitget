<template>
  <div class="sticky-header">
    <div class="global-theme">
      <header class="header-box asia">
        <div data-micro-type="Header" class="micro micro-light" data-micro-id="44162602">
          <div data-v-7c2db744 id="MicroHeaderFrame" class="micro-header micro-app-hide leading-140%">
            <div data-v-7c2db744 class="micro-download relative z-1 flex items-center py-12px px-16px border-b-line border-b cursor-pointer !md:hidden">
              <svg width="41" height="40" viewBox="0 0 41 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="0.998383" width="40" height="40" rx="8.71094" fill="#00F0FF"></rect>
                <path d="M19.458 15.7671H26.9266L34.567 23.3587C35.064 23.8525 35.0666 24.6558 34.5721 25.1521L24.7737 35H17.08L19.406 32.7387L27.946 24.2526L19.5144 15.7664" fill="#1B1B1B"></path>
                <path d="M22.5276 24.2336H15.059L7.41858 16.6419C6.92156 16.1481 6.91902 15.3449 7.4135 14.8485L17.2119 5H24.9056L22.5796 7.26132L14.0396 15.7474L22.4712 24.2336" fill="#1B1B1B"></path>
              </svg>
              <div class="ml-10px">
                <div class="text-14px text-primaryText font-700 leading-22px">Bitget App</div>
                <div class="text-12px text-thirdText leading-16px">Trade smarter</div>
              </div>
              <div class="flex items-center justify-content ml-auto px-16px h-34px bg-primary text-white text-14px font-500 rounded-100px">Open</div>
            </div>
            <div data-v-7c2db744 class="relative z-1 flex h-48px w-full box-border items-center px-24px text-14px text-primaryText md:!h-64px lt-md:!px-16px">
              <a data-v-7c2db744 class="text-primaryText micro-logo w-80px h-24px !md:w-103px !md:h-32px mr-20px" href="/" target="_self">
                <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0,0,103,32" fill="none" class="dark:text-[#00E0FF] !rotate-y-0 w-80px h-24px !md:w-103px !md:h-32px">
                  <g fill="currentColor" clip-path="url(#a)">
                    <path d="M40.372 16.074c.775-.44 1.395-.988 1.847-1.634a4.269 4.269 0 0 0 .777-2.496c0-1.722-.644-3.067-1.913-3.996-1.254-.92-2.979-1.385-5.129-1.385H28.18v19.951h8.085c2.264 0 4.077-.526 5.388-1.565 1.321-1.048 1.992-2.515 1.992-4.362 0-1.125-.316-2.092-.937-2.875-.557-.7-1.342-1.25-2.336-1.638Zm-7.985-5.915h3.229c1.013 0 1.777.196 2.274.583.49.38.73.882.73 1.53 0 .65-.24 1.176-.73 1.559-.497.386-1.261.582-2.274.582h-3.229v-4.254Zm6.079 12.083c-.56.449-1.415.676-2.54.676h-3.539v-4.882h3.54c1.124 0 1.98.22 2.542.65.557.43.827.997.827 1.736 0 .778-.271 1.373-.83 1.82ZM49.33 11.595h-4.236v14.918h4.235V11.595ZM91.161 13.84a6.832 6.832 0 0 0-2.497-1.86c-.986-.437-2.095-.659-3.294-.659-1.47 0-2.796.334-3.943.992a7.182 7.182 0 0 0-2.71 2.726c-.651 1.15-.98 2.482-.98 3.961 0 1.48.32 2.9.95 4.067a6.726 6.726 0 0 0 2.7 2.73c1.157.639 2.516.963 4.04.963 1.87 0 3.457-.47 4.72-1.399 1.215-.893 2.05-2.152 2.506-3.73h-4.264c-.224.537-.54.994-.993 1.316-.535.38-1.226.572-2.054.572-.718 0-1.334-.174-1.83-.518-.497-.345-.877-.853-1.127-1.514a5.795 5.795 0 0 1-.319-1.346h10.661l.021-.132c.19-1.203.142-2.343-.144-3.388a7.286 7.286 0 0 0-1.443-2.782Zm-9.027 3.54a6.1 6.1 0 0 1 .265-.908c.26-.67.635-1.185 1.116-1.529.479-.344 1.075-.517 1.771-.517.873 0 1.59.283 2.13.84.513.53.803 1.254.865 2.113h-6.147ZM49.418 6.563h-4.412v3.596h4.412V6.563ZM72.61 13.288a5.28 5.28 0 0 0-1.75-1.39c-.79-.383-1.715-.577-2.749-.577-1.265 0-2.4.313-3.37.927-.97.615-1.74 1.483-2.285 2.579-.545 1.094-.821 2.378-.821 3.818s.29 2.649.864 3.75c.575 1.105 1.372 1.985 2.369 2.617.998.633 2.137.955 3.385.955.942 0 1.803-.204 2.557-.607a4.563 4.563 0 0 0 1.49-1.255v1.624c0 1.007-.264 1.78-.784 2.295-.522.515-1.316.775-2.36.775-.9 0-1.607-.204-2.102-.607-.405-.33-.759-.762-.841-1.678h-4.084c.038 1.282.414 2.145.946 2.902.595.847 1.433 1.51 2.493 1.968 1.048.452 2.266.682 3.616.682 2.268 0 4.073-.57 5.365-1.693 1.3-1.129 1.958-2.71 1.958-4.698v-14.08h-3.896v1.693Zm-.745 7.339a3.06 3.06 0 0 1-1.128 1.29c-.48.3-1.06.454-1.722.454-.96 0-1.705-.327-2.28-.998-.574-.669-.865-1.587-.865-2.729 0-1.142.29-2.06.864-2.729.569-.662 1.336-.998 2.28-.998.945 0 1.779.34 2.366 1.013.592.679.892 1.601.892 2.74 0 .739-.137 1.396-.407 1.956ZM103.002 15.164v-3.568h-3.057V6.563h-4.207v5.033h-2.611v3.568h2.611v5.84c0 3.247.64 5.633 4.626 5.559l2.503-.05V23.17h-1.242c-1.772 0-1.673-1.033-1.673-2.952l-.007-5.053h3.057ZM60.606 15.164v-3.568h-3.057V6.563h-4.207v5.033H50.73v3.568h2.61v5.84c0 3.247.64 5.633 4.627 5.559l2.502-.05V23.17H59.23c-1.772 0-1.674-1.033-1.674-2.952l-.007-5.053h3.057ZM10.56 10.159h6.353l6.499 6.457c.423.42.425 1.104.004 1.526l-8.335 8.377H8.538l1.979-1.924 7.264-7.218-7.172-7.219"></path>
                    <path d="M13.17 17.36H6.819l-6.5-6.457a1.078 1.078 0 0 1-.004-1.526L8.65 1h6.544l-1.978 1.924-7.265 7.218 7.173 7.218"></path>
                  </g>
                  <defs>
                    <clipPath id="a">
                      <path fill="#fff" d="M0 0h103v32H0z"></path>
                    </clipPath>
                  </defs>
                </svg>
              </a>
              <div data-v-5f651626 data-v-7c2db744 id="MicroMenu" class="micro-menu flex items-center relative h-full min-w-[fit-content] lt-lg:!hidden">
                <div data-v-5f651626 class="group-menu mr-4px" data-menu-id="96">
                  <svg data-v-5f651626 width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9.46625 3.45227H4.96629C4.56847 3.45227 4.18695 3.6103 3.90564 3.89161C3.62434 4.17291 3.46631 4.55443 3.46631 4.95226V9.45221C3.46631 9.85003 3.62434 10.2316 3.90564 10.5129C4.18695 10.7942 4.56847 10.9522 4.96629 10.9522H9.46625C9.86407 10.9522 10.2456 10.7942 10.5269 10.5129C10.8082 10.2316 10.9662 9.85003 10.9662 9.45221V4.95226C10.9662 4.55443 10.8082 4.17291 10.5269 3.89161C10.2456 3.6103 9.86407 3.45227 9.46625 3.45227ZM9.46625 9.45221H4.96629V4.95226H9.46625V9.45221ZM19.0103 3.45227H14.5103C14.1125 3.45227 13.731 3.6103 13.4497 3.89161C13.1684 4.17291 13.0103 4.55443 13.0103 4.95226V9.45221C13.0103 9.85003 13.1684 10.2316 13.4497 10.5129C13.731 10.7942 14.1125 10.9522 14.5103 10.9522H19.0103C19.4081 10.9522 19.7896 10.7942 20.0709 10.5129C20.3522 10.2316 20.5103 9.85003 20.5103 9.45221V4.95226C20.5103 4.55443 20.3522 4.17291 20.0709 3.89161C19.7896 3.6103 19.4081 3.45227 19.0103 3.45227ZM19.0103 9.45221H14.5103V4.95226H19.0103V9.45221ZM9.46625 13.0689H4.96629C4.56847 13.0689 4.18695 13.2269 3.90564 13.5082C3.62434 13.7895 3.46631 14.171 3.46631 14.5689V19.0688C3.46631 19.4666 3.62434 19.8482 3.90564 20.1295C4.18695 20.4108 4.56847 20.5688 4.96629 20.5688H9.46625C9.86407 20.5688 10.2456 20.4108 10.5269 20.1295C10.8082 19.8482 10.9662 19.4666 10.9662 19.0688V14.5689C10.9662 14.171 10.8082 13.7895 10.5269 13.5082C10.2456 13.2269 9.86407 13.0689 9.46625 13.0689ZM9.46625 19.0688H4.96629V14.5689H9.46625V19.0688Z" fill="currentColor"></path>
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M21.2864 15.9465L18.1045 12.7646C17.8232 12.4833 17.4416 12.3252 17.0438 12.3252C16.646 12.3252 16.2645 12.4833 15.9832 12.7646L12.8012 15.9465C12.5199 16.2278 12.3619 16.6093 12.3619 17.0072C12.3619 17.405 12.5199 17.7865 12.8012 18.0678L15.9832 21.2498C16.2645 21.5311 16.646 21.6891 17.0438 21.6891C17.4416 21.6891 17.8232 21.5311 18.1045 21.2498L21.2864 18.0678C21.5677 17.7865 21.7258 17.405 21.7258 17.0072C21.7258 16.6093 21.5677 16.2278 21.2864 15.9465ZM17.0438 20.1891L13.8619 17.0072L17.0438 13.8252L20.2258 17.0072L17.0438 20.1891Z" fill="var(--group-primary)"></path>
                  </svg>
                </div>
                <span data-v-5f651626 class="text-primaryText menu-item group" data-menu-id="13"><span data-v-5f651626 class="title">Markets</span></span><span data-v-5f651626 class="text-primaryText menu-item group" data-menu-id="99"><span data-v-5f651626 class="title" data-testid="HeaderTradeButton">Trade</span></span><span data-v-5f651626 class="text-primaryText menu-item group" data-menu-id="259"><span data-v-5f651626 class="title">Futures</span><img data-v-5f651626 class="tag-img" src="https://img.bitgetimg.com/multiLang/web/348920c3f7c1828fa1820516d5460943.png" alt></span><span data-v-5f651626 class="text-primaryText menu-item group" data-menu-id="142"><span data-v-5f651626 class="title">Copy</span></span><span data-v-5f651626 class="text-primaryText menu-item group" data-menu-id="143"><span data-v-5f651626 class="title">Bots</span></span><span data-v-5f651626 class="text-primaryText menu-item group" data-menu-id="53"><span data-v-5f651626 class="title">Earn</span></span><span data-v-5f651626 class="text-primaryText menu-item group" data-menu-id="88"><span data-v-5f651626 class="title">Web3</span></span><span data-v-5f651626 class="text-primaryText menu-item group" data-menu-id="277"><span data-v-5f651626 class="title">Launchhub</span></span><a data-v-5f651626 class="text-primaryText menu-item group min-w-[fit-content]" href="/asia/copy-trading/traderpro?proSourceType=1&amp;utmTerm=19" target="_blank" data-menu-id="247"><img data-v-5f651626 class="h-24px group-hover:hidden" src="https://img.bitgetimg.com/multiLang/web/6146e63b2dd4207e82fb0c71a8d82d65.png" alt="TraderPro"><img data-v-5f651626 class="h-24px hidden group-hover:inline-block" src="https://img.bitgetimg.com/multiLang/web/16613340924bf9b9386583f94426ead0.png" alt="TraderPro"></a>
                <div data-v-5f651626 class="absolute top-100% rounded-12px light:shadow-popover light:border-1px light:border-line light:bg-bg dark:bg-dsColorLayerOne" style="will-change: transform, opacity, left, right; transition: opacity 0.15s; opacity: 0;">
                  <div class="relative z-1 bg-inherit rounded-12px overflow-hidden w-[fit-content]">
                    <div style="display: none;">
                      <div data-v-550f7d44 class="flex flex-row gap-4px min-h-338px max-h-504px bg-inherit" style="height: 584px; max-height: 404px;">
                        <div data-v-550f7d44 class="flex flex-row mt-4px h-[calc(100%-8px)] overflow-x-auto">
                          <div data-v-550f7d44 class="px-12px pt-8px h-auto">
                            <div data-v-550f7d44 class="px-16px h-48px leading-48px text-16px font-600">Promotions</div>
                            <div data-v-550f7d44 class="flex flex-col flex-wrap gap-8px pb-8px">
                              <a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/launchpool" target="_blank" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/2348a50e2515847796542df9257cda18.png" alt="Launchpool" loading="lazy" decoding="async" width="24" height="24">
                                <div data-v-097919ff class="flex-1">
                                  <div data-v-097919ff class="title">
                                    <div data-v-097919ff class="line-clamp-2">Launchpool</div>
                                  </div>
                                </div>
                              </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/poolx" target="_blank" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/81f3b95e38d40da5a1832b9414880060.png" alt="PoolX  " loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">PoolX</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/candy-bomb" target="_self" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/6a11919833b2369d444fef2c0678a425.png" alt="CandyBomb" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">CandyBomb</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/referral-all-program" target="_blank" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/dbb59021b4e4a6ef54f9e222cd55ea1d.png" alt="Referral" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Referral</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/rewards" target="_self" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/8b49c214d9c9f4ed5f1361dbb578755e.png" alt="Rewards" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Rewards</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/coin-buddy" target="_blank" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/2971a86e61b151618a35e7662cfaa310.png" alt="Coin Buddy" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Coin Buddy</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/referral" target="_self" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/c3f295f7d060e41896313a7d78b7f3ff.png" alt="Invite friends" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Invite friends</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/turntable" target="_self" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/d56e01c792f43792586c525ce15c9722.png" alt="Fortune Wheel" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Fortune Wheel</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/offer" target="_self" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/a5917ba9c4f97457ce00890260902433.png" alt="Assist2Earn" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Assist2Earn</div>
                                </div>
                              </div>
                            </a></div>
                          </div>
                          <div data-v-550f7d44 class="px-12px pt-8px h-auto">
                            <div data-v-550f7d44 class="px-16px h-48px leading-48px text-16px font-600">Programs</div>
                            <div data-v-550f7d44 class="flex flex-col flex-wrap gap-8px pb-8px">
                              <a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/affiliates" target="_self" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/db7c27914a30d0b98dc39b07cc1b9f0c.png" alt="Affiliates" loading="lazy" decoding="async" width="24" height="24">
                                <div data-v-097919ff class="flex-1">
                                  <div data-v-097919ff class="title">
                                    <div data-v-097919ff class="line-clamp-2">Affiliates</div>
                                  </div>
                                </div>
                              </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/kol-promotion" target="_blank" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/02a9649cef56e42610cc7617344f01bd.png" alt="Booster Platform" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Booster Platform</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/incubation-program" target="_self" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/4e518fbd21c7b4436989ec69209c1022.png" alt="Bitget Builders" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Bitget Builders</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/broker" target="_self" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/4e66c4e84c0f70a9f750266fe0e4289c.png" alt="Broker program" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Broker program</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/vip/vipIntroduce" target="_self" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/0170a9a63a2c8b2317457d6cce5d16ea.png" alt="VIP program" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">VIP program</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/custody" target="_self" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/1a455da76ca47a925059bce4d7d3d780.png" alt="Asset custody" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Asset custody</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/taxes-api" target="_blank" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/026e687ce9f157856f4d183a7fb8bb85.png" alt="Tax API" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Tax API</div>
                                </div>
                              </div>
                            </a></div>
                          </div>
                          <div data-v-550f7d44 class="px-12px pt-8px h-auto">
                            <div data-v-550f7d44 class="px-16px h-48px leading-48px text-16px font-600">Learn and explore</div>
                            <div data-v-550f7d44 class="flex flex-col flex-wrap gap-8px pb-8px">
                              <a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/support/announcement-center" target="_blank" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/837d421d78e48b1efdf12839dc79ef73.png" alt="Announcement center" loading="lazy" decoding="async" width="24" height="24">
                                <div data-v-097919ff class="flex-1">
                                  <div data-v-097919ff class="title">
                                    <div data-v-097919ff class="line-clamp-2">Announcement center</div>
                                  </div>
                                </div>
                              </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/academy" target="_self" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/7bd68d86c3ae9d8d5449793ea363e828.png" alt="Bitget Academy" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Bitget Academy</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/kyc?source=1" target="_self" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/c5bc2007c5716e346edb4523bb16ff17.png" alt="ID verification zone" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">ID verification zone</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/futures-tutorial?source=2" target="_blank" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/9c8d7967627ab1c056c0d038067d0cb2.png" alt="Futures zone" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Futures zone</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/blog" target="_self" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/957e2f5d9b553f536ea5c828467014b5.png" alt="Bitget Blog" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Bitget Blog</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/learn-to-earn" target="_self" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/1165361e17de977ba99a5a72f100df44.png" alt="Learn2Earn" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Learn2Earn</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/research" target="_self" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/90b06592e183a6d85fc9693b5b06b1eb.png" alt="Bitget Research" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Bitget Research</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/support" target="_self" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/86702b5fa64620751f316f79df83ee3d.png" alt="Help Center" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Help Center</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/feedback" target="_self" style="height: 48px;"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/4d09c04f133d92b9e82596d33d2cd261.png" alt="Submit feedback" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Submit feedback</div>
                                </div>
                              </div>
                            </a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div style="display: none;">
                      <div data-v-3d905981 class="flex bg-inherit max-h-504px">
                        <div data-v-3d905981 class="relative p-12px w-276px overflow-y-auto">
                          <div data-v-3d905981 class="mx-2px pt-4px pb-18px px-14px font-600 text-16px leading-22px [&amp;>span]:inline-flex [&amp;>span]:items-center [&amp;>span]:align-middle [&amp;_img]:px-6px">Market is up by
                            <span class="text-contentTradeBuy mr-6px">
                              <img src="../assets/img/icon-up.8e87c9cc.svg" alt="up">
                                1.47%
                              </span>
                            in the last 24 hours.
                          </div>
                          <div data-v-3d905981 class="flex gap-12px flex-col">
                            <a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/markets/overview" target="_self" data-testid="menu_market_chance_title"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/9950b9a2950877c0c29d5025c88db0c9.png" alt="Opportunities" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Opportunities</div>
                                </div>
                                <div data-v-097919ff class="desc">Timely seize new market opportunities</div>
                              </div>
                            </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/markets" target="_self" data-testid="menu_market_title"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/bd583eb48b634071f770e1c29151ed2e.png" alt="Markets" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Markets</div>
                              </div>
                              <div data-v-097919ff class="desc">View the latest crypto prices and volume</div>
                            </div>
                          </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/markets/trading-data" target="_self" data-testid="menu_menu_data"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/9b9e8f4ee7f1e27b3cd259d34919138b.png" alt="Data" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Data</div>
                                <img data-v-097919ff class="ml-8px h-16px" src="https://img.bitgetimg.com/multiLang/web/348920c3f7c1828fa1820516d5460943.png" alt>
                              </div>
                              <div data-v-097919ff class="desc">Halving info and trading data</div>
                            </div>
                          </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/insights" target="_blank" data-testid="menu_insight"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/985ef41ce3533f9320e91e3a7d246494.png" alt="Insights" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Insights</div>
                              </div>
                              <div data-v-097919ff class="desc">Insights from experts</div>
                            </div>
                          </a></div>
                        </div>
                      </div>
                    </div>
                    <div style="display: none;">
                      <div data-v-3d905981 class="flex bg-inherit max-h-504px">
                        <div data-v-3d905981 class="relative p-12px w-276px overflow-y-auto">
                          <div data-v-3d905981 class="flex gap-12px flex-col">
                            <a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/spot/BTCUSDT" target="_self" data-testid="menu_spot"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/2b8ce0f6122dac6a6b130203725b8ddc.png" alt="Spot" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Spot</div>
                                </div>
                                <div data-v-097919ff class="desc">Buy and sell crypto with ease</div>
                              </div>
                              <svg data-v-097919ff width="13" height="14" viewBox="0 0 13 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="arrow">
                                <g id="i-down">
                                  <path id="Line 72 (Stroke)" fill-rule="evenodd" clip-rule="evenodd" d="M4.84492 11.8125L4.21875 11.2479L8.72283 6.75L4.21875 2.25209L4.84492 1.6875L9.84375 6.75L4.84492 11.8125Z" fill="#B8B8B8"></path>
                                </g>
                              </svg>
                            </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/spot/BTCUSDT?type=cross" target="_self" data-testid="menu_margin"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/910ab6e9231835476b028e4e00809bf7.png" alt="Margin" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Margin</div>
                              </div>
                              <div data-v-097919ff class="desc">Trade with leverage</div>
                            </div>
                          </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/convert" target="_self" data-testid="menu_spot_convert"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/a2cd492cd22e0c33d49706e0f1540706.png" alt="Convert" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Convert</div>
                              </div>
                              <div data-v-097919ff class="desc">Zero fees, no slippage</div>
                            </div>
                          </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/bitget-api" target="_self" data-testid="menu_api_trading"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/c78567c2ea2b36de01c21c924c791fa6.png" alt="APIs" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">APIs</div>
                              </div>
                              <div data-v-097919ff class="desc">Take your trading to the next level</div>
                            </div>
                          </a></div>
                        </div>
                      </div>
                    </div>
                    <div style="display: none;">
                      <div data-v-3d905981 class="flex bg-inherit max-h-504px">
                        <div data-v-3d905981 class="relative p-12px w-276px overflow-y-auto">
                          <div data-v-3d905981 class="flex gap-12px flex-col">
                            <a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/futures" target="_blank" data-testid><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/b8a92427a023b63772ddf47233479d30.png" alt="Futures overview" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Futures overview</div>
                                </div>
                                <div data-v-097919ff class="desc">Browse all Bitget futures services</div>
                              </div>
                            </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/futures/usdt/BTCUSDT" target="_blank" data-testid="menu_menu_usdt_m"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/5cf4620605bb97a99785da3ca5d4c57f.png" alt="USDT-M Futures" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">USDT-M Futures</div>
                              </div>
                              <div data-v-097919ff class="desc">Futures settled in USDT</div>
                            </div>
                            <svg data-v-097919ff width="13" height="14" viewBox="0 0 13 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="arrow">
                              <g id="i-down">
                                <path id="Line 72 (Stroke)" fill-rule="evenodd" clip-rule="evenodd" d="M4.84492 11.8125L4.21875 11.2479L8.72283 6.75L4.21875 2.25209L4.84492 1.6875L9.84375 6.75L4.84492 11.8125Z" fill="#B8B8B8"></path>
                              </g>
                            </svg>
                          </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/futures/usdc/BTCPERP" target="_blank" data-testid="menu_menu_usdc_m"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/e8471ffeee6cc04f36bcf7adfe97965d.png" alt="USDC-M Futures" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">USDC-M Futures</div>
                              </div>
                              <div data-v-097919ff class="desc">Futures settled in USDC</div>
                            </div>
                            <svg data-v-097919ff width="13" height="14" viewBox="0 0 13 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="arrow">
                              <g id="i-down">
                                <path id="Line 72 (Stroke)" fill-rule="evenodd" clip-rule="evenodd" d="M4.84492 11.8125L4.21875 11.2479L8.72283 6.75L4.21875 2.25209L4.84492 1.6875L9.84375 6.75L4.84492 11.8125Z" fill="#B8B8B8"></path>
                              </g>
                            </svg>
                          </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/futures/usd/BTCUSD" target="_blank" data-testid="menu_menu_coin_m"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/060290a1420c968249ffb07bc6b3d20b.png" alt="Coin-M Futures" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Coin-M Futures</div>
                              </div>
                              <div data-v-097919ff class="desc">Futures settled in cryptocurrencies</div>
                            </div>
                            <svg data-v-097919ff width="13" height="14" viewBox="0 0 13 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="arrow">
                              <g id="i-down">
                                <path id="Line 72 (Stroke)" fill-rule="evenodd" clip-rule="evenodd" d="M4.84492 11.8125L4.21875 11.2479L8.72283 6.75L4.21875 2.25209L4.84492 1.6875L9.84375 6.75L4.84492 11.8125Z" fill="#B8B8B8"></path>
                              </g>
                            </svg>
                          </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/events/futures-tutorial?source=2" target="_blank" data-testid><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/460911878574ab5c4c70b9bcadb5fc3b.png" alt="Futures Kickoff" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Futures Kickoff</div>
                              </div>
                              <div data-v-097919ff class="desc">For beginners to try out futures trading</div>
                            </div>
                          </a><span data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" data-testid><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/898716ad0e4267b2adf87b941c215b73.png" alt="Futures promotions" loading="lazy" decoding="async" width="24" height="24"><div data-v-097919ff class="flex-1"><div data-v-097919ff class="title"><div data-v-097919ff class="line-clamp-2">Futures promotions</div></div><div data-v-097919ff class="desc">Generous rewards await</div></div></span><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/events/super-pairs" target="_blank" data-testid><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/dc81606213a2edc5d8cc3fd4e2053b6d.png" alt="Super Pairs" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Super Pairs</div>
                                <img data-v-097919ff class="ml-8px h-16px" src="https://img.bitgetimg.com/multiLang/web/07e6ffb7263fb48a0ecadaeee7b1a48c.png" alt>
                              </div>
                              <div data-v-097919ff class="desc">Trade the newest &amp; hottest futures pairs</div>
                            </div>
                          </a></div>
                        </div>
                      </div>
                    </div>
                    <div style="display: none;">
                      <div data-v-e216624f class="flex flex-row gap-4px min-h-320px max-h-504px bg-inherit">
                        <div data-v-e216624f class="menu-right-border p-24px w-260px b-r-line">
                          <img data-v-e216624f class="w-40px h-40px rtl:rotate-y-180" src="https://img.bitgetimg.com/multiLang/web/146444adcf9d63ce8abc4d9d31b8b14f.png" alt="Bitget TraderPro program">
                          <div data-v-e216624f class="my-8px font-700 text-16px leading-140% whitespace-pre-line">Bitget TraderPro program</div>
                          <div data-v-e216624f class="text-12px text-contentTertiary leading-140%">Unlock your trading potential! Become a verified Bitget elite trader and earn 10,000 USDT to help skyrocket your profits. Join now and start your journey to success!</div>
                          <button data-v-e216624f aria-disabled="false" type="button" class="mi-button is-round mt-20px"><!--v-if--><span class>Start challenge <i data-v-e216624f class="mi-icon ml-4px" style="font-size: 16px;"><svg data-v-e216624f xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M20.78 12.53l-6.75 6.75a.75.75 0 01-1.06-1.06l5.47-5.47H3.75a.75.75 0 110-1.5h14.69l-5.47-5.47a.75.75 0 111.06-1.06l6.75 6.75a.747.747 0 010 1.06z"></path></svg></i></span><!--v-if-->
                          </button>
                        </div>
                        <div data-v-e216624f class="p-12px w-260px overflow-y-auto">
                          <a data-v-097919ff data-v-e216624f class="text-primaryText menu-item" href="/asia/copy-trading/overview" target="_self"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/7bcba41424cbce3180d86c6c55f8e352.png" alt="Overview" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Overview</div>
                              </div>
                              <div data-v-097919ff class="desc">Introduction to Bitget copy trading and its advantages</div>
                            </div>
                          </a>
                          <div data-v-e216624f class="mt-8px mb-4px p-12px text-16px font-700">Copy what suits you</div>
                          <div data-v-e216624f class="flex flex-col gap-8px">
                            <a data-v-097919ff data-v-e216624f class="text-primaryText menu-item" href="/asia/copy-trading/futures" target="_self"><img data-v-097919ff class="menu-icon unreverse" src="https://img.bitgetimg.com/multiLang/web/89c679ac256ff1f17f50f246128107d2.png" alt="Futures Copy Trading" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Futures Copy Trading</div>
                                </div>
                                <div data-v-097919ff class="desc">Follow the world's top futures trading experts</div>
                              </div>
                            </a><a data-v-097919ff data-v-e216624f class="text-primaryText menu-item" href="/asia/copy-trading/spot" target="_self"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/7337ab9e17d914baf14ba023acd9d81b.png" alt="Spot Copy Trading" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Spot Copy Trading</div>
                              </div>
                              <div data-v-097919ff class="desc">Follow the world's top spot trading experts</div>
                            </div>
                          </a><a data-v-097919ff data-v-e216624f class="text-primaryText menu-item" href="/asia/copy-trading/strategy" target="_self"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/299df18fe41d614ed0e0c1856a93a974.png" alt="Bot Copy Trading" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Bot Copy Trading</div>
                              </div>
                              <div data-v-097919ff class="desc">Copy top bots to trade smarter</div>
                            </div>
                          </a></div>
                        </div>
                        <div data-v-e216624f class="menu-left-border flex flex-col p-12px w-440px">
                          <div data-v-e216624f class="flex justify-between">
                            <a data-v-e216624f class="text-primaryText flex items-center px-12px h-36px text-16px font-700 cursor-pointer rounded-99px hover:bg-bgSecondary" href="/copy-trading/leaderboard-ranking/futures-roi" target="_self">Leaderboard
                              <svg data-v-e216624f width="13" height="14" viewBox="0 0 13 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="ml-4px [&amp;_path]:fill-contentTertiary">
                                <g id="i-down">
                                  <path id="Line 72 (Stroke)" fill-rule="evenodd" clip-rule="evenodd" d="M4.84492 11.8125L4.21875 11.2479L8.72283 6.75L4.21875 2.25209L4.84492 1.6875L9.84375 6.75L4.84492 11.8125Z" fill="#B8B8B8"></path>
                                </g>
                              </svg>
                            </a></div>
                          <div data-v-e216624f class="flex flex-1 items-center">
                            <div data-v-e216624f class="flex items-end gap-8px p-12px">
                              <div data-v-e216624f class="group card order-1 !h-232px !w-132px">
                                <div data-v-e216624f class="relative mx-auto mb-8px w-44px h-44px !mb-20px !w-70px !h-70px">
                                  <img data-v-e216624f class="rounded-100px w-full h-full" src="../assets/img/avatar.2d0040f2.svg" alt="avatar"><img data-v-e216624f class="absolute -top-4px -left-4px w-32px h-16px" src="../assets/img/no1.4cf28e69.svg" alt="rank-1"><img data-v-e216624f class="absolute bottom-0 right-0 w-20px h-20px" src="/micro-runtime/assets/badge.8ab5fd57.svg" alt="badge">
                                </div>
                                <div data-v-e216624f class="text-16px font-700 truncate mi-tooltip__trigger mi-tooltip__trigger">BGUSER-MN0KQQ3S</div>
                                <div data-v-e216624f class="flex justify-center items-center mt-2px">
                                  <svg data-v-e216624f width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="mr-4px">
                                    <path d="M6.91214 8.63677C7.49849 8.24641 7.94366 7.67771 8.1818 7.01479C8.41995 6.35186 8.43844 5.62989 8.23453 4.95564C8.03062 4.28139 7.61514 3.69066 7.04953 3.27081C6.48392 2.85096 5.79821 2.62427 5.09381 2.62427C4.3894 2.62427 3.70369 2.85096 3.13808 3.27081C2.57248 3.69066 2.157 4.28139 1.95309 4.95564C1.74918 5.62989 1.76766 6.35186 2.00581 7.01479C2.24396 7.67771 2.68912 8.24641 3.27547 8.63677C2.21482 9.02769 1.309 9.75108 0.693165 10.699C0.660799 10.7471 0.638317 10.8012 0.627027 10.858C0.615737 10.9149 0.615863 10.9734 0.627399 11.0303C0.638935 11.0871 0.661649 11.1411 0.694222 11.189C0.726796 11.237 0.768578 11.278 0.817141 11.3097C0.865703 11.3413 0.920077 11.363 0.977103 11.3735C1.03413 11.384 1.09267 11.383 1.14932 11.3707C1.20596 11.3583 1.25959 11.3349 1.30709 11.3016C1.35458 11.2683 1.39499 11.226 1.42597 11.177C1.82321 10.566 2.36677 10.0639 3.00731 9.71638C3.64784 9.36882 4.36505 9.18678 5.09381 9.18678C5.82256 9.18678 6.53977 9.36882 7.1803 9.71638C7.82084 10.0639 8.36441 10.566 8.76165 11.177C8.82581 11.2723 8.92494 11.3386 9.03758 11.3615C9.15023 11.3844 9.26736 11.362 9.36363 11.2992C9.45991 11.2364 9.52761 11.1382 9.55209 11.0259C9.57657 10.9136 9.55586 10.7962 9.49445 10.699C8.87862 9.75108 7.97279 9.02769 6.91214 8.63677ZM2.68759 5.9068C2.68759 5.4309 2.82871 4.96568 3.09311 4.56998C3.35751 4.17428 3.73331 3.86587 4.17299 3.68375C4.61267 3.50163 5.09648 3.45398 5.56324 3.54682C6.03 3.63967 6.45874 3.86884 6.79526 4.20535C7.13177 4.54187 7.36094 4.97061 7.45379 5.43737C7.54663 5.90413 7.49898 6.38794 7.31686 6.82762C7.13474 7.2673 6.82633 7.6431 6.43063 7.9075C6.03493 8.1719 5.56971 8.31302 5.09381 8.31302C4.45586 8.3123 3.84425 8.05855 3.39315 7.60746C2.94206 7.15636 2.68831 6.54475 2.68759 5.9068ZM14.1795 11.3044C14.0823 11.3678 13.9639 11.3899 13.8504 11.366C13.7369 11.3421 13.6375 11.2741 13.5741 11.177C13.1773 10.5656 12.6338 10.0634 11.9932 9.71594C11.3525 9.36853 10.635 9.18703 9.90624 9.18801C9.79021 9.18801 9.67893 9.14192 9.59688 9.05987C9.51484 8.97782 9.46875 8.86654 9.46875 8.75051C9.46875 8.63448 9.51484 8.5232 9.59688 8.44116C9.67893 8.35911 9.79021 8.31302 9.90624 8.31302C10.2606 8.31269 10.6105 8.23409 10.931 8.08285C11.2514 7.93161 11.5345 7.71146 11.76 7.43813C11.9855 7.16479 12.1479 6.84503 12.2355 6.50167C12.3231 6.15832 12.3338 5.79985 12.2668 5.45189C12.1998 5.10393 12.0568 4.77506 11.848 4.48877C11.6391 4.20249 11.3696 3.96587 11.0588 3.7958C10.7479 3.62574 10.4033 3.52644 10.0496 3.505C9.69588 3.48355 9.34181 3.5405 9.01266 3.67176C8.95899 3.69496 8.90122 3.70716 8.84276 3.70766C8.78429 3.70815 8.72632 3.69692 8.67227 3.67463C8.61822 3.65234 8.56919 3.61945 8.52807 3.57789C8.48694 3.53633 8.45457 3.48694 8.43286 3.43266C8.41114 3.37838 8.40053 3.32029 8.40165 3.26183C8.40276 3.20338 8.41558 3.14574 8.43935 3.09232C8.46312 3.03891 8.49735 2.9908 8.54003 2.95083C8.5827 2.91087 8.63296 2.87987 8.68782 2.85966C9.44111 2.55924 10.279 2.54843 11.0398 2.82931C11.8005 3.1102 12.4304 3.66287 12.8077 4.38072C13.185 5.09858 13.2832 5.93074 13.0832 6.71667C12.8831 7.5026 12.3992 8.18662 11.7246 8.63677C12.7852 9.02769 13.6911 9.75108 14.3069 10.699C14.3703 10.7962 14.3924 10.9146 14.3685 11.0281C14.3446 11.1416 14.2766 11.241 14.1795 11.3044Z" fill="currentColor"></path>
                                  </svg>
                                  299 <span data-v-e216624f class="text-contentTertiary">/</span> 300
                                </div>
                                <div data-v-e216624f class="mt-12px text-12px font-400 text-contentTertiary !mt-20px">ROI</div>
                                <div data-v-e216624f class="font-700 text-contentTradeBuy mt-2px">
                                  <span data-v-4b336f5e data-v-e216624f class="text-contentTradeBuy" dir="ltr">+1,277.75%</span>
                                </div>
                              </div>
                              <div data-v-e216624f class="group card">
                                <div data-v-e216624f class="relative mx-auto mb-8px w-44px h-44px">
                                  <img data-v-e216624f class="rounded-100px w-full h-full" src="/micro-runtime/assets/avatar.2d0040f2.svg" alt="avatar"><img data-v-e216624f class="absolute -top-4px -left-4px w-32px h-16px" src="/micro-runtime/assets/no2.f82a9e98.svg" alt="rank-2"><img data-v-e216624f class="absolute bottom-0 right-0" src="../assets/img/badge.8ab5fd57.svg" alt="badge">
                                </div>
                                <div data-v-e216624f class="text-16px font-700 truncate mi-tooltip__trigger mi-tooltip__trigger">BGUSER-5KRL3S4P</div>
                                <div data-v-e216624f class="flex justify-center items-center mt-2px">
                                  <svg data-v-e216624f width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="mr-4px">
                                    <path d="M6.91214 8.63677C7.49849 8.24641 7.94366 7.67771 8.1818 7.01479C8.41995 6.35186 8.43844 5.62989 8.23453 4.95564C8.03062 4.28139 7.61514 3.69066 7.04953 3.27081C6.48392 2.85096 5.79821 2.62427 5.09381 2.62427C4.3894 2.62427 3.70369 2.85096 3.13808 3.27081C2.57248 3.69066 2.157 4.28139 1.95309 4.95564C1.74918 5.62989 1.76766 6.35186 2.00581 7.01479C2.24396 7.67771 2.68912 8.24641 3.27547 8.63677C2.21482 9.02769 1.309 9.75108 0.693165 10.699C0.660799 10.7471 0.638317 10.8012 0.627027 10.858C0.615737 10.9149 0.615863 10.9734 0.627399 11.0303C0.638935 11.0871 0.661649 11.1411 0.694222 11.189C0.726796 11.237 0.768578 11.278 0.817141 11.3097C0.865703 11.3413 0.920077 11.363 0.977103 11.3735C1.03413 11.384 1.09267 11.383 1.14932 11.3707C1.20596 11.3583 1.25959 11.3349 1.30709 11.3016C1.35458 11.2683 1.39499 11.226 1.42597 11.177C1.82321 10.566 2.36677 10.0639 3.00731 9.71638C3.64784 9.36882 4.36505 9.18678 5.09381 9.18678C5.82256 9.18678 6.53977 9.36882 7.1803 9.71638C7.82084 10.0639 8.36441 10.566 8.76165 11.177C8.82581 11.2723 8.92494 11.3386 9.03758 11.3615C9.15023 11.3844 9.26736 11.362 9.36363 11.2992C9.45991 11.2364 9.52761 11.1382 9.55209 11.0259C9.57657 10.9136 9.55586 10.7962 9.49445 10.699C8.87862 9.75108 7.97279 9.02769 6.91214 8.63677ZM2.68759 5.9068C2.68759 5.4309 2.82871 4.96568 3.09311 4.56998C3.35751 4.17428 3.73331 3.86587 4.17299 3.68375C4.61267 3.50163 5.09648 3.45398 5.56324 3.54682C6.03 3.63967 6.45874 3.86884 6.79526 4.20535C7.13177 4.54187 7.36094 4.97061 7.45379 5.43737C7.54663 5.90413 7.49898 6.38794 7.31686 6.82762C7.13474 7.2673 6.82633 7.6431 6.43063 7.9075C6.03493 8.1719 5.56971 8.31302 5.09381 8.31302C4.45586 8.3123 3.84425 8.05855 3.39315 7.60746C2.94206 7.15636 2.68831 6.54475 2.68759 5.9068ZM14.1795 11.3044C14.0823 11.3678 13.9639 11.3899 13.8504 11.366C13.7369 11.3421 13.6375 11.2741 13.5741 11.177C13.1773 10.5656 12.6338 10.0634 11.9932 9.71594C11.3525 9.36853 10.635 9.18703 9.90624 9.18801C9.79021 9.18801 9.67893 9.14192 9.59688 9.05987C9.51484 8.97782 9.46875 8.86654 9.46875 8.75051C9.46875 8.63448 9.51484 8.5232 9.59688 8.44116C9.67893 8.35911 9.79021 8.31302 9.90624 8.31302C10.2606 8.31269 10.6105 8.23409 10.931 8.08285C11.2514 7.93161 11.5345 7.71146 11.76 7.43813C11.9855 7.16479 12.1479 6.84503 12.2355 6.50167C12.3231 6.15832 12.3338 5.79985 12.2668 5.45189C12.1998 5.10393 12.0568 4.77506 11.848 4.48877C11.6391 4.20249 11.3696 3.96587 11.0588 3.7958C10.7479 3.62574 10.4033 3.52644 10.0496 3.505C9.69588 3.48355 9.34181 3.5405 9.01266 3.67176C8.95899 3.69496 8.90122 3.70716 8.84276 3.70766C8.78429 3.70815 8.72632 3.69692 8.67227 3.67463C8.61822 3.65234 8.56919 3.61945 8.52807 3.57789C8.48694 3.53633 8.45457 3.48694 8.43286 3.43266C8.41114 3.37838 8.40053 3.32029 8.40165 3.26183C8.40276 3.20338 8.41558 3.14574 8.43935 3.09232C8.46312 3.03891 8.49735 2.9908 8.54003 2.95083C8.5827 2.91087 8.63296 2.87987 8.68782 2.85966C9.44111 2.55924 10.279 2.54843 11.0398 2.82931C11.8005 3.1102 12.4304 3.66287 12.8077 4.38072C13.185 5.09858 13.2832 5.93074 13.0832 6.71667C12.8831 7.5026 12.3992 8.18662 11.7246 8.63677C12.7852 9.02769 13.6911 9.75108 14.3069 10.699C14.3703 10.7962 14.3924 10.9146 14.3685 11.0281C14.3446 11.1416 14.2766 11.241 14.1795 11.3044Z" fill="currentColor"></path>
                                  </svg>
                                  19 <span data-v-e216624f class="text-contentTertiary">/</span> 300
                                </div>
                                <div data-v-e216624f class="mt-12px text-12px font-400 text-contentTertiary">ROI</div>
                                <div data-v-e216624f class="font-700 text-contentTradeBuy mt-2px">
                                  <span data-v-4b336f5e data-v-e216624f class="text-contentTradeBuy" dir="ltr">+988.79%</span>
                                </div>
                              </div>
                              <div data-v-e216624f class="group card order-2">
                                <div data-v-e216624f class="relative mx-auto mb-8px w-44px h-44px">
                                  <img data-v-e216624f class="rounded-100px w-full h-full" src="/micro-runtime/assets/avatar.2d0040f2.svg" alt="avatar"><img data-v-e216624f class="absolute -top-4px -left-4px w-32px h-16px" src="/micro-runtime/assets/no3.ab023367.svg" alt="rank-3"><img data-v-e216624f class="absolute bottom-0 right-0" src="/micro-runtime/assets/badge.8ab5fd57.svg" alt="badge">
                                </div>
                                <div data-v-e216624f class="text-16px font-700 truncate mi-tooltip__trigger mi-tooltip__trigger">CryptoMasterTrader</div>
                                <div data-v-e216624f class="flex justify-center items-center mt-2px">
                                  <svg data-v-e216624f width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="mr-4px">
                                    <path d="M6.91214 8.63677C7.49849 8.24641 7.94366 7.67771 8.1818 7.01479C8.41995 6.35186 8.43844 5.62989 8.23453 4.95564C8.03062 4.28139 7.61514 3.69066 7.04953 3.27081C6.48392 2.85096 5.79821 2.62427 5.09381 2.62427C4.3894 2.62427 3.70369 2.85096 3.13808 3.27081C2.57248 3.69066 2.157 4.28139 1.95309 4.95564C1.74918 5.62989 1.76766 6.35186 2.00581 7.01479C2.24396 7.67771 2.68912 8.24641 3.27547 8.63677C2.21482 9.02769 1.309 9.75108 0.693165 10.699C0.660799 10.7471 0.638317 10.8012 0.627027 10.858C0.615737 10.9149 0.615863 10.9734 0.627399 11.0303C0.638935 11.0871 0.661649 11.1411 0.694222 11.189C0.726796 11.237 0.768578 11.278 0.817141 11.3097C0.865703 11.3413 0.920077 11.363 0.977103 11.3735C1.03413 11.384 1.09267 11.383 1.14932 11.3707C1.20596 11.3583 1.25959 11.3349 1.30709 11.3016C1.35458 11.2683 1.39499 11.226 1.42597 11.177C1.82321 10.566 2.36677 10.0639 3.00731 9.71638C3.64784 9.36882 4.36505 9.18678 5.09381 9.18678C5.82256 9.18678 6.53977 9.36882 7.1803 9.71638C7.82084 10.0639 8.36441 10.566 8.76165 11.177C8.82581 11.2723 8.92494 11.3386 9.03758 11.3615C9.15023 11.3844 9.26736 11.362 9.36363 11.2992C9.45991 11.2364 9.52761 11.1382 9.55209 11.0259C9.57657 10.9136 9.55586 10.7962 9.49445 10.699C8.87862 9.75108 7.97279 9.02769 6.91214 8.63677ZM2.68759 5.9068C2.68759 5.4309 2.82871 4.96568 3.09311 4.56998C3.35751 4.17428 3.73331 3.86587 4.17299 3.68375C4.61267 3.50163 5.09648 3.45398 5.56324 3.54682C6.03 3.63967 6.45874 3.86884 6.79526 4.20535C7.13177 4.54187 7.36094 4.97061 7.45379 5.43737C7.54663 5.90413 7.49898 6.38794 7.31686 6.82762C7.13474 7.2673 6.82633 7.6431 6.43063 7.9075C6.03493 8.1719 5.56971 8.31302 5.09381 8.31302C4.45586 8.3123 3.84425 8.05855 3.39315 7.60746C2.94206 7.15636 2.68831 6.54475 2.68759 5.9068ZM14.1795 11.3044C14.0823 11.3678 13.9639 11.3899 13.8504 11.366C13.7369 11.3421 13.6375 11.2741 13.5741 11.177C13.1773 10.5656 12.6338 10.0634 11.9932 9.71594C11.3525 9.36853 10.635 9.18703 9.90624 9.18801C9.79021 9.18801 9.67893 9.14192 9.59688 9.05987C9.51484 8.97782 9.46875 8.86654 9.46875 8.75051C9.46875 8.63448 9.51484 8.5232 9.59688 8.44116C9.67893 8.35911 9.79021 8.31302 9.90624 8.31302C10.2606 8.31269 10.6105 8.23409 10.931 8.08285C11.2514 7.93161 11.5345 7.71146 11.76 7.43813C11.9855 7.16479 12.1479 6.84503 12.2355 6.50167C12.3231 6.15832 12.3338 5.79985 12.2668 5.45189C12.1998 5.10393 12.0568 4.77506 11.848 4.48877C11.6391 4.20249 11.3696 3.96587 11.0588 3.7958C10.7479 3.62574 10.4033 3.52644 10.0496 3.505C9.69588 3.48355 9.34181 3.5405 9.01266 3.67176C8.95899 3.69496 8.90122 3.70716 8.84276 3.70766C8.78429 3.70815 8.72632 3.69692 8.67227 3.67463C8.61822 3.65234 8.56919 3.61945 8.52807 3.57789C8.48694 3.53633 8.45457 3.48694 8.43286 3.43266C8.41114 3.37838 8.40053 3.32029 8.40165 3.26183C8.40276 3.20338 8.41558 3.14574 8.43935 3.09232C8.46312 3.03891 8.49735 2.9908 8.54003 2.95083C8.5827 2.91087 8.63296 2.87987 8.68782 2.85966C9.44111 2.55924 10.279 2.54843 11.0398 2.82931C11.8005 3.1102 12.4304 3.66287 12.8077 4.38072C13.185 5.09858 13.2832 5.93074 13.0832 6.71667C12.8831 7.5026 12.3992 8.18662 11.7246 8.63677C12.7852 9.02769 13.6911 9.75108 14.3069 10.699C14.3703 10.7962 14.3924 10.9146 14.3685 11.0281C14.3446 11.1416 14.2766 11.241 14.1795 11.3044Z" fill="currentColor"></path>
                                  </svg>
                                  179 <span data-v-e216624f class="text-contentTertiary">/</span> 300
                                </div>
                                <div data-v-e216624f class="mt-12px text-12px font-400 text-contentTertiary">ROI</div>
                                <div data-v-e216624f class="font-700 text-contentTradeBuy mt-2px">
                                  <span data-v-4b336f5e data-v-e216624f class="text-contentTradeBuy" dir="ltr">+985.84%</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div style="display: none;">
                      <div data-v-25920e85 class="flex flex-row gap-4px min-h-380px max-h-504px bg-inherit">
                        <div data-v-25920e85 class="p-12px w-276px overflow-y-auto">
                          <a data-v-097919ff data-v-25920e85 class="text-primaryText menu-item" href="/asia/trading-bot" target="_self"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/f823e89871e1ead67ef013937c23e751.png" alt="Overview" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Overview</div>
                              </div>
                              <div data-v-097919ff class="desc">Bringing together the most comprehensive top bots</div>
                            </div>
                          </a>
                          <div data-v-25920e85 class="px-12px">
                            <div data-v-25920e85 class="my-20px text-16px font-600">Create</div>
                          </div>
                          <div data-v-25920e85 class="flex flex-col gap-8px mt-10px">
                            <a data-v-097919ff data-v-25920e85 class="text-primaryText menu-item" href="/asia/trading-bot/spot/BTCUSDT" target="_blank"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/b645faa4380faea1eb411fbde0a95cee.png" alt="Spot grid" loading="lazy" decoding="async" width="24" height="24">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Spot grid</div>
                                </div>
                                <div data-v-097919ff class="desc">Automate trades with grid bots</div>
                              </div>
                            </a><a data-v-097919ff data-v-25920e85 class="text-primaryText menu-item" href="/asia/trading-bot/futures/BTCUSDT" target="_blank"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/56871a51c9132aa0a84bb0cdb884190f.png" alt="Futures grid" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Futures grid</div>
                              </div>
                              <div data-v-097919ff class="desc">Amplify grid bot trades with leverage</div>
                            </div>
                          </a><a data-v-097919ff data-v-25920e85 class="text-primaryText menu-item" href="/asia/trading-bot/spot/moon/BTCUSDT" target="_self"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/f7b7512fb56a7e7845b2b4da0a9dd6cf.png" alt="Spot position grid" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Spot position grid</div>
                              </div>
                              <div data-v-097919ff class="desc">Buy low and sell high on volatile markets.</div>
                            </div>
                          </a><a data-v-097919ff data-v-25920e85 class="text-primaryText menu-item" href="/asia/trading-bot/futures/moon/BTCUSDT" target="_self"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/ba2da9f4bb0281552631d25d6b12c8a7.png" alt="Futures position grid" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Futures position grid</div>
                              </div>
                              <div data-v-097919ff class="desc">Place positions at regular intervals on oscillating markets.</div>
                            </div>
                          </a><a data-v-097919ff data-v-25920e85 class="text-primaryText menu-item" href="/asia/trading-bot/spot/timing/BTCUSDT" target="_blank"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/c86c9a362db8b6ff993b476f3e5c8081.png" alt="Spot auto-invest+" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Spot auto-invest+</div>
                              </div>
                              <div data-v-097919ff class="desc">Regularly invest without timing the market</div>
                            </div>
                          </a><a data-v-097919ff data-v-25920e85 class="text-primaryText menu-item" href="/asia/trading-bot/spot/hoard/BTCUSDT" target="_blank"><img data-v-097919ff class="menu-icon" src="https://img.bitgetimg.com/multiLang/web/8f2ce378f67c520abe67381a680efeb2.png" alt="Smart Portfolio" loading="lazy" decoding="async" width="24" height="24">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Smart Portfolio</div>
                              </div>
                              <div data-v-097919ff class="desc">Smart dynamic rebalancing and cyclic arbitrage</div>
                            </div>
                          </a></div>
                        </div>
                      </div>
                    </div>
                    <div style="display: none;">
                      <div data-v-550f7d44 class="flex flex-row gap-4px min-h-338px max-h-504px bg-inherit" style="height: 510px; max-height: 504px;">
                        <div data-v-550f7d44 class="flex flex-row mt-4px h-[calc(100%-8px)] overflow-x-auto">
                          <div data-v-550f7d44 class="px-12px pt-8px h-auto">
                            <div data-v-550f7d44 class="px-16px h-48px leading-48px text-16px font-600">Earn products</div>
                            <div data-v-550f7d44 class="flex flex-col flex-wrap gap-8px pb-8px">
                              <a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning?source1=earn&amp;source2=earn_overview" target="_self" style="height: 78px;">
                                <div data-v-097919ff class="flex-1">
                                  <div data-v-097919ff class="title">
                                    <div data-v-097919ff class="line-clamp-2">Overview</div>
                                  </div>
                                  <div data-v-097919ff class="desc">Comprehensive investment and financial management</div>
                                </div>
                              </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning/savings?source1=earn&amp;source2=savings" target="_self" style="height: 78px;">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Savings</div>
                                </div>
                                <div data-v-097919ff class="desc">Earn daily profits with idle tokens</div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning/staking" target="_self" style="height: 78px;">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Staking</div>
                                </div>
                                <div data-v-097919ff class="desc">Guaranteed earnings in both bear and bull markets</div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning/loan" target="_self" style="height: 78px;">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Crypto Loans</div>
                                </div>
                                <div data-v-097919ff class="desc">Borrow crypto quickly and easily</div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning/bgb-staking" target="_self" style="height: 78px;">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">BGB Staking</div>
                                </div>
                                <div data-v-097919ff class="desc">Stake BGB for zero-fee withdrawals</div>
                              </div>
                            </a></div>
                          </div>
                          <div data-v-550f7d44 class="px-12px pt-8px h-auto">
                            <div data-v-550f7d44 class="px-16px h-48px leading-48px text-16px font-600"></div>
                            <div data-v-550f7d44 class="flex flex-col flex-wrap gap-8px pb-8px">
                              <a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning/shark-fin" target="_self" style="height: 78px;">
                                <div data-v-097919ff class="flex-1">
                                  <div data-v-097919ff class="title">
                                    <div data-v-097919ff class="line-clamp-2">Shark Fin</div>
                                  </div>
                                  <div data-v-097919ff class="desc">Principal-guaranteed high yields</div>
                                </div>
                              </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning/smart-trend" target="_self" style="height: 78px;">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Smart Trend</div>
                                </div>
                                <div data-v-097919ff class="desc">Time the market and enjoy incredible yields</div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning/dual-investment" target="_self" style="height: 78px;">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Dual Investment</div>
                                </div>
                                <div data-v-097919ff class="desc">Buy low and sell high — profit no matter the market direction</div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning/wealth-management" target="_self" style="height: 78px;">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Wealth Management</div>
                                </div>
                                <div data-v-097919ff class="desc">Grow your wealth with our top-tier asset management team</div>
                              </div>
                            </a></div>
                          </div>
                          <div data-v-550f7d44 class="px-12px pt-8px h-auto">
                            <div data-v-550f7d44 class="px-16px h-48px leading-48px text-16px font-600">Promotions</div>
                            <div data-v-550f7d44 class="flex flex-col flex-wrap gap-8px pb-8px">
                              <a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/BGB/intro" target="_self" style="height: 78px;">
                                <div data-v-097919ff class="flex-1">
                                  <div data-v-097919ff class="title">
                                    <div data-v-097919ff class="line-clamp-2">BGB Zone</div>
                                  </div>
                                  <div data-v-097919ff class="desc">All BGB rewards in one place</div>
                                </div>
                              </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning/auto-invest" target="_blank" style="height: 78px;">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Spot auto-invest+</div>
                                </div>
                                <div data-v-097919ff class="desc">Automatically subscribe to auto-invest Earn products and earn for additional profits.</div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/launchpool" target="_self" style="height: 78px;">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Launchpool</div>
                                </div>
                                <div data-v-097919ff class="desc">Stake and mine hot and new tokens</div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/poolx" target="_blank" style="height: 78px;">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">PoolX</div>
                                </div>
                                <div data-v-097919ff class="desc">Stake for new tokens. Always on. Always earning.</div>
                              </div>
                            </a></div>
                          </div>
                        </div>
                        <div data-v-550f7d44 class="relative py-40px px-34px w-260px text-center bg-bgSecondary">
                          <div class="mt-20px text-20px font-700">Crypto loans!</div>
                          <div class="mt-8px font-500 text-12px !leading-18px">Flexible borrowing</div>
                          <button aria-disabled="false" type="button" class="mi-button mi-button--chunky is-round absolute bottom-40px left-[calc(50%-81px)] h-40px w-162px"><!--v-if--><span class>Details <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" class="ml-8px"><g clip-path="url(#clip0_1051_26544)"><path d="M10.7807 7.33312L7.20468 3.75712L8.14735 2.81445L13.3327 7.99979L8.14735 13.1851L7.20468 12.2425L10.7807 8.66645H2.66602V7.33312H10.7807Z" fill="currentColor"></path></g><defs><clipPath id="clip0_1051_26544"><rect width="16" height="16" fill="white"></rect></clipPath></defs></svg></span><!--v-if-->
                          </button>
                        </div>
                      </div>
                    </div>
                    <div style="display: none;">
                      <div data-v-3d905981 class="flex bg-inherit max-h-504px">
                        <div data-v-3d905981 class="relative p-12px w-276px overflow-y-auto">
                          <div data-v-3d905981 class="flex gap-12px flex-col">
                            <a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="https://web3.bitget.com/en?source=bitget" target="_blank" data-testid="menu_web3_wallet_title">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Bitget Wallet</div>
                                </div>
                                <div data-v-097919ff class="desc">Decentralized Web3 wallet for safer crypto transactions</div>
                              </div>
                            </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="https://web3.bitget.com/en/nft?source=bitget" target="_blank" data-testid="menu_web3_nft_title">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Bitget NFT</div>
                              </div>
                              <div data-v-097919ff class="desc">Simplified batch listing and purchasing NFTs with any tokens</div>
                            </div>
                          </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="https://web3.bitget.com/en/dapp?source=bitget" target="_blank" data-testid="menu_web3_dapp_title">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">DApp</div>
                              </div>
                              <div data-v-097919ff class="desc">Engage with the massive trending DApps</div>
                            </div>
                          </a></div>
                        </div>
                      </div>
                    </div>
                    <div style="display: none;">
                      <div data-v-3d905981 class="flex bg-inherit max-h-504px">
                        <div data-v-3d905981 class="relative p-12px w-276px overflow-y-auto">
                          <div data-v-3d905981 class="flex gap-12px flex-col">
                            <a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/pre-market" target="_blank" data-testid>
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Pre-Market</div>
                                </div>
                                <div data-v-097919ff class="desc">Grab coins before they're listed</div>
                              </div>
                            </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/events/launchpad" target="_blank" data-testid="menu_launchpad">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Launchpad</div>
                              </div>
                              <div data-v-097919ff class="desc">Get ahead with hot and new tokens</div>
                            </div>
                          </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/events/launchpool" target="_blank" data-testid="menu_launchpool">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Launchpool</div>
                              </div>
                              <div data-v-097919ff class="desc">Stake and mine hot and new tokens</div>
                            </div>
                          </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/events/poolx" target="_blank" data-testid>
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">PoolX</div>
                              </div>
                              <div data-v-097919ff class="desc">Stake to win token airdrops</div>
                            </div>
                          </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/events/candy-bomb" target="_blank" data-testid="menu_candybomb">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">CandyBomb</div>
                              </div>
                              <div data-v-097919ff class="desc">Get ready for an explosion of rewards</div>
                            </div>
                          </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/events/deposit" target="_blank" data-testid="menu_events_deposit">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Deposit to List</div>
                              </div>
                              <div data-v-097919ff class="desc">Deposit and list tokens easily</div>
                            </div>
                          </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/events/tap-to-earn-more" target="_blank" data-testid>
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Tap to Earn More</div>
                              </div>
                              <div data-v-097919ff class="desc">Tap "Boost" daily for a +5% deposit boost</div>
                            </div>
                          </a></div>
                        </div>
                      </div>
                    </div>
                    <div style="display: none;">
                      <div data-v-3d905981 class="flex bg-inherit max-h-504px">
                        <div data-v-3d905981 class="relative p-12px w-276px overflow-y-auto">
                          <div data-v-3d905981 class="flex gap-12px flex-col"></div>
                          <div data-v-3d905981 class="flex flex-col items-center justify-center py-20px">
                            <svg width="88" height="86" viewBox="0 0 88 86" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M61.5 41.1198C63.7701 41.0244 65.9032 41.086 67.8562 41.2995C71.0644 41.6503 73.7715 42.4093 75.7997 43.543C77.8261 44.6757 79.1568 46.171 79.6602 47.9934C80.1636 49.8159 79.8056 51.8419 78.6787 53.9656C77.5508 56.091 75.6621 58.2945 73.1446 60.4446C72.7761 60.7593 72.3944 61.0727 72 61.3843M28.2887 51.5447C26.3172 52.7849 24.543 54.0786 23.0003 55.3962C20.4828 57.5464 18.5941 59.7498 17.4662 61.8753C16.3393 63.999 15.9813 66.025 16.4847 67.8474C16.9881 69.6698 18.3188 71.1651 20.3452 72.2978C22.3734 73.4315 25.0805 74.1906 28.2887 74.5413C34.7041 75.2427 43.0626 74.3048 51.8366 71.5474C52.5668 71.3179 53.2882 71.0796 54 70.8328" stroke="var(--color-disabled-text)" stroke-width="0.622027"></path>
                              <path d="M64.8571 55.5L56.843 23.4049C56.2182 20.9025 53.699 19.4471 51.2192 20.1559L26.9782 27.084C24.4981 27.7928 22.9987 30.3972 23.631 32.8977L34.1662 74.5583C34.1832 74.5586 34.2013 74.5588 34.2203 74.559C34.4057 74.5612 34.684 74.5612 35.0526 74.552C35.7896 74.5338 36.8873 74.4793 38.323 74.334C41.1942 74.0435 45.4175 73.3897 50.8111 71.936C51.8964 71.6435 52.9632 71.3167 54 70.9681" stroke="var(--color-disabled-text)" stroke-width="0.622027"></path>
                              <path d="M52.7654 32.3288L31.1859 38.4962C30.82 38.6008 30.5986 38.9847 30.6913 39.3538L31.1243 41.0774C31.217 41.4464 31.5888 41.6608 31.9546 41.5563L53.5341 35.3888C53.9 35.2842 54.1214 34.9003 54.0287 34.5313L53.5957 32.8076C53.503 32.4386 53.1313 32.2242 52.7654 32.3288Z" stroke="var(--color-disabled-text)" stroke-width="0.622027"></path>
                              <path d="M55.0701 41.1745L33.4906 47.3419C33.1247 47.4465 32.9033 47.8304 32.996 48.1995L33.429 49.9231C33.5217 50.2921 33.8934 50.5065 34.2593 50.402L55.8388 44.2345C56.2047 44.13 56.4261 43.746 56.3334 43.377L55.9004 41.6534C55.8077 41.2843 55.436 41.0699 55.0701 41.1745Z" stroke="var(--color-disabled-text)" stroke-width="0.622027"></path>
                              <path d="M80.0897 16.3879C80.5844 17.5588 80.3321 18.9478 79.4635 20.2646C78.5961 21.5796 77.1282 22.7953 75.2595 23.5846C73.3908 24.374 71.4959 24.5789 69.9484 24.2839C68.3988 23.9886 67.2272 23.2011 66.7325 22.0301C66.2379 20.8592 66.4902 19.4702 67.3588 18.1534C68.2262 16.8384 69.6941 15.6227 71.5628 14.8334C73.4315 14.044 75.3264 13.8391 76.8739 14.1341C78.4235 14.4294 79.5951 15.2169 80.0897 16.3879Z" stroke="var(--color-disabled-text)" stroke-width="0.5"></path>
                              <path d="M77.9445 18.3791C78.3743 19.3966 77.073 20.9183 75.038 21.7779" stroke="var(--color-disabled-text)" stroke-width="0.5"></path>
                              <path fill-rule="evenodd" clip-rule="evenodd" d="M65.0429 18.6722C63.9146 16.0012 66.0932 12.5293 69.9089 10.9175C73.7246 9.30573 77.7324 10.1644 78.8607 12.8353L80.2226 16.0595L80.2141 16.0631C79.0048 13.7023 75.1652 13.0394 71.4654 14.6023C67.7655 16.1651 65.564 19.3799 66.4133 21.8927L66.4048 21.8963L65.0429 18.6722Z" fill="var(--color-disabled-text)"></path>
                              <path d="M57.5074 56.3595C58.8612 55.0057 60.9317 54.5815 63.224 55.04C65.5143 55.498 67.9952 56.8342 70.1121 58.9512C72.2291 61.0681 73.5653 63.5491 74.0234 65.8393C74.4818 68.1316 74.0576 70.2021 72.7038 71.5559C71.35 72.9098 69.2795 73.3339 66.9872 72.8755C64.697 72.4174 62.216 71.0812 60.0991 68.9643C57.9821 66.8473 56.6459 64.3664 56.1878 62.0761C55.7294 59.7838 56.1536 57.7133 57.5074 56.3595Z" stroke="var(--color-disabled-text)" stroke-width="0.5"></path>
                              <path d="M61.4764 58.2557C62.6215 57.1106 65.4062 58.0389 67.6964 60.329" stroke="var(--color-disabled-text)" stroke-width="0.5"></path>
                              <path fill-rule="evenodd" clip-rule="evenodd" d="M68.9933 75.62C65.9875 78.6258 60.0698 77.5815 55.7758 73.2875C51.4818 68.9935 50.4375 63.0759 53.4433 60.0701L57.0716 56.4417L57.0811 56.4512C54.5409 59.3959 55.7581 64.9774 59.922 69.1413C64.0859 73.3052 69.6674 74.5224 72.6121 71.9822L72.6216 71.9917L68.9933 75.62Z" fill="var(--color-disabled-text)"></path>
                              <path d="M12.7754 26.537C12.1076 26.9225 11.2219 26.8589 10.2994 26.3713C9.38049 25.8857 8.46155 24.9944 7.77499 23.8053C7.08843 22.6161 6.77608 21.3747 6.81495 20.336C6.85397 19.2934 7.24171 18.4945 7.90944 18.109C8.57718 17.7234 9.46291 17.7871 10.3854 18.2746C11.3043 18.7603 12.2233 19.6515 12.9098 20.8407C13.5964 22.0298 13.9087 23.2713 13.8699 24.3099C13.8308 25.3526 13.4431 26.1515 12.7754 26.537Z" stroke="var(--color-disabled-text)" stroke-width="0.5"></path>
                              <path d="M11.4775 25.3629C10.8625 25.718 9.75317 24.9479 8.99971 23.6429" stroke="var(--color-disabled-text)" stroke-width="0.5"></path>
                              <path fill-rule="evenodd" clip-rule="evenodd" d="M9.87181 16.6877C11.4862 15.7556 13.9402 16.9836 15.3529 19.4305C16.7656 21.8774 16.6021 24.6166 14.9877 25.5487L13.039 26.6738L13.0357 26.6681C14.4416 25.7022 14.495 23.0888 13.1253 20.7163C11.7555 18.3439 9.46558 17.0835 7.9261 17.818L7.92307 17.8128L9.87181 16.6877Z" fill="var(--color-disabled-text)"></path>
                            </svg>
                            <span class="mt-16px text-thirdText">No data</span></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <i class="absolute -top-6px w-12px h-12px rounded-[3px_0_0_0] rotate-45deg light:shadow-popover light:border-1px light:border-line light:bg-bg dark:bg-cardBg" style="opacity: 0;"></i>
                </div>
              </div>
              <div data-v-7c2db744 class="micro-action flex items-center gap-8px ml-auto h-full">
                <!--登录注册链接-->
                <div v-if="!isLogin" class="flex items-center gap-20px whitespace-nowrap pr-8px">
                  <div data-v-d8e0da7c class="relative inline-flex items-center h-full login-popover-move">
                    <div data-v-d8e0da7c>
                      <a class="text-primaryText text-16px cursor-pointer leading-40px text-center" href="/login" target="_self" rel="nofollow">Log in</a>
                    </div>
                    <div data-v-d8e0da7c class="popover absolute z-1000 opacity-0 invisible left" lt-md="fixed left-0" style="top: calc(100% + 0px); padding-top: 0px;">
                      <i data-v-d8e0da7c class="absolute -top-6px !right-20px w-12px h-12px rounded-[3px_0_0_0] rotate-45deg transition-opacity light:shadow-popover light:border-1px light:border-line light:bg-bg dark:bg-cardBg !border-b-0px !border-r-0px" style="display: none;"></i>
                    </div>
                  </div>
                  <a class="text-primaryText inline-flex items-center justify-center px-18px h-40px min-w-87px text-16px rounded-20px bg-contentPrimary cursor-pointer !text-contentInversePrimary" href="/register" target="_self" rel="nofollow">Sign up</a>
                </div>

                <!--搜索-->
                <div data-v-d8e0da7c data-v-527d4eb3 class="relative inline-flex items-center h-full popover-search">
                  <div data-v-d8e0da7c>
                    <div data-v-527d4eb3 class="inline-flex items-center justify-center w-40px h-40px rounded-50% hover:bg-bgSecondary text-24px cursor-pointer undefined">
                      <svg data-v-527d4eb3 width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g id="Search">
                          <path id="Vector" d="M11 19C15.4183 19 19 15.4183 19 11C19 6.58172 15.4183 3 11 3C6.58172 3 3 6.58172 3 11C3 15.4183 6.58172 19 11 19Z" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"></path>
                          <path id="Vector_2" d="M21.0343 22.1655C21.3467 22.4779 21.8533 22.4779 22.1657 22.1655C22.4781 21.8531 22.4781 21.3465 22.1657 21.0341L21.0343 22.1655ZM22.1657 21.0341L17.3657 16.2341L16.2343 17.3655L21.0343 22.1655L22.1657 21.0341Z" fill="currentColor"></path>
                        </g>
                      </svg>
                    </div>
                  </div>
                  <div data-v-d8e0da7c class="popover absolute z-1000 opacity-0 invisible left" lt-md="fixed left-0" style="top: calc(100% + 0px); padding-top: 0px;">
                    <div data-v-d8e0da7c class="popover-main rounded-12px overflow-y-auto light:shadow light:border-1px light:border-line light:bg-bg dark:bg-cardBg" style="display: none;"></div>
                    <i data-v-d8e0da7c class="absolute -top-6px !right-20px w-12px h-12px rounded-[3px_0_0_0] rotate-45deg transition-opacity light:shadow-popover light:border-1px light:border-line light:bg-bg dark:bg-cardBg !border-b-0px !border-r-0px" style="display: none;"></i>
                  </div>
                </div>
                <!--提示-->
                <div data-v-d8e0da7c data-v-27c3d3ee class="relative inline-flex items-center h-full">
                  <div data-v-d8e0da7c>
                    <a data-v-27c3d3ee class="text-primaryText relative inline-flex items-center h-full" href="/asia/inmail" target="_self">
                      <div data-v-27c3d3ee class="micro-inmail-icon flex items-center justify-center w-40px h-40px rounded-50% hover:bg-bgSecondary">
                        <svg data-v-27c3d3ee width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <g id="Icon24">
                            <g id="icon-bell">
                              <path id="Rectangle 34625611" d="M3.55693 16.6646L2 19H22L20.4431 16.6646C20.1542 16.2312 20 15.7221 20 15.2012V11C20 6.58172 16.4183 3 12 3C7.58172 3 4 6.58172 4 11V15.2012C4 15.7221 3.84583 16.2312 3.55693 16.6646Z" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"></path>
                              <path id="Rectangle 34625614" d="M14 22H10" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"></path>
                              <path id="Rectangle 34625613" d="M12 1L12 3" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"></path>
                            </g>
                          </g>
                        </svg>
                      </div>
                    </a></div>
                  <div data-v-d8e0da7c class="popover absolute z-1000 opacity-0 invisible left" lt-md="fixed left-0" style="top: calc(100% - 22px); padding-top: 22px;">
                    <i data-v-d8e0da7c class="absolute -top-6px !right-20px w-12px h-12px rounded-[3px_0_0_0] rotate-45deg transition-opacity light:shadow-popover light:border-1px light:border-line light:bg-bg dark:bg-cardBg !border-b-0px !border-r-0px" style="display: none;"></i>
                  </div>
                </div>
                <div data-v-d8e0da7c class="relative inline-flex items-center h-full">
                  <div data-v-d8e0da7c>
                    <a class="text-primaryText relative inline-flex items-center h-full" href="https://www.bitget.com/asia/download?openApp=1" target="_self">
                      <div class="flex items-center justify-center w-40px h-40px rounded-50% hover:bg-bgSecondary">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M21 14.25V19.5C21 19.8978 20.842 20.2794 20.5607 20.5607C20.2794 20.842 19.8978 21 19.5 21H4.5C4.10218 21 3.72064 20.842 3.43934 20.5607C3.15804 20.2794 3 19.8978 3 19.5V14.25C3 14.0511 3.07902 13.8603 3.21967 13.7197C3.36032 13.579 3.55109 13.5 3.75 13.5C3.94891 13.5 4.13968 13.579 4.28033 13.7197C4.42098 13.8603 4.5 14.0511 4.5 14.25V19.5H19.5V14.25C19.5 14.0511 19.579 13.8603 19.7197 13.7197C19.8603 13.579 20.0511 13.5 20.25 13.5C20.4489 13.5 20.6397 13.579 20.7803 13.7197C20.921 13.8603 21 14.0511 21 14.25ZM11.4694 14.7806C11.539 14.8504 11.6217 14.9057 11.7128 14.9434C11.8038 14.9812 11.9014 15.0006 12 15.0006C12.0986 15.0006 12.1962 14.9812 12.2872 14.9434C12.3783 14.9057 12.461 14.8504 12.5306 14.7806L16.2806 11.0306C16.3503 10.9609 16.4056 10.8782 16.4433 10.7872C16.481 10.6961 16.5004 10.5985 16.5004 10.5C16.5004 10.4015 16.481 10.3039 16.4433 10.2128C16.4056 10.1218 16.3503 10.0391 16.2806 9.96937C16.2109 9.89969 16.1282 9.84442 16.0372 9.8067C15.9461 9.76899 15.8485 9.74958 15.75 9.74958C15.6515 9.74958 15.5539 9.76899 15.4628 9.8067C15.3718 9.84442 15.2891 9.89969 15.2194 9.96937L12.75 12.4397V3.75C12.75 3.55109 12.671 3.36032 12.5303 3.21967C12.3897 3.07902 12.1989 3 12 3C11.8011 3 11.6103 3.07902 11.4697 3.21967C11.329 3.36032 11.25 3.55109 11.25 3.75V12.4397L8.78063 9.96937C8.63989 9.82864 8.44902 9.74958 8.25 9.74958C8.05098 9.74958 7.86011 9.82864 7.71937 9.96937C7.57864 10.1101 7.49958 10.301 7.49958 10.5C7.49958 10.699 7.57864 10.8899 7.71937 11.0306L11.4694 14.7806Z" fill="currentColor"></path>
                        </svg>
                      </div>
                    </a>
                  </div>
                  <div data-v-d8e0da7c class="popover absolute z-1000 opacity-0 invisible left" lt-md="fixed left-0" style="top: calc(100% - 22px); padding-top: 22px;">
                    <i data-v-d8e0da7c class="absolute -top-6px !right-20px w-12px h-12px rounded-[3px_0_0_0] rotate-45deg transition-opacity light:shadow-popover light:border-1px light:border-line light:bg-bg dark:bg-cardBg !border-b-0px !border-r-0px" style="display: none;"></i>
                  </div>
                </div>

                <div class="flex items-center justify-center w-40px h-40px rounded-50% cursor-pointer hover:bg-bgSecondary">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="9.35" stroke="currentColor" stroke-width="1.3"></circle>
                    <path d="M21.35 12C21.35 13.0019 20.5209 14.0839 18.7804 14.9542C17.0787 15.805 14.6824 16.35 12 16.35C9.31761 16.35 6.92129 15.805 5.21962 14.9542C3.47907 14.0839 2.65 13.0019 2.65 12C2.65 10.9981 3.47907 9.91612 5.21962 9.04584C6.92129 8.19501 9.31761 7.65 12 7.65C14.6824 7.65 17.0787 8.19501 18.7804 9.04584C20.5209 9.91612 21.35 10.9981 21.35 12Z" stroke="currentColor" stroke-width="1.3"></path>
                    <path d="M12 2.65C13.0019 2.65 14.0839 3.47907 14.9542 5.21962C15.805 6.92129 16.35 9.3176 16.35 12C16.35 14.6824 15.805 17.0787 14.9542 18.7804C14.0839 20.5209 13.0019 21.35 12 21.35C10.9981 21.35 9.91612 20.5209 9.04584 18.7804C8.19501 17.0787 7.65 14.6824 7.65 12C7.65 9.3176 8.19501 6.92129 9.04584 5.21962C9.91612 3.47907 10.9981 2.65 12 2.65Z" stroke="currentColor" stroke-width="1.3"></path>
                  </svg>
                </div>

                <!--个人中心链接-->
                <div class="relative inline-flex items-center h-full">
                  <div data-v-d8e0da7c>
                    <div class="flex items-center justify-center w-40px h-40px rounded-50% cursor-pointer hover:bg-bgSecondary">
                      <div data-v-ada517e7 class="micro-bit-avatar" style="width: 32px; height: 32px;" data-testid="MicroUserIcon">
                        <span data-v-ada517e7 class="mi-avatar mi-avatar--circle" style="--mi-avatar-size: 32px;"><svg data-v-ada517e7 width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" class="icon-item w-20px h-20px min-w-20px"><g id="Frame 1533210730"><g clip-path="url(#clip0_3447_5316)"><rect width="32" height="32" rx="16" fill="#DDDDDD"></rect><path id="Vector 4611" d="M11.1585 16.2486C11.2558 16.739 12.5284 18.0159 12.5284 18.0159C12.5284 18.0159 10.9591 18.8166 10.1769 17.4425C9.39473 16.0685 11.0613 15.7581 11.1585 16.2486Z" fill="#3E2D32"></path><path id="Vector 4612" d="M20.8844 16.2486C20.7872 16.739 19.5145 18.0159 19.5145 18.0159C19.5145 18.0159 21.0838 18.8166 21.866 17.4425C22.6482 16.0685 20.9817 15.7581 20.8844 16.2486Z" fill="#3E2D32"></path><rect id="Rectangle 34626493" x="13" y="20" width="6" height="4" fill="#F382AB"></rect><circle id="Ellipse 7375" cx="19.5" cy="10.5" r="3.5" fill="#3E2D32"></circle><circle id="Ellipse 7376" cx="12.5" cy="10.5" r="3.5" fill="#3E2D32"></circle><ellipse id="Ellipse 7371" cx="16" cy="40" rx="23" ry="17" fill="#03AAC7"></ellipse><g id="Mask group"><mask id="mask0_3447_5316" style="mask-type:alpha;" maskUnits="userSpaceOnUse" x="-7" y="23" width="46" height="34"><ellipse id="Ellipse 7373" cx="16" cy="40" rx="23" ry="17" fill="#03AAC7"></ellipse></mask><g mask="url(#mask0_3447_5316)"><ellipse id="Ellipse 7372" cx="16" cy="22.5" rx="6" ry="5.5" fill="#F382AB"></ellipse></g></g><rect id="Rectangle 34626491" x="9" y="13" width="14" height="4" rx="2" fill="#F382AB"></rect><rect id="Rectangle 34626490" x="11" y="6" width="10" height="15" rx="5" fill="#FF9DC0"></rect><path id="Rectangle 34626492" d="M10 8.26667C10 5.91025 11.78 4 13.9757 4H18.594C20.5153 4 22 5.67147 22 7.73333C22 9.7952 20.5153 12 18.594 12H10V8.26667Z" fill="#3E2D32"></path><path id="Vector 4610" d="M21.1157 7.5C21.6157 7.5 23.1157 6.5 23.1157 6.5C23.1157 6.5 23.5959 8.19507 22.0959 8.69507C20.5959 9.19507 20.6157 7.5 21.1157 7.5Z" fill="#3E2D32"></path></g></g><defs><clipPath id="clip0_3447_5316"><rect width="32" height="32" rx="16" fill="white"></rect></clipPath></defs></svg></span><!---->
                      </div>
                    </div>
                  </div>
                  <div data-v-d8e0da7c class="popover absolute z-1000 opacity-0 invisible left" lt-md="fixed left-0" style="top: calc(100% - 22px); padding-top: 22px;">
                    <i data-v-d8e0da7c class="absolute -top-6px !right-20px w-12px h-12px rounded-[3px_0_0_0] rotate-45deg transition-opacity light:shadow-popover light:border-1px light:border-line light:bg-bg dark:bg-cardBg !border-b-0px !border-r-0px" style="display: none;"></i>
                  </div>
                </div>

              </div>
            </div>

            <div data-v-7c2db744 class="bg"></div>
            <div data-v-5f651626 data-v-7c2db744 id="MicroMenu" class="micro-menu flex items-center relative h-full min-w-[fit-content] lt-lg:!hidden" style="display: inline-flex; position: absolute; visibility: hidden;">
              <div data-v-5f651626 class="group-menu mr-4px" data-menu-id="96" style="display: inline-flex;">
                <svg data-v-5f651626 width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9.46625 3.45227H4.96629C4.56847 3.45227 4.18695 3.6103 3.90564 3.89161C3.62434 4.17291 3.46631 4.55443 3.46631 4.95226V9.45221C3.46631 9.85003 3.62434 10.2316 3.90564 10.5129C4.18695 10.7942 4.56847 10.9522 4.96629 10.9522H9.46625C9.86407 10.9522 10.2456 10.7942 10.5269 10.5129C10.8082 10.2316 10.9662 9.85003 10.9662 9.45221V4.95226C10.9662 4.55443 10.8082 4.17291 10.5269 3.89161C10.2456 3.6103 9.86407 3.45227 9.46625 3.45227ZM9.46625 9.45221H4.96629V4.95226H9.46625V9.45221ZM19.0103 3.45227H14.5103C14.1125 3.45227 13.731 3.6103 13.4497 3.89161C13.1684 4.17291 13.0103 4.55443 13.0103 4.95226V9.45221C13.0103 9.85003 13.1684 10.2316 13.4497 10.5129C13.731 10.7942 14.1125 10.9522 14.5103 10.9522H19.0103C19.4081 10.9522 19.7896 10.7942 20.0709 10.5129C20.3522 10.2316 20.5103 9.85003 20.5103 9.45221V4.95226C20.5103 4.55443 20.3522 4.17291 20.0709 3.89161C19.7896 3.6103 19.4081 3.45227 19.0103 3.45227ZM19.0103 9.45221H14.5103V4.95226H19.0103V9.45221ZM9.46625 13.0689H4.96629C4.56847 13.0689 4.18695 13.2269 3.90564 13.5082C3.62434 13.7895 3.46631 14.171 3.46631 14.5689V19.0688C3.46631 19.4666 3.62434 19.8482 3.90564 20.1295C4.18695 20.4108 4.56847 20.5688 4.96629 20.5688H9.46625C9.86407 20.5688 10.2456 20.4108 10.5269 20.1295C10.8082 19.8482 10.9662 19.4666 10.9662 19.0688V14.5689C10.9662 14.171 10.8082 13.7895 10.5269 13.5082C10.2456 13.2269 9.86407 13.0689 9.46625 13.0689ZM9.46625 19.0688H4.96629V14.5689H9.46625V19.0688Z" fill="currentColor"></path>
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M21.2864 15.9465L18.1045 12.7646C17.8232 12.4833 17.4416 12.3252 17.0438 12.3252C16.646 12.3252 16.2645 12.4833 15.9832 12.7646L12.8012 15.9465C12.5199 16.2278 12.3619 16.6093 12.3619 17.0072C12.3619 17.405 12.5199 17.7865 12.8012 18.0678L15.9832 21.2498C16.2645 21.5311 16.646 21.6891 17.0438 21.6891C17.4416 21.6891 17.8232 21.5311 18.1045 21.2498L21.2864 18.0678C21.5677 17.7865 21.7258 17.405 21.7258 17.0072C21.7258 16.6093 21.5677 16.2278 21.2864 15.9465ZM17.0438 20.1891L13.8619 17.0072L17.0438 13.8252L20.2258 17.0072L17.0438 20.1891Z" fill="var(--group-primary)"></path>
                </svg>
              </div>
              <span data-v-5f651626 class="text-primaryText menu-item group" data-menu-id="13" style="display: inline-flex;"><span data-v-5f651626 class="title">Markets</span></span><span data-v-5f651626 class="text-primaryText menu-item group" data-menu-id="99" style="display: inline-flex;"><span data-v-5f651626 class="title" data-testid="HeaderTradeButton">Trade</span></span><span data-v-5f651626 class="text-primaryText menu-item group" data-menu-id="259" style="display: inline-flex;"><span data-v-5f651626 class="title">Futures</span><img data-v-5f651626 class="tag-img" src="https://img.bitgetimg.com/multiLang/web/348920c3f7c1828fa1820516d5460943.png" alt></span><span data-v-5f651626 class="text-primaryText menu-item group" data-menu-id="142" style="display: inline-flex;"><span data-v-5f651626 class="title">Copy</span></span><span data-v-5f651626 class="text-primaryText menu-item group" data-menu-id="143" style="display: inline-flex;"><span data-v-5f651626 class="title">Bots</span></span><span data-v-5f651626 class="text-primaryText menu-item group" data-menu-id="53" style="display: inline-flex;"><span data-v-5f651626 class="title">Earn</span></span><span data-v-5f651626 class="text-primaryText menu-item group" data-menu-id="88" style="display: inline-flex;"><span data-v-5f651626 class="title">Web3</span></span><span data-v-5f651626 class="text-primaryText menu-item group" data-menu-id="277" style="display: inline-flex;"><span data-v-5f651626 class="title">Launchhub</span></span><a data-v-5f651626 class="text-primaryText menu-item group min-w-[fit-content]" href="/asia/copy-trading/traderpro?proSourceType=1&amp;utmTerm=19" target="_blank" data-menu-id="247" style="display: inline-flex;"><img data-v-5f651626 class="h-24px group-hover:hidden" src="https://img.bitgetimg.com/multiLang/web/6146e63b2dd4207e82fb0c71a8d82d65.png" alt="TraderPro"><img data-v-5f651626 class="h-24px hidden group-hover:inline-block" src="https://img.bitgetimg.com/multiLang/web/16613340924bf9b9386583f94426ead0.png" alt="TraderPro"></a>
              <div data-v-5f651626 class="absolute top-100% rounded-12px light:shadow-popover light:border-1px light:border-line light:bg-bg dark:bg-dsColorLayerOne" style="will-change: transform, opacity, left, right; transition: opacity 0.15s; opacity: 0;">
                <div class="relative z-1 bg-inherit rounded-12px overflow-hidden w-[fit-content]">
                  <div style="display: none;">
                    <div data-v-550f7d44 class="flex flex-row gap-4px min-h-338px max-h-504px bg-inherit" style="height: 584px; max-height: 404px;">
                      <div data-v-550f7d44 class="flex flex-row mt-4px h-[calc(100%-8px)] overflow-x-auto">
                        <div data-v-550f7d44 class="px-12px pt-8px h-auto">
                          <div data-v-550f7d44 class="px-16px h-48px leading-48px text-16px font-600">Promotions</div>
                          <div data-v-550f7d44 class="flex flex-col flex-wrap gap-8px pb-8px">
                            <a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/launchpool" target="_blank" style="height: 48px;">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Launchpool</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/poolx" target="_blank" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">PoolX</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/candy-bomb" target="_self" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">CandyBomb</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/referral-all-program" target="_blank" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Referral</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/rewards" target="_self" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Rewards</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/coin-buddy" target="_blank" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Coin Buddy</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/referral" target="_self" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Invite friends</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/turntable" target="_self" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Fortune Wheel</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/offer" target="_self" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Assist2Earn</div>
                              </div>
                            </div>
                          </a></div>
                        </div>
                        <div data-v-550f7d44 class="px-12px pt-8px h-auto">
                          <div data-v-550f7d44 class="px-16px h-48px leading-48px text-16px font-600">Programs</div>
                          <div data-v-550f7d44 class="flex flex-col flex-wrap gap-8px pb-8px">
                            <a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/affiliates" target="_self" style="height: 48px;">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Affiliates</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/kol-promotion" target="_blank" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Booster Platform</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/incubation-program" target="_self" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Bitget Builders</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/broker" target="_self" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Broker program</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/vip/vipIntroduce" target="_self" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">VIP program</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/custody" target="_self" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Asset custody</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/taxes-api" target="_blank" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Tax API</div>
                              </div>
                            </div>
                          </a></div>
                        </div>
                        <div data-v-550f7d44 class="px-12px pt-8px h-auto">
                          <div data-v-550f7d44 class="px-16px h-48px leading-48px text-16px font-600">Learn and explore</div>
                          <div data-v-550f7d44 class="flex flex-col flex-wrap gap-8px pb-8px">
                            <a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/support/announcement-center" target="_blank" style="height: 48px;">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Announcement center</div>
                                </div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/academy" target="_self" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Bitget Academy</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/kyc?source=1" target="_self" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">ID verification zone</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/futures-tutorial?source=2" target="_blank" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Futures zone</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/blog" target="_self" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Bitget Blog</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/learn-to-earn" target="_self" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Learn2Earn</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/research" target="_self" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Bitget Research</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/support" target="_self" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Help Center</div>
                              </div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/feedback" target="_self" style="height: 48px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Submit feedback</div>
                              </div>
                            </div>
                          </a></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div style="display: none;">
                    <div data-v-3d905981 class="flex bg-inherit max-h-504px">
                      <div data-v-3d905981 class="relative p-12px w-276px overflow-y-auto">
                        <div data-v-3d905981 class="flex gap-12px flex-col">
                          <a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/markets/overview" target="_self" data-testid="menu_market_chance_title">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Opportunities</div>
                              </div>
                              <div data-v-097919ff class="desc">Timely seize new market opportunities</div>
                            </div>
                          </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/markets" target="_self" data-testid="menu_market_title">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Markets</div>
                            </div>
                            <div data-v-097919ff class="desc">View the latest crypto prices and volume</div>
                          </div>
                        </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/markets/trading-data" target="_self" data-testid="menu_menu_data">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Data</div>
                            </div>
                            <div data-v-097919ff class="desc">Halving info and trading data</div>
                          </div>
                        </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/insights" target="_blank" data-testid="menu_insight">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Insights</div>
                            </div>
                            <div data-v-097919ff class="desc">Insights from experts</div>
                          </div>
                        </a></div>
                      </div>
                    </div>
                  </div>
                  <div style="display: none;">
                    <div data-v-3d905981 class="flex bg-inherit max-h-504px">
                      <div data-v-3d905981 class="relative p-12px w-276px overflow-y-auto">
                        <div data-v-3d905981 class="flex gap-12px flex-col">
                          <a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/spot/BTCUSDT" target="_self" data-testid="menu_spot">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Spot</div>
                              </div>
                              <div data-v-097919ff class="desc">Buy and sell crypto with ease</div>
                            </div>
                            <svg data-v-097919ff width="13" height="14" viewBox="0 0 13 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="arrow">
                              <g id="i-down">
                                <path id="Line 72 (Stroke)" fill-rule="evenodd" clip-rule="evenodd" d="M4.84492 11.8125L4.21875 11.2479L8.72283 6.75L4.21875 2.25209L4.84492 1.6875L9.84375 6.75L4.84492 11.8125Z" fill="#B8B8B8"></path>
                              </g>
                            </svg>
                          </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/spot/BTCUSDT?type=cross" target="_self" data-testid="menu_margin">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Margin</div>
                            </div>
                            <div data-v-097919ff class="desc">Trade with leverage</div>
                          </div>
                        </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/convert" target="_self" data-testid="menu_spot_convert">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Convert</div>
                            </div>
                            <div data-v-097919ff class="desc">Zero fees, no slippage</div>
                          </div>
                        </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/bitget-api" target="_self" data-testid="menu_api_trading">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">APIs</div>
                            </div>
                            <div data-v-097919ff class="desc">Take your trading to the next level</div>
                          </div>
                        </a></div>
                      </div>
                    </div>
                  </div>
                  <div style="display: none;">
                    <div data-v-3d905981 class="flex bg-inherit max-h-504px">
                      <div data-v-3d905981 class="relative p-12px w-276px overflow-y-auto">
                        <div data-v-3d905981 class="flex gap-12px flex-col">
                          <a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/futures" target="_blank" data-testid>
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Futures overview</div>
                              </div>
                              <div data-v-097919ff class="desc">Browse all Bitget futures services</div>
                            </div>
                          </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/futures/usdt/BTCUSDT" target="_blank" data-testid="menu_menu_usdt_m">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">USDT-M Futures</div>
                            </div>
                            <div data-v-097919ff class="desc">Futures settled in USDT</div>
                          </div>
                          <svg data-v-097919ff width="13" height="14" viewBox="0 0 13 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="arrow">
                            <g id="i-down">
                              <path id="Line 72 (Stroke)" fill-rule="evenodd" clip-rule="evenodd" d="M4.84492 11.8125L4.21875 11.2479L8.72283 6.75L4.21875 2.25209L4.84492 1.6875L9.84375 6.75L4.84492 11.8125Z" fill="#B8B8B8"></path>
                            </g>
                          </svg>
                        </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/futures/usdc/BTCPERP" target="_blank" data-testid="menu_menu_usdc_m">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">USDC-M Futures</div>
                            </div>
                            <div data-v-097919ff class="desc">Futures settled in USDC</div>
                          </div>
                          <svg data-v-097919ff width="13" height="14" viewBox="0 0 13 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="arrow">
                            <g id="i-down">
                              <path id="Line 72 (Stroke)" fill-rule="evenodd" clip-rule="evenodd" d="M4.84492 11.8125L4.21875 11.2479L8.72283 6.75L4.21875 2.25209L4.84492 1.6875L9.84375 6.75L4.84492 11.8125Z" fill="#B8B8B8"></path>
                            </g>
                          </svg>
                        </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/futures/usd/BTCUSD" target="_blank" data-testid="menu_menu_coin_m">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Coin-M Futures</div>
                            </div>
                            <div data-v-097919ff class="desc">Futures settled in cryptocurrencies</div>
                          </div>
                          <svg data-v-097919ff width="13" height="14" viewBox="0 0 13 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="arrow">
                            <g id="i-down">
                              <path id="Line 72 (Stroke)" fill-rule="evenodd" clip-rule="evenodd" d="M4.84492 11.8125L4.21875 11.2479L8.72283 6.75L4.21875 2.25209L4.84492 1.6875L9.84375 6.75L4.84492 11.8125Z" fill="#B8B8B8"></path>
                            </g>
                          </svg>
                        </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/events/futures-tutorial?source=2" target="_blank" data-testid>
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Futures Kickoff</div>
                            </div>
                            <div data-v-097919ff class="desc">For beginners to try out futures trading</div>
                          </div>
                        </a><span data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" data-testid><div data-v-097919ff class="flex-1"><div data-v-097919ff class="title"><div data-v-097919ff class="line-clamp-2">Futures promotions</div></div><div data-v-097919ff class="desc">Generous rewards await</div></div></span><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/events/super-pairs" target="_blank" data-testid>
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Super Pairs</div>
                            </div>
                            <div data-v-097919ff class="desc">Trade the newest &amp; hottest futures pairs</div>
                          </div>
                        </a></div>
                      </div>
                    </div>
                  </div>
                  <div style="display: none;">
                    <div data-v-e216624f class="flex flex-row gap-4px min-h-320px max-h-504px bg-inherit">
                      <div data-v-e216624f class="menu-right-border p-24px w-260px b-r-line">
                        <div data-v-e216624f class="my-8px font-700 text-16px leading-140% whitespace-pre-line">Bitget TraderPro program</div>
                        <div data-v-e216624f class="text-12px text-contentTertiary leading-140%">Unlock your trading potential! Become a verified Bitget elite trader and earn 10,000 USDT to help skyrocket your profits. Join now and start your journey to success!</div>
                        <button data-v-e216624f aria-disabled="false" type="button" class="mi-button is-round mt-20px"><!--v-if--><span class>Start challenge <i data-v-e216624f class="mi-icon ml-4px" style="font-size: 16px;"><svg data-v-e216624f xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M20.78 12.53l-6.75 6.75a.75.75 0 01-1.06-1.06l5.47-5.47H3.75a.75.75 0 110-1.5h14.69l-5.47-5.47a.75.75 0 111.06-1.06l6.75 6.75a.747.747 0 010 1.06z"></path></svg></i></span><!--v-if-->
                        </button>
                      </div>
                      <div data-v-e216624f class="p-12px w-260px overflow-y-auto">
                        <a data-v-097919ff data-v-e216624f class="text-primaryText menu-item" href="/asia/copy-trading/overview" target="_self">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Overview</div>
                            </div>
                            <div data-v-097919ff class="desc">Introduction to Bitget copy trading and its advantages</div>
                          </div>
                        </a>
                        <div data-v-e216624f class="mt-8px mb-4px p-12px text-16px font-700">Copy what suits you</div>
                        <div data-v-e216624f class="flex flex-col gap-8px">
                          <a data-v-097919ff data-v-e216624f class="text-primaryText menu-item" href="/asia/copy-trading/futures" target="_self">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Futures Copy Trading</div>
                              </div>
                              <div data-v-097919ff class="desc">Follow the world's top futures trading experts</div>
                            </div>
                          </a><a data-v-097919ff data-v-e216624f class="text-primaryText menu-item" href="/asia/copy-trading/spot" target="_self">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Spot Copy Trading</div>
                            </div>
                            <div data-v-097919ff class="desc">Follow the world's top spot trading experts</div>
                          </div>
                        </a><a data-v-097919ff data-v-e216624f class="text-primaryText menu-item" href="/asia/copy-trading/strategy" target="_self">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Bot Copy Trading</div>
                            </div>
                            <div data-v-097919ff class="desc">Copy top bots to trade smarter</div>
                          </div>
                        </a></div>
                      </div>
                      <div data-v-e216624f class="menu-left-border flex flex-col p-12px w-440px">
                        <div data-v-e216624f class="flex justify-between">
                          <a data-v-e216624f class="text-primaryText flex items-center px-12px h-36px text-16px font-700 cursor-pointer rounded-99px hover:bg-bgSecondary" href="/copy-trading/leaderboard-ranking/futures-roi" target="_self">Leaderboard
                            <svg data-v-e216624f width="13" height="14" viewBox="0 0 13 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="ml-4px [&amp;_path]:fill-contentTertiary">
                              <g id="i-down">
                                <path id="Line 72 (Stroke)" fill-rule="evenodd" clip-rule="evenodd" d="M4.84492 11.8125L4.21875 11.2479L8.72283 6.75L4.21875 2.25209L4.84492 1.6875L9.84375 6.75L4.84492 11.8125Z" fill="#B8B8B8"></path>
                              </g>
                            </svg>
                          </a></div>
                        <div data-v-e216624f class="flex flex-1 items-center">
                          <div data-v-e216624f class="flex items-end gap-8px p-12px">
                            <div data-v-e216624f class="card">
                              <img data-v-e216624f class="rounded-100px w-40px h-40px mb-20px" src="/micro-runtime/assets/avatar.2d0040f2.svg" alt="avatar">
                              <div data-v-e216624f class="mi-skeleton is-animated skeleton skeleton"><!-- <bit-skeleton-item :class="ns.is('first')" variant="p" /> -->
                                <div class="mi-skeleton__item mi-skeleton__p mi-skeleton__paragraph"><!--v-if--></div>
                                <div class="mi-skeleton__item mi-skeleton__p mi-skeleton__paragraph is-last"><!--v-if--></div>
                              </div>
                            </div>
                            <div data-v-e216624f class="card !h-232px !w-132px">
                              <img data-v-e216624f class="rounded-100px w-40px h-40px mb-20px !w-70px !h-70px mb-40px" src="/micro-runtime/assets/avatar.2d0040f2.svg" alt="avatar">
                              <div data-v-e216624f class="mi-skeleton is-animated skeleton skeleton"><!-- <bit-skeleton-item :class="ns.is('first')" variant="p" /> -->
                                <div class="mi-skeleton__item mi-skeleton__p mi-skeleton__paragraph"><!--v-if--></div>
                                <div class="mi-skeleton__item mi-skeleton__p mi-skeleton__paragraph is-last"><!--v-if--></div>
                              </div>
                            </div>
                            <div data-v-e216624f class="card">
                              <img data-v-e216624f class="rounded-100px w-40px h-40px mb-20px" src="/micro-runtime/assets/avatar.2d0040f2.svg" alt="avatar">
                              <div data-v-e216624f class="mi-skeleton is-animated skeleton skeleton"><!-- <bit-skeleton-item :class="ns.is('first')" variant="p" /> -->
                                <div class="mi-skeleton__item mi-skeleton__p mi-skeleton__paragraph"><!--v-if--></div>
                                <div class="mi-skeleton__item mi-skeleton__p mi-skeleton__paragraph is-last"><!--v-if--></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div style="display: none;">
                    <div data-v-25920e85 class="flex flex-row gap-4px min-h-380px max-h-504px bg-inherit">
                      <div data-v-25920e85 class="p-12px w-276px overflow-y-auto">
                        <a data-v-097919ff data-v-25920e85 class="text-primaryText menu-item" href="/asia/trading-bot" target="_self">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Overview</div>
                            </div>
                            <div data-v-097919ff class="desc">Bringing together the most comprehensive top bots</div>
                          </div>
                        </a>
                        <div data-v-25920e85 class="px-12px">
                          <div data-v-25920e85 class="my-20px text-16px font-600">Create</div>
                        </div>
                        <div data-v-25920e85 class="flex flex-col gap-8px mt-10px">
                          <a data-v-097919ff data-v-25920e85 class="text-primaryText menu-item" href="/asia/trading-bot/spot/BTCUSDT" target="_blank">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Spot grid</div>
                              </div>
                              <div data-v-097919ff class="desc">Automate trades with grid bots</div>
                            </div>
                          </a><a data-v-097919ff data-v-25920e85 class="text-primaryText menu-item" href="/asia/trading-bot/futures/BTCUSDT" target="_blank">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Futures grid</div>
                            </div>
                            <div data-v-097919ff class="desc">Amplify grid bot trades with leverage</div>
                          </div>
                        </a><a data-v-097919ff data-v-25920e85 class="text-primaryText menu-item" href="/asia/trading-bot/spot/moon/BTCUSDT" target="_self">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Spot position grid</div>
                            </div>
                            <div data-v-097919ff class="desc">Buy low and sell high on volatile markets.</div>
                          </div>
                        </a><a data-v-097919ff data-v-25920e85 class="text-primaryText menu-item" href="/asia/trading-bot/futures/moon/BTCUSDT" target="_self">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Futures position grid</div>
                            </div>
                            <div data-v-097919ff class="desc">Place positions at regular intervals on oscillating markets.</div>
                          </div>
                        </a><a data-v-097919ff data-v-25920e85 class="text-primaryText menu-item" href="/asia/trading-bot/spot/timing/BTCUSDT" target="_blank">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Spot auto-invest+</div>
                            </div>
                            <div data-v-097919ff class="desc">Regularly invest without timing the market</div>
                          </div>
                        </a><a data-v-097919ff data-v-25920e85 class="text-primaryText menu-item" href="/asia/trading-bot/spot/hoard/BTCUSDT" target="_blank">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Smart Portfolio</div>
                            </div>
                            <div data-v-097919ff class="desc">Smart dynamic rebalancing and cyclic arbitrage</div>
                          </div>
                        </a></div>
                      </div>
                    </div>
                  </div>
                  <div style="display: none;">
                    <div data-v-550f7d44 class="flex flex-row gap-4px min-h-338px max-h-504px bg-inherit" style="height: 510px; max-height: 504px;">
                      <div data-v-550f7d44 class="flex flex-row mt-4px h-[calc(100%-8px)] overflow-x-auto">
                        <div data-v-550f7d44 class="px-12px pt-8px h-auto">
                          <div data-v-550f7d44 class="px-16px h-48px leading-48px text-16px font-600">Earn products</div>
                          <div data-v-550f7d44 class="flex flex-col flex-wrap gap-8px pb-8px">
                            <a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning?source1=earn&amp;source2=earn_overview" target="_self" style="height: 78px;">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Overview</div>
                                </div>
                                <div data-v-097919ff class="desc">Comprehensive investment and financial management</div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning/savings?source1=earn&amp;source2=savings" target="_self" style="height: 78px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Savings</div>
                              </div>
                              <div data-v-097919ff class="desc">Earn daily profits with idle tokens</div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning/staking" target="_self" style="height: 78px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Staking</div>
                              </div>
                              <div data-v-097919ff class="desc">Guaranteed earnings in both bear and bull markets</div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning/loan" target="_self" style="height: 78px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Crypto Loans</div>
                              </div>
                              <div data-v-097919ff class="desc">Borrow crypto quickly and easily</div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning/bgb-staking" target="_self" style="height: 78px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">BGB Staking</div>
                              </div>
                              <div data-v-097919ff class="desc">Stake BGB for zero-fee withdrawals</div>
                            </div>
                          </a></div>
                        </div>
                        <div data-v-550f7d44 class="px-12px pt-8px h-auto">
                          <div data-v-550f7d44 class="px-16px h-48px leading-48px text-16px font-600"></div>
                          <div data-v-550f7d44 class="flex flex-col flex-wrap gap-8px pb-8px">
                            <a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning/shark-fin" target="_self" style="height: 78px;">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">Shark Fin</div>
                                </div>
                                <div data-v-097919ff class="desc">Principal-guaranteed high yields</div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning/smart-trend" target="_self" style="height: 78px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Smart Trend</div>
                              </div>
                              <div data-v-097919ff class="desc">Time the market and enjoy incredible yields</div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning/dual-investment" target="_self" style="height: 78px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Dual Investment</div>
                              </div>
                              <div data-v-097919ff class="desc">Buy low and sell high — profit no matter the market direction</div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning/wealth-management" target="_self" style="height: 78px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Wealth Management</div>
                              </div>
                              <div data-v-097919ff class="desc">Grow your wealth with our top-tier asset management team</div>
                            </div>
                          </a></div>
                        </div>
                        <div data-v-550f7d44 class="px-12px pt-8px h-auto">
                          <div data-v-550f7d44 class="px-16px h-48px leading-48px text-16px font-600">Promotions</div>
                          <div data-v-550f7d44 class="flex flex-col flex-wrap gap-8px pb-8px">
                            <a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/BGB/intro" target="_self" style="height: 78px;">
                              <div data-v-097919ff class="flex-1">
                                <div data-v-097919ff class="title">
                                  <div data-v-097919ff class="line-clamp-2">BGB Zone</div>
                                </div>
                                <div data-v-097919ff class="desc">All BGB rewards in one place</div>
                              </div>
                            </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/earning/auto-invest" target="_blank" style="height: 78px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Spot auto-invest+</div>
                              </div>
                              <div data-v-097919ff class="desc">Automatically subscribe to auto-invest Earn products and earn for additional profits.</div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/launchpool" target="_self" style="height: 78px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Launchpool</div>
                              </div>
                              <div data-v-097919ff class="desc">Stake and mine hot and new tokens</div>
                            </div>
                          </a><a data-v-097919ff data-v-550f7d44 class="text-primaryText menu-item" href="/asia/events/poolx" target="_blank" style="height: 78px;">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">PoolX</div>
                              </div>
                              <div data-v-097919ff class="desc">Stake for new tokens. Always on. Always earning.</div>
                            </div>
                          </a></div>
                        </div>
                      </div>
                      <div data-v-550f7d44 class="relative py-40px px-34px w-260px text-center bg-bgSecondary">
                        <div class="mt-20px text-20px font-700">Crypto loans!</div>
                        <div class="mt-8px font-500 text-12px !leading-18px">Flexible borrowing</div>
                        <button aria-disabled="false" type="button" class="mi-button mi-button--chunky is-round absolute bottom-40px left-[calc(50%-81px)] h-40px w-162px"><!--v-if--><span class>Details <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" class="ml-8px"><g clip-path="url(#clip0_1051_26544)"><path d="M10.7807 7.33312L7.20468 3.75712L8.14735 2.81445L13.3327 7.99979L8.14735 13.1851L7.20468 12.2425L10.7807 8.66645H2.66602V7.33312H10.7807Z" fill="currentColor"></path></g><defs><clipPath id="clip0_1051_26544"><rect width="16" height="16" fill="white"></rect></clipPath></defs></svg></span><!--v-if-->
                        </button>
                      </div>
                    </div>
                  </div>
                  <div style="display: none;">
                    <div data-v-3d905981 class="flex bg-inherit max-h-504px">
                      <div data-v-3d905981 class="relative p-12px w-276px overflow-y-auto">
                        <div data-v-3d905981 class="flex gap-12px flex-col">
                          <a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="https://web3.bitget.com/en?source=bitget" target="_blank" data-testid="menu_web3_wallet_title">
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Bitget Wallet</div>
                              </div>
                              <div data-v-097919ff class="desc">Decentralized Web3 wallet for safer crypto transactions</div>
                            </div>
                          </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="https://web3.bitget.com/en/nft?source=bitget" target="_blank" data-testid="menu_web3_nft_title">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Bitget NFT</div>
                            </div>
                            <div data-v-097919ff class="desc">Simplified batch listing and purchasing NFTs with any tokens</div>
                          </div>
                        </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="https://web3.bitget.com/en/dapp?source=bitget" target="_blank" data-testid="menu_web3_dapp_title">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">DApp</div>
                            </div>
                            <div data-v-097919ff class="desc">Engage with the massive trending DApps</div>
                          </div>
                        </a></div>
                      </div>
                    </div>
                  </div>
                  <div style="display: none;">
                    <div data-v-3d905981 class="flex bg-inherit max-h-504px">
                      <div data-v-3d905981 class="relative p-12px w-276px overflow-y-auto">
                        <div data-v-3d905981 class="flex gap-12px flex-col">
                          <a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/pre-market" target="_blank" data-testid>
                            <div data-v-097919ff class="flex-1">
                              <div data-v-097919ff class="title">
                                <div data-v-097919ff class="line-clamp-2">Pre-Market</div>
                              </div>
                              <div data-v-097919ff class="desc">Grab coins before they're listed</div>
                            </div>
                          </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/events/launchpad" target="_blank" data-testid="menu_launchpad">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Launchpad</div>
                            </div>
                            <div data-v-097919ff class="desc">Get ahead with hot and new tokens</div>
                          </div>
                        </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/events/launchpool" target="_blank" data-testid="menu_launchpool">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Launchpool</div>
                            </div>
                            <div data-v-097919ff class="desc">Stake and mine hot and new tokens</div>
                          </div>
                        </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/events/poolx" target="_blank" data-testid>
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">PoolX</div>
                            </div>
                            <div data-v-097919ff class="desc">Stake to win token airdrops</div>
                          </div>
                        </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/events/candy-bomb" target="_blank" data-testid="menu_candybomb">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">CandyBomb</div>
                            </div>
                            <div data-v-097919ff class="desc">Get ready for an explosion of rewards</div>
                          </div>
                        </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/events/deposit" target="_blank" data-testid="menu_events_deposit">
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Deposit to List</div>
                            </div>
                            <div data-v-097919ff class="desc">Deposit and list tokens easily</div>
                          </div>
                        </a><a data-v-097919ff data-v-3d905981 class="text-primaryText menu-item" href="/asia/events/tap-to-earn-more" target="_blank" data-testid>
                          <div data-v-097919ff class="flex-1">
                            <div data-v-097919ff class="title">
                              <div data-v-097919ff class="line-clamp-2">Tap to Earn More</div>
                            </div>
                            <div data-v-097919ff class="desc">Tap "Boost" daily for a +5% deposit boost</div>
                          </div>
                        </a></div>
                      </div>
                    </div>
                  </div>
                  <div style="display: none;">
                    <div data-v-3d905981 class="flex bg-inherit max-h-504px">
                      <div data-v-3d905981 class="relative p-12px w-276px overflow-y-auto">
                        <div data-v-3d905981 class="flex gap-12px flex-col"></div>
                        <div data-v-3d905981 class="flex flex-col items-center justify-center py-20px">
                          <svg width="88" height="86" viewBox="0 0 88 86" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M61.5 41.1198C63.7701 41.0244 65.9032 41.086 67.8562 41.2995C71.0644 41.6503 73.7715 42.4093 75.7997 43.543C77.8261 44.6757 79.1568 46.171 79.6602 47.9934C80.1636 49.8159 79.8056 51.8419 78.6787 53.9656C77.5508 56.091 75.6621 58.2945 73.1446 60.4446C72.7761 60.7593 72.3944 61.0727 72 61.3843M28.2887 51.5447C26.3172 52.7849 24.543 54.0786 23.0003 55.3962C20.4828 57.5464 18.5941 59.7498 17.4662 61.8753C16.3393 63.999 15.9813 66.025 16.4847 67.8474C16.9881 69.6698 18.3188 71.1651 20.3452 72.2978C22.3734 73.4315 25.0805 74.1906 28.2887 74.5413C34.7041 75.2427 43.0626 74.3048 51.8366 71.5474C52.5668 71.3179 53.2882 71.0796 54 70.8328" stroke="var(--color-disabled-text)" stroke-width="0.622027"></path>
                            <path d="M64.8571 55.5L56.843 23.4049C56.2182 20.9025 53.699 19.4471 51.2192 20.1559L26.9782 27.084C24.4981 27.7928 22.9987 30.3972 23.631 32.8977L34.1662 74.5583C34.1832 74.5586 34.2013 74.5588 34.2203 74.559C34.4057 74.5612 34.684 74.5612 35.0526 74.552C35.7896 74.5338 36.8873 74.4793 38.323 74.334C41.1942 74.0435 45.4175 73.3897 50.8111 71.936C51.8964 71.6435 52.9632 71.3167 54 70.9681" stroke="var(--color-disabled-text)" stroke-width="0.622027"></path>
                            <path d="M52.7654 32.3288L31.1859 38.4962C30.82 38.6008 30.5986 38.9847 30.6913 39.3538L31.1243 41.0774C31.217 41.4464 31.5888 41.6608 31.9546 41.5563L53.5341 35.3888C53.9 35.2842 54.1214 34.9003 54.0287 34.5313L53.5957 32.8076C53.503 32.4386 53.1313 32.2242 52.7654 32.3288Z" stroke="var(--color-disabled-text)" stroke-width="0.622027"></path>
                            <path d="M55.0701 41.1745L33.4906 47.3419C33.1247 47.4465 32.9033 47.8304 32.996 48.1995L33.429 49.9231C33.5217 50.2921 33.8934 50.5065 34.2593 50.402L55.8388 44.2345C56.2047 44.13 56.4261 43.746 56.3334 43.377L55.9004 41.6534C55.8077 41.2843 55.436 41.0699 55.0701 41.1745Z" stroke="var(--color-disabled-text)" stroke-width="0.622027"></path>
                            <path d="M80.0897 16.3879C80.5844 17.5588 80.3321 18.9478 79.4635 20.2646C78.5961 21.5796 77.1282 22.7953 75.2595 23.5846C73.3908 24.374 71.4959 24.5789 69.9484 24.2839C68.3988 23.9886 67.2272 23.2011 66.7325 22.0301C66.2379 20.8592 66.4902 19.4702 67.3588 18.1534C68.2262 16.8384 69.6941 15.6227 71.5628 14.8334C73.4315 14.044 75.3264 13.8391 76.8739 14.1341C78.4235 14.4294 79.5951 15.2169 80.0897 16.3879Z" stroke="var(--color-disabled-text)" stroke-width="0.5"></path>
                            <path d="M77.9445 18.3791C78.3743 19.3966 77.073 20.9183 75.038 21.7779" stroke="var(--color-disabled-text)" stroke-width="0.5"></path>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M65.0429 18.6722C63.9146 16.0012 66.0932 12.5293 69.9089 10.9175C73.7246 9.30573 77.7324 10.1644 78.8607 12.8353L80.2226 16.0595L80.2141 16.0631C79.0048 13.7023 75.1652 13.0394 71.4654 14.6023C67.7655 16.1651 65.564 19.3799 66.4133 21.8927L66.4048 21.8963L65.0429 18.6722Z" fill="var(--color-disabled-text)"></path>
                            <path d="M57.5074 56.3595C58.8612 55.0057 60.9317 54.5815 63.224 55.04C65.5143 55.498 67.9952 56.8342 70.1121 58.9512C72.2291 61.0681 73.5653 63.5491 74.0234 65.8393C74.4818 68.1316 74.0576 70.2021 72.7038 71.5559C71.35 72.9098 69.2795 73.3339 66.9872 72.8755C64.697 72.4174 62.216 71.0812 60.0991 68.9643C57.9821 66.8473 56.6459 64.3664 56.1878 62.0761C55.7294 59.7838 56.1536 57.7133 57.5074 56.3595Z" stroke="var(--color-disabled-text)" stroke-width="0.5"></path>
                            <path d="M61.4764 58.2557C62.6215 57.1106 65.4062 58.0389 67.6964 60.329" stroke="var(--color-disabled-text)" stroke-width="0.5"></path>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M68.9933 75.62C65.9875 78.6258 60.0698 77.5815 55.7758 73.2875C51.4818 68.9935 50.4375 63.0759 53.4433 60.0701L57.0716 56.4417L57.0811 56.4512C54.5409 59.3959 55.7581 64.9774 59.922 69.1413C64.0859 73.3052 69.6674 74.5224 72.6121 71.9822L72.6216 71.9917L68.9933 75.62Z" fill="var(--color-disabled-text)"></path>
                            <path d="M12.7754 26.537C12.1076 26.9225 11.2219 26.8589 10.2994 26.3713C9.38049 25.8857 8.46155 24.9944 7.77499 23.8053C7.08843 22.6161 6.77608 21.3747 6.81495 20.336C6.85397 19.2934 7.24171 18.4945 7.90944 18.109C8.57718 17.7234 9.46291 17.7871 10.3854 18.2746C11.3043 18.7603 12.2233 19.6515 12.9098 20.8407C13.5964 22.0298 13.9087 23.2713 13.8699 24.3099C13.8308 25.3526 13.4431 26.1515 12.7754 26.537Z" stroke="var(--color-disabled-text)" stroke-width="0.5"></path>
                            <path d="M11.4775 25.3629C10.8625 25.718 9.75317 24.9479 8.99971 23.6429" stroke="var(--color-disabled-text)" stroke-width="0.5"></path>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M9.87181 16.6877C11.4862 15.7556 13.9402 16.9836 15.3529 19.4305C16.7656 21.8774 16.6021 24.6166 14.9877 25.5487L13.039 26.6738L13.0357 26.6681C14.4416 25.7022 14.495 23.0888 13.1253 20.7163C11.7555 18.3439 9.46558 17.0835 7.9261 17.818L7.92307 17.8128L9.87181 16.6877Z" fill="var(--color-disabled-text)"></path>
                          </svg>
                          <span class="mt-16px text-thirdText">No data</span></div>
                      </div>
                    </div>
                  </div>
                </div>
                <i class="absolute -top-6px w-12px h-12px rounded-[3px_0_0_0] rotate-45deg light:shadow-popover light:border-1px light:border-line light:bg-bg dark:bg-cardBg" style="opacity: 0;"></i>
              </div>
            </div>
          </div>
        </div>
        <div data-micro-type="GlobalDialog" class="micro micro-light" data-micro-id="55565866"></div>
        <div data-micro-type="KycGuideBar" class="micro micro-light" data-micro-id="148535682">
          <div data-v-ea321364 class="micro-kyc-guide-bar flex items-center justify-between py-8px px-16px cursor-pointer lt-md:min-h-36px lt-md:box-border" style="background-color: rgba(255, 145, 66, 0.14); display: none;">
            <div data-v-ea321364 class="w-full flex items-center md:justify-center md:justify-start">
              <div data-v-ea321364 class="text-primaryText text-fs14 flex items-center lt-md:block">
                <div data-v-ea321364 class="flex item-center">
                  <span data-v-ea321364 class="ml-8px mr-12px break-words line-clamp-3 max-w-[calc(100vw-88px)]">Complete identity verification to unlock all features.</span>
                </div>
                <div data-v-ea321364 class="mr-12px flex items-center lt-md:hidden">
                  <i data-v-ea321364 class="mi-icon mi-tooltip__trigger" style="font-size: 16px;">
                    <svg data-v-ea321364 xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                      <path d="M13.125 16.875a1.125 1.125 0 11-2.25 0 1.125 1.125 0 012.25 0zM12 6.75c-2.068 0-3.75 1.514-3.75 3.375v.375a.75.75 0 101.5 0v-.375c0-1.031 1.01-1.875 2.25-1.875s2.25.844 2.25 1.875C14.25 11.156 13.24 12 12 12a.75.75 0 00-.75.75v.75a.75.75 0 101.5 0v-.068c1.71-.314 3-1.678 3-3.307 0-1.86-1.682-3.375-3.75-3.375zM21.75 12A9.75 9.75 0 1112 2.25 9.76 9.76 0 0121.75 12zm-1.5 0A8.25 8.25 0 1012 20.25 8.26 8.26 0 0020.25 12z"></path>
                    </svg>
                  </i>
                </div>
                <span data-v-ea321364 class="header-kyc-btn mr-12px whitespace-nowrap lt-md:hidden" style="color: rgb(255, 145, 66);">Verify now</span>
              </div>
            </div>
            <i data-v-ea321364 class="mi-icon text-primaryText" style="font-size: 16px;">
              <svg data-v-ea321364 xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                <path d="M19.28 18.22a.75.75 0 01-.817 1.223.75.75 0 01-.244-.162L12 13.06l-6.22 6.22a.75.75 0 01-1.06-1.062L10.94 12 4.72 5.78a.75.75 0 111.06-1.06L12 10.94l6.22-6.22a.75.75 0 011.06 1.06L13.06 12l6.22 6.22z"></path>
              </svg>
            </i></div>
        </div>
        <div style="display: none;">
          <div class="header-referral">
            <a href="javascript:;"><img src="../assets/img/referral-gift-white.svg" alt="header-referral-light" loading="lazy" class="header-referral-gift">
              <img src="../assets/img/referral-gift-black1.svg" alt="header-referral-black" loading="lazy" class="header-referral-gift" style="display: none;">
              <div class="header-referral-content"><span class="header-referral-u">Become a Premier Inviter and enjoy a <span>25%</span> rebate</span>
              </div>
              <i class="bit-icon text-v3PrimaryText rtl-rotate phone:hidden" style="font-size: 14px;">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M20.78 12.53l-6.75 6.75a.75.75 0 01-1.06-1.06l5.47-5.47H3.75a.75.75 0 110-1.5h14.69l-5.47-5.47a.75.75 0 111.06-1.06l6.75 6.75a.747.747 0 010 1.06z"></path>
                </svg>
              </i></a>
            <span class="!absolute px-5px py-5px top-8px cursor-pointer text-v3PrimaryText right-120px phone:right-0"><i class="bit-icon" style="font-size: 14px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M19.28 18.22a.75.75 0 01-.817 1.223.75.75 0 01-.244-.162L12 13.06l-6.22 6.22a.75.75 0 01-1.06-1.062L10.94 12 4.72 5.78a.75.75 0 111.06-1.06L12 10.94l6.22-6.22a.75.75 0 011.06 1.06L13.06 12l6.22 6.22z"></path></svg></i></span>
          </div>
        </div>
      </header>
      <div></div>
    </div>
    <div data-v-1d5ba9c6 class="bit-dialog__wrapper is-centered is-notitle" style="display: none;">
      <div role="dialog" aria-modal="true" aria-label="dialog" class="bit-dialog register-rewards__dialog--base border-0 border-none" style="margin-top: 15vh; width: 100%;">
        <div class="bit-dialog__header"></div>
        <div class="bit-dialog__footer">
          <div data-v-1d5ba9c6 class="lg:hidden mt-[20px] mx-auto w-[263px] lg:w-[700px] text-center cursor-pointer">
            <img data-v-1d5ba9c6 src="/baseasset/img/registerGift/rewards-close.svg" alt="new-register-rewards-close">
          </div>
        </div>
      </div>
    </div>
    <div data-micro-type="KycGuideDialog" class="micro micro-light" data-micro-id="314643623"></div>
    <div data-micro-type="LegalDialog" class="micro " data-micro-id="560848365"></div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      token: '',
      isLogin: false,
    }
  },
  mounted() {
    console.log('获取token')
    this.token = localStorage.getItem('token')
    if (this.token) {
      this.isLogin = true
      console.log(this.isLogin);
    }
    console.log(this.token);
  }
}
</script>

<style scoped>


</style>