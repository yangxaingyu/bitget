<template>
  <div data-micro-type="Tabbar" class="micro micro-light" data-micro-id="01479074">
    <div data-v-ba5e20f0="" class="micro-tabbar min-h-56px md:hidden" serverlocale="">
      <div data-v-ba5e20f0="" class="fixed left-0 z-1 flex py-5px w-full h-56px bg-bgPrimary transition-bottom duration-500" style="bottom: 0px; box-shadow: rgba(31, 31, 31, 0.03) 0px -0.5px 7px 2px; z-index: 100;">
        <a data-v-ba5e20f0="" class="flex flex-col flex-1 justify-center items-center text-contentTertiary text-12px no-underline cursor-pointer" href="/">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mb-2px text-contentPrimary">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M3.38322 9.61722C3.14131 9.80677 3 10.097 3 10.4043V20.4996C3 20.7757 3.22386 20.9996 3.5 20.9996H20.5C20.7761 20.9996 21 20.7757 21 20.4996V10.4043C21 10.097 20.8587 9.80677 20.6168 9.61722L12.3084 3.10692C12.1273 2.96501 11.8727 2.96501 11.6916 3.10692L3.38322 9.61722ZM11.3 12.9395C11.1343 12.9395 11 13.0738 11 13.2395V17.6395C11 17.8052 11.1343 17.9395 11.3 17.9395H12.7C12.8657 17.9395 13 17.8052 13 17.6395V13.2395C13 13.0738 12.8657 12.9395 12.7 12.9395H11.3Z" fill="currentColor"></path>
          </svg>
          Home</a><a data-v-ba5e20f0="" class="flex flex-col flex-1 justify-center items-center text-contentTertiary text-12px no-underline cursor-pointer" href="/markets">
        <svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mb-2px text-contentTertiary">
          <rect x="10.5" y="3" width="4" height="18" rx="0.5" fill="currentColor"></rect>
          <rect x="3.5" y="9" width="4" height="12" rx="0.5" fill="currentColor"></rect>
          <rect x="17.5" y="12" width="4" height="9" rx="0.5" fill="currentColor"></rect>
        </svg>
        Market</a><a data-v-ba5e20f0="" class="flex flex-col flex-1 justify-center items-center text-contentTertiary text-12px no-underline cursor-pointer" href="/spot/BTCUSDT">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mb-2px text-contentTertiary">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M12.1114 4.06458C8.02581 4.80415 4.80415 8.02581 4.06458 12.1114C2.80316 11.0632 2 9.48254 2 7.71429C2 4.55837 4.55837 2 7.71429 2C9.48254 2 11.0632 2.80316 12.1114 4.06458Z" fill="currentColor"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M13.9038 22.001C18.3747 22.001 21.9991 18.3767 21.9991 13.9058C21.9991 9.43491 18.3747 5.81055 13.9038 5.81055C9.43296 5.81055 5.80859 9.43491 5.80859 13.9058C5.80859 18.3767 9.43296 22.001 13.9038 22.001ZM16.598 13.973L13.9043 11.2793L11.2106 13.973L13.9043 16.6668L16.598 13.973Z" fill="currentColor"></path>
        </svg>
        Trade</a><a data-v-ba5e20f0="" class="flex flex-col flex-1 justify-center items-center text-contentTertiary text-12px no-underline cursor-pointer" href="/futures/usdt/BTCUSDT">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mb-2px text-contentTertiary">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M8 3.5C8 3.22386 8.22386 3 8.5 3H20.5C20.7761 3 21 3.22386 21 3.5V20.5C21 20.7761 20.7761 21 20.5 21H8.5C8.22386 21 8 20.7761 8 20.5V3.5ZM10 6.3C10 6.13431 10.1343 6 10.3 6H18.7C18.8657 6 19 6.13431 19 6.3V7.7C19 7.86569 18.8657 8 18.7 8H10.3C10.1343 8 10 7.86569 10 7.7V6.3ZM10.3 10C10.1343 10 10 10.1343 10 10.3V11.7C10 11.8657 10.1343 12 10.3 12H13.7C13.8657 12 14 11.8657 14 11.7V10.3C14 10.1343 13.8657 10 13.7 10H10.3Z" fill="currentColor"></path>
          <path d="M3 13.5C3 13.2239 3.22386 13 3.5 13H12V21H7C4.79086 21 3 19.2091 3 17V13.5Z" fill="currentColor"></path>
        </svg>
        Futures</a><a data-v-ba5e20f0="" class="flex flex-col flex-1 justify-center items-center text-contentTertiary text-12px no-underline cursor-pointer" rel="nofollow" href="/asset">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mb-2px text-contentTertiary">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M3.5 7C3.22386 7 3 7.22386 3 7.5V19.5C3 19.7761 3.22386 20 3.5 20H20.5C20.7761 20 21 19.7761 21 19.5V7.5C21 7.22386 20.7761 7 20.5 7H3.5ZM14.3536 12.6464C14.1583 12.8417 14.1583 13.1583 14.3536 13.3536L15.6464 14.6464C15.8417 14.8417 16.1583 14.8417 16.3536 14.6464L17.6464 13.3536C17.8417 13.1583 17.8417 12.8417 17.6464 12.6464L16.3536 11.3536C16.1583 11.1583 15.8417 11.1583 15.6464 11.3536L14.3536 12.6464Z" fill="currentColor"></path>
          <rect x="3" y="4" width="2" height="5" rx="0.5" fill="currentColor"></rect>
          <path d="M4.5 6C4.22386 6 4 5.77614 4 5.5L4 4.5C4 4.22386 4.22386 4 4.5 4L17.5 4C17.7761 4 18 4.22386 18 4.5L18 5.5C18 5.77614 17.7761 6 17.5 6L4.5 6Z" fill="currentColor"></path>
        </svg>
        Assets</a></div>
    </div>
  </div>
</template>


<script>

</script>


<style scoped>

</style>